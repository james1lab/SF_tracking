
      INCLUDE 'SUBs/SUB_FFT_LOCAL_FILTER_COS_FTN_HnF_f90.f'
      INCLUDE 'SUBs/MAT_ZFILT_FFEM_type_I_local_filter.f'

      SUBROUTINE NCINFO (IT,JT,KT,TT,NCDATA)
      IMPLICIT NONE
      integer :: status, ncid,varid,dimid
      integer :: IT,JT,KT,TT
      real :: truelat1,dx
      character(200) :: NCDATA
      INCLUDE 'netcdf.inc'
      status = nf_open(NCDATA,nf_nowrite,ncid)
      status = nf_inq_dimid(ncid,'longitude',dimid)
      status = nf_inq_dimlen(ncid,dimid,IT)
      status = nf_inq_dimid(ncid,'latitude',dimid)
      status = nf_inq_dimlen(ncid,dimid,JT)
      status = nf_inq_dimid(ncid,'plev',dimid)
      status = nf_inq_dimlen(ncid,dimid,KT)
      status = nf_inq_dimid(ncid,'time',dimid)
      status = nf_inq_dimlen(ncid,dimid,TT)
      ENDSUBROUTINE NCINFO

      SUBROUTINE NCGetVar4d (idata,IT,JT,KT,TT,LT,var,NCDATA)
      IMPLICIT NONE
      INCLUDE 'netcdf.inc'
      integer :: status, ncid,varid
      integer :: IT,JT,KT,TT,LT
      REAL(KIND=4),DIMENSION(IT,JT,KT,TT) :: idata
      character(200) :: NCDATA
      character(LT) :: var

      status = nf_open(NCDATA,nf_nowrite,ncid)
      status = nf_inq_varid(ncid,var,varid)
      status = nf_get_var_real(ncid,varid,idata)
      print*, ncid, varid, var
      IF( STATUS .NE. NF_NOERR) CALL HANDLE_ERR(STATUS)
      END SUBROUTINE NCGetVar4d

      SUBROUTINE NCGetVar3d (idata,IT,JT,TT,LT,var,NCDATA)
      IMPLICIT NONE
      INCLUDE 'netcdf.inc'
      integer :: status, ncid,varid,dimid
      integer :: IT,JT,TT,LT
      REAL(KIND=4),DIMENSION(IT,JT,TT) :: idata
      character(200) :: NCDATA
      character(LT) :: var

      status = nf_open(NCDATA,nf_nowrite,ncid)
      status = nf_inq_varid(ncid,var,varid)
      status = nf_get_var_real(ncid,varid,idata)

      print*, ncid, varid, var
      IF( STATUS .NE. NF_NOERR) CALL HANDLE_ERR(STATUS)
      END SUBROUTINE NCGetVar3d

      SUBROUTINE NCGetVar2d (idata,IT,JT,LT,var,NCDATA)
      IMPLICIT NONE
      INCLUDE 'netcdf.inc'
      integer :: status, ncid,varid
      integer :: IT,JT,LT
      REAL,DIMENSION(IT,JT) :: idata
      character(200) :: NCDATA
      character(LT) :: var

      status = nf_open(NCDATA,nf_nowrite,ncid)
      status = nf_inq_varid(ncid,var,varid)
      status = nf_get_var_real(ncid,varid,idata)
      print*, ncid, varid, var
      IF( STATUS .NE. NF_NOERR) CALL HANDLE_ERR(STATUS)
      END SUBROUTINE NCGetVar2d

      SUBROUTINE NCGetVar1d (idata,XT,LT,var,NCDATA)
      IMPLICIT NONE
      INCLUDE 'netcdf.inc'
      integer :: status, ncid,varid
      integer :: XT,LT
      REAL(KIND=4),DIMENSION(XT) :: idata
      character(200) :: NCDATA
      character(LT) :: var

      status = nf_open(NCDATA,nf_nowrite,ncid)
      status = nf_inq_varid(ncid,var,varid)
      status = nf_get_var_real(ncid,varid,idata)
      print*, ncid, varid, var
      IF( STATUS .NE. NF_NOERR) CALL HANDLE_ERR(STATUS)
      END SUBROUTINE NCGetVar1d

      SUBROUTINE HANDLE_ERR(STATUS)
      INCLUDE 'netcdf.inc'
      INTEGER :: STATUS

      PRINT*,NF_STRERROR(STATUS)
      RETURN
      ENDSUBROUTINE HANDLE_ERR


!***************************************************************************************!
!                                                                                       !
!  This special program is Finite differential scheme matrix code.                      !
!  For example, if there is a certain matrix, it can be differenciated by horizontal    !
!  direction.                                                                           !
!                                                                                       !
!  In near future, it can be further extended to various differenctial scheme.          !
!                                                                                       !
!                                                     2015. 10. 18                      !
!                                                       written by James (Jaedeok, LEE) !
!***************************************************************************************!

      SUBROUTINE FDM_DIFF_CODE_DX (LAT,LON,IDATA,ODATA)
      USE parameter_dsize
      IMPLICIT NONE
      INTEGER :: i,j,NX,NY
      REAL(KIND=8) :: DLAMB,SUM
      REAL(KIND=4),DIMENSION(0:IB1),intent(in) :: LON
      REAL(KIND=4),DIMENSION(-JB:JB),intent(in) :: LAT
      REAL(KIND=4),DIMENSION(0:IB1,-JB:JB),intent(in) :: IDATA
      REAL(KIND=8),DIMENSION(0:IB1,-JB:JB) :: IDATA8
      REAL(KIND=8),DIMENSION(0:IB1,-JB:JB),intent(out) :: ODATA
      REAL(kind= 8), parameter :: PI=3.14159265358979312D-00,PI180=PI/180.d0
      REAL(kind= 8), parameter :: RADIUS=6371220.

      IDATA8(:,:)=IDATA(:,:) 

      Do j = -JB,JB
      Do i = 0,IB1
       DLAMB = (2.*PI*RADIUS*DCOS(LAT(j)*PI180))/IB
      IF( I == 0  ) THEN
       sum = (IDATA8(1,J)-IDATA8(IB1,J))/(2.*DLAMB)
      ELSE IF( I == IB1 ) THEN
       sum = (IDATA8(0,J)-IDATA8(IB1-1,J))/(2.*DLAMB)
      ELSE
       sum = (IDATA8(I+1,J)-IDATA8(I-1,J))/(2.*DLAMB)
      ENDIF

      ODATA(i,j) = sum 
      ENDDO
      ENDDO
      ENDSUBROUTINE FDM_DIFF_CODE_DX

!***************************************************************************************!
!                                                                                       !
!  This special program is Finite differential scheme matrix code.                      !
!  For example, if there is a certain matrix, it can be differenciated by horizontal    !
!  direction.                                                                           !
!                                                                                       !
!  In near future, it can be further extended to various differenctial scheme.          !
!                                                                                       !
!                                                     2015. 10. 18                      !
!                                                       written by James (Jaedeok, LEE) !
!***************************************************************************************!

      SUBROUTINE FDM_DIFF_CODE_DY (LAT,LON,IDATA,ODATA)
      USE parameter_dsize
      IMPLICIT NONE
      INTEGER :: i,j,NX,NY
      REAL(KIND=8) :: SUM,DTHETA
      REAL(KIND=4),DIMENSION(0:IB1),intent(in) :: LON
      REAL(KIND=4),DIMENSION(-JB:JB),intent(in) :: LAT
      REAL(KIND=4),DIMENSION(0:IB1,-JB:JB),intent(in) :: IDATA
      REAL(KIND=8),DIMENSION(0:IB1,-JB:JB) :: IDATA8
      REAL(KIND=8),DIMENSION(0:IB1,-JB:JB),intent(out) :: ODATA
      REAL(kind= 8), parameter :: PI=3.14159265358979312D-00,PI180=PI/180.d0
      REAL(kind= 8), parameter :: RADIUS=6371220.
 
      IDATA8(:,:)=IDATA(:,:) 

      Do j = -JB,JB
      Do i = 0,IB1

       DTHETA = (PI*RADIUS)/JBW
      IF( J == -JB .or. J == JB ) THEN
       sum = 0.
      ELSE
       sum = (IDATA8(I,J+1)*DCOS(LAT(J+1)*PI180)-IDATA8(I,J-1)*DCOS(LAT(J-1)*PI180))/(2.*DTHETA*DCOS(LAT(J)*PI180))
      ENDIF

      ODATA(i,j) = sum 
      ENDDO
      ENDDO

      ENDSUBROUTINE FDM_DIFF_CODE_DY



      SUBROUTINE DATE_INCREASE(ISYEAR,ISMONS,ISDAYS,ISHOUR)
      IMPLICIT NONE
      INTEGER :: ISYEAR,ISMONS,ISDAYS,ISHOUR
      INTEGER,DIMENSION(12) :: CMONTHS,LMONTHS,MONTHS
      !data cmonths / 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30/
      !data lmonths / 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30/
      data cmonths / 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31/
      data lmonths / 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31/
      
       ISHOUR = ISHOUR + 6
      IF ( MOD(ISYEAR,400) ==  0 .or.  (MOD(ISYEAR,4) == 0  .and. MOD(ISYEAR,100) /= 0) ) then

 
       IF (ISHOUR .GE. 24 ) THEN
         ISHOUR = ISHOUR - 24
         ISDAYS = ISDAYS + 1      
       ENDIF
       IF (ISDAYS > LMONTHS(ISMONS))THEN
        ISDAYS = ISDAYS - LMONTHS(ISMONS)
        ISMONS = ISMONS+1
       ENDIF
       IF (ISMONS > 12)THEN
        ISMONS = ISMONS-12
        ISYEAR= ISYEAR + 1
       ENDIF
       
      ELSE

       IF (ISHOUR .GE. 24 ) THEN
        ISHOUR = ISHOUR - 24
        ISDAYS = ISDAYS + 1      
       ENDIF
       IF (ISDAYS > CMONTHS(ISMONS))THEN
        ISDAYS = ISDAYS - CMONTHS(ISMONS) 
        ISMONS = ISMONS+1
       ENDIF
       IF (ISMONS > 12)THEN
        ISMONS = ISMONS-12
        ISYEAR= ISYEAR + 1
       ENDIF
      ENDIF
       
      ENDSUBROUTINE DATE_INCREASE
       
      SUBROUTINE COSINE_DIS(BLAT,BLON,MLAT,MLON,distan)
       IMPLICIT NONE
       REAL(KIND=8),PARAMETER :: R=6371.220D0
       REAL(KIND=4) :: BLAT,BLON,MLON,MLAT
       REAL(KIND=8) :: D_lat,D_lat1,D_lon,pi
       REAL(KIND=4) :: distan

       pi=ATAN(1.0)*4
       D_lat=90-BLAT
       D_lat1=90-MLAT
       D_lon=BLON-MLON

       distan=DACOS(DCOS(D_lat*pi/180.)*DCOS(D_lat1*pi/180.)+           &
      DSIN(D_lat*pi/180.)*DSIN(D_lat1*pi/180.)*DCOS(D_lon*pi/180.))*R

       IF( BLAT == MLAT .and. BLON == MLON) distan =0.
        
         
      ENDSUBROUTINE COSINE_DIS
 
      SUBROUTINE Azimuthal_AV(DATA1,KT,DATA2)
      IMPLICIT NONE
      INTEGER :: T,K,R,THETA,TT,KT
      REAL(KIND=4) :: SUM1
      REAL,DIMENSION(0:360,0:359,KT) :: DATA1
      REAL,DIMENSION(0:360,KT) :: DATA2

      DO K = 1, KT
      DO R = 0, 360
      SUM1=0.
      DO THETA = 0, 359
      SUM1 = SUM1 +DATA1(r,theta,k)/360.
      ENDDO
      DATA2(R,K) = SUM1
      ENDDO
      ENDDO
      ENDSUBROUTINE Azimuthal_AV

      SUBROUTINE REVERS (IDATA,ODATA)
      use parameter_dsize
      IMPLICIT NONE
      INTEGER :: I,J,K
      REAL,DIMENSION(0:IB1,-JB:JB) :: IDATA,ODATA

      DO J = JB,-JB,-1
       ODATA(:,-J) = IDATA(:,J)
      ENDDO
      ENDSUBROUTINE REVERS

      SUBROUTINE FILTERING_SUBs(fgrid1,gamma0,LAP_DIM)
       USE parameter_dsize
       USE parameter_wsize
       IMPLICIT NONE
       INTEGER :: LAP_DIM,I,J
       REAL(KIND=8) :: gamma0
       REAL(KIND=8), DIMENSION(0:IB1,-JB:JB) :: fgrid1
       REAL(kind=8), DIMENSION(-MT:MT,-JB:JB) :: F1

      CALL FFT_DFS_235_SC_FullGrid_x_trans                              &
      ( +1, fgrid1, F1, JBW, -1 ) ! is=1:->Wa, ip=1:cut

      CALL ZVISFILT8_JS2_Re_FEM( F1, gamma0, LAP_DIM )

      CALL FFT_DFS_235_SC_FullGrid_x_trans                              &
      ( -1, fgrid1, F1, JBW, -1 ) ! is=1:->Wa, ip=1:cut

      ENDSUBROUTINE FILTERING_SUBs

      SUBROUTINE SORTING_DATE(BASIN_INPUT,BASIN_OUTPUT)
      IMPLICIT NONE
      INTEGER :: ICOUNT1,ICOUNT2,IMAX,T,I,J,A1
      INTEGER :: YEAR,MONTH,DAY,HOUR
      REAL :: LON1,LAT1,LON2,LAT2,DISTANCE
      CHARACTER(100) :: BASIN_INPUT,BASIN_OUTPUT
      INTEGER,ALLOCATABLE,DIMENSION(:) :: YEAR1,MONS1,DAYS1,HOUR1
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: CLON1,CLAT1,MWIND1
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: MSLP1,MVOR1
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: PSI1

       print*, TRIM(BASIN_INPUT)
      OPEN(990, FILE=TRIM(BASIN_INPUT))
      OPEN(991, FILE=TRIM(BASIN_OUTPUT))

      ICOUNT1=0
      DO
      READ(990,*,IOSTAT=A1)
      IF(A1<0) exit
      ICOUNT1=ICOUNT1+1
      ENDDO
      REWIND 990
      WRITE(*,*) " SORTING PROCEDURE FOR NH", ICOUNT1

      ALLOCATE(YEAR1(ICOUNT1),MONS1(ICOUNT1),DAYS1(ICOUNT1))
      ALLOCATE(HOUR1(ICOUNT1),CLON1(ICOUNT1),CLAT1(ICOUNT1))
      ALLOCATE(MWIND1(ICOUNT1),MSLP1(ICOUNT1),MVOR1(ICOUNT1))
      ALLOCATE(PSI1(ICOUNT1))

      DO T = 1, ICOUNT1
       READ(990,'(I4.4,1x,3(I2.2,1x),1x,5(f8.2,1x),E13.4)')             &
                  YEAR1(T),MONS1(T),DAYS1(T),HOUR1(T),CLAT1(T),CLON1(T),&
                  MSLP1(T),MWIND1(T),PSI1(T),MVOR1(T)
       WRITE(*,'(I4.4,1x,3(I2.2,1x),1x,5(f8.2,1x),E13.4)')              &
                  YEAR1(T),MONS1(T),DAYS1(T),HOUR1(T),CLAT1(T),CLON1(T),&
                  MSLP1(T),MWIND1(T),PSI1(T),MVOR1(T)
      ENDDO

      DO T = 1, ICOUNT1
       IF( YEAR1(T) == -999 ) GOTO 223

        YEAR=YEAR1(T)
        MONTH=MONS1(T)
        DAY=DAYS1(T)
        HOUR=HOUR1(T)
        LON1=CLON1(T)
        LAT1=CLAT1(T)   

       CALL DATE_INCREASE(YEAR,MONTH,DAY,HOUR)
       IMAX=T+10800
       IF(IMAX >= ICOUNT1) IMAX=ICOUNT1
        
       ICOUNT2=1
       DO I = T+1,IMAX
       IF( YEAR == YEAR1(I) .and. MONTH == MONS1(I) .and.           &
            DAY == DAYS1(I) .and.  HOUR == HOUR1(I) ) THEN
        LON2 =CLON1(I); LAT2 =CLAT1(I)
        CALL COSINE_DIS(LAT1,LON1,LAT2,LON2,DISTANCE)
        IF(  DISTANCE .le. 444. ) THEN
         ICOUNT2=ICOUNT2+1  !FOR DURATION TIME
         YEAR=YEAR1(I)
         MONTH=MONS1(I)
         DAY=DAYS1(I)
         HOUR=HOUR1(I)
        CALL DATE_INCREASE(YEAR,MONTH,DAY,HOUR)
         LAT1=CLAT1(I);LON1=CLON1(I)
        ENDIF
       ENDIF
      ENDDO ! ENDDO FOR I

      IF( ICOUNT2>=5) THEN

       WRITE(991,'(I4.4,1x,3(I2.2,1x),1x,5(f8.2,1x),E13.4)')            &
                  YEAR1(T),MONS1(T),DAYS1(T),HOUR1(T),CLAT1(T),CLON1(T),&
                  MSLP1(T),MWIND1(T),PSI1(T),MVOR1(T)

        YEAR=YEAR1(T)
        MONTH=MONS1(T)
        DAY=DAYS1(T)
        HOUR=HOUR1(T)
        CALL DATE_INCREASE(YEAR,MONTH,DAY,HOUR)
        LON1=CLON1(T);LAT1=CLAT1(T)   

      DO I = T+1,IMAX
       IF( YEAR == YEAR1(I) .and. MONTH == MONS1(I) .and.           &
            DAY == DAYS1(I) .and.  HOUR == HOUR1(I) ) THEN
        LON2 =CLON1(I); LAT2 =CLAT1(I)
        CALL COSINE_DIS(LAT1,LON1,LAT2,LON2,DISTANCE)
        IF(  DISTANCE .le. 444. ) THEN

       WRITE(991,'(I4.4,1x,3(I2.2,1x),1x,5(f8.2,1x),E13.4)')            &
                  YEAR1(I),MONS1(I),DAYS1(I),HOUR1(I),CLAT1(I),CLON1(I),&
                  MSLP1(I),MWIND1(I),PSI1(I),MVOR1(I)

         YEAR=YEAR1(I)
         MONTH=MONS1(I)
         DAY=DAYS1(I)
         HOUR=HOUR1(I)
         CALL DATE_INCREASE(YEAR,MONTH,DAY,HOUR)
         LAT1=CLAT1(I);LON1=CLON1(I)
        YEAR1(I) = -999
        ENDIF
       ENDIF
      ENDDO ! ENDDO FOR I
      ENDIF
     
 223  CONTINUE
      ENDDO ! ENDDO FOR T
      CLOSE(990);CLOSE(991)
      DEALLOCATE(YEAR1,MONS1,DAYS1,HOUR1,CLON1,CLAT1,MWIND1,MSLP1,      &
                   MVOR1,PSI1)
      ENDSUBROUTINE 

      SUBROUTINE TCMATCHING(BASIN_INPUT,BEST_INPUT,BASIN_OUTPUT)
      IMPLICIT NONE
      INTEGER :: ICOUNT1,ICOUNT2,IMAX,T,I,J,A1
      INTEGER :: YEAR,YEAR4,MONTH,DAY,HOUR,INDEX
      REAL :: LON1,LAT1,LON2,LAT2,DISTANCE
      CHARACTER(100) :: BASIN_INPUT,BASIN_OUTPUT,BEST_INPUT
      INTEGER,ALLOCATABLE,DIMENSION(:) :: YEAR1,MONS1,DAYS1,HOUR1,TCDET1
      INTEGER,ALLOCATABLE,DIMENSION(:) :: JYEAR,JMONS,JDAYS,JHOUR,JTC
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: JLAT,JLON,JWMS,JMSLP
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: CLON1,CLAT1,MWIND1,TAA1
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: MSLP1,MVOR1
      INTEGER,ALLOCATABLE,DIMENSION(:) :: LAND1

!-----------------------------------------------------------------------
!     TC DETERMINATION COMPARED TO BEST TRACK FOR NH
!-----------------------------------------------------------------------

      OPEN(850, FILE=TRIM(BASIN_INPUT))
      OPEN(852, FILE=TRIM(BASIN_OUTPUT))

      ICOUNT1=0
      DO
      READ(850,*,IOSTAT=A1)
      IF(A1<0) exit
      ICOUNT1=ICOUNT1+1
      ENDDO
      REWIND 850
      WRITE(*,*) "TCDETERMINING PROCEDURE FOR NH", ICOUNT1

      ALLOCATE(YEAR1(ICOUNT1),MONS1(ICOUNT1),DAYS1(ICOUNT1))
      ALLOCATE(HOUR1(ICOUNT1),CLON1(ICOUNT1),CLAT1(ICOUNT1))
      ALLOCATE(MWIND1(ICOUNT1),TAA1(ICOUNT1),MSLP1(ICOUNT1))
      ALLOCATE(MVOR1(ICOUNT1), LAND1(ICOUNT1))

      DO T = 1, ICOUNT1
       READ(850,'(I4.4,1x,3(I2.2,1x),1X,5(f8.2,1x),E13.4,2x,I)')        &
         YEAR1(T),MONS1(T),DAYS1(T),HOUR1(T),CLAT1(T),CLON1(T),         &
        MWIND1(T),MSLP1(T), TAA1(T),MVOR1(T),LAND1(T)
      ENDDO

      DO T = 1, ICOUNT1
       OPEN(851,FILE=TRIM(BEST_INPUT))

       DO 
       READ(851,*,IOSTAT=A1) YEAR4, ICOUNT2
       IF(A1<0) GOTO 110

       ALLOCATE(JYEAR(ICOUNT2),JMONS(ICOUNT2),JDAYS(ICOUNT2))
       ALLOCATE(JHOUR(ICOUNT2),JTC(ICOUNT2),JLAT(ICOUNT2))
       ALLOCATE(JLON(ICOUNT2),JWMS(ICOUNT2),JMSLP(ICOUNT2))

      DO I = 1,ICOUNT2
        READ(851,*) JYEAR(I),JMONS(I),JDAYS(I),JHOUR(I), JTC(I),        &
                     JLAT(I), JLON(I), JWMS(I),JMSLP(I) 
         IF( YEAR1(T) == JYEAR(I) .and. MONS1(T) == JMONS(I) .and.      &
             DAYS1(T) == JDAYS(I) .and. HOUR1(T) == JHOUR(I) ) THEN
             CALL COSINE_DIS(CLAT1(T),CLON1(T),JLAT(I),JLON(I),DISTANCE)
          IF( JTC(I) == 1 .and. DISTANCE .LE. 333. ) THEN
            IF( JWMS(I) <= 32.89) INDEX=1   ! TS scale
            IF( JWMS(I) > 32.89 .and. JWMS(I) <= 48.83 ) INDEX=2 
            IF( JWMS(I) > 48.83) INDEX=3 
            WRITE(852,'(I4.4,1x,3(I2.2,1x),1X,5(f8.2,1x),E13.4,2x,I1,2x,I)')      &
            YEAR1(T),MONS1(T),DAYS1(T),HOUR1(T),CLAT1(T),CLON1(T),       &
            MWIND1(T),MSLP1(T),TAA1(T),MVOR1(T),INDEX,LAND1(T)
            WRITE(*,'(I4.4,1x,3(I2.2,1x),1X,5(f8.2,1x),E13.4,2x,I1,2x,I)')      &
            YEAR1(T),MONS1(T),DAYS1(T),HOUR1(T),CLAT1(T),CLON1(T),       &
            MWIND1(T),MSLP1(T),TAA1(T),MVOR1(T),INDEX,LAND1(T)
            DEALLOCATE(JYEAR,JMONS,JDAYS,JHOUR,JTC,JLAT,JLON,JWMS,JMSLP)
            GOTO 423
           ENDIF
          ENDIF
       ENDDO
            DEALLOCATE(JYEAR,JMONS,JDAYS,JHOUR,JTC,JLAT,JLON,JWMS,JMSLP)
       ENDDO ! IMPLICITE DO
  110  CONTINUE
         WRITE(852,'(I4.4,1x,3(I2.2,1x),1X,5(f8.2,1x),E13.4,2x,I1,2x,I)')      &
          YEAR1(T),MONS1(T),DAYS1(T),HOUR1(T),CLAT1(T),CLON1(T),       &
          MWIND1(T),MSLP1(T),TAA1(T),MVOR1(T),0,LAND1(T)
  423  CONTINUE
       CLOSE(851)
       ENDDO !ENDDO FOR T
      DEALLOCATE(YEAR1,MONS1,DAYS1,HOUR1,CLON1,CLAT1,MWIND1,TAA1,MSLP1)
      DEALLOCATE(MVOR1,LAND1)
      CLOSE(850);CLOSE(851);CLOSE(852)
      ENDSUBROUTINE TCMATCHING

      SUBROUTINE RSMCFORMAT(BASIN_INPUT,BASIN_OUTPUT) 
      USE parameter_dsize
      IMPLICIT NONE
      INTEGER :: ICOUNT1,ICOUNT2,ICOUNT3,ICOUNT4,IMAX,P,Q,T,I,J,A1
      INTEGER :: YEAR,YEAR4,MONTH,DAY,HOUR
      REAL :: LON1,LAT1,LON2,LAT2,DISTANCE
      CHARACTER(100) :: BASIN_INPUT,BASIN_OUTPUT
      INTEGER,ALLOCATABLE,DIMENSION(:) :: YEAR1,MONS1,DAYS1,HOUR1,TCDET1
      INTEGER,ALLOCATABLE,DIMENSION(:) :: JYEAR,JMONS,JDAYS,JHOUR,JTC
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: JLAT,JLON,JWMS,JMSLP
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: CLON1,CLAT1,MWIND1,TAA1
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: MSLP1,MVOR1,MTPRECIP1

      OPEN(850, FILE=TRIM(BASIN_INPUT))
      OPEN(851, FILE=TRIM(BASIN_OUTPUT))

      ICOUNT1=0
      DO
      READ(850,*,IOSTAT=A1)
      IF(A1<0) exit
      ICOUNT1=ICOUNT1+1
      ENDDO
      WRITE(*,*) " SORTING TO RSMCTYPE ", ICOUNT1
      REWIND 850

      ALLOCATE(YEAR1(ICOUNT1),MONS1(ICOUNT1),DAYS1(ICOUNT1))
      ALLOCATE(HOUR1(ICOUNT1),CLON1(ICOUNT1),CLAT1(ICOUNT1))
      ALLOCATE(MWIND1(ICOUNT1),MSLP1(ICOUNT1),MVOR1(ICOUNT1))
      ALLOCATE(MTPRECIP1(ICOUNT1))

      DO T = 1, ICOUNT1
      READ(850,'(I4.4,1x,3(I2.2,1x),1x,5(f8.2,1x),E13.4)')              &
       YEAR1(T),MONS1(T),DAYS1(T),HOUR1(T),CLAT1(T),CLON1(T),MSLP1(T),  &
      MWIND1(T),MTPRECIP1(T),MVOR1(T)
      ENDDO

      ICOUNT3=1
      DO T = 1, ICOUNT1
       IF( YEAR1(T) == -999 ) GOTO 225
       
       ICOUNT2=1
        YEAR=YEAR1(T)
        MONTH=MONS1(T)
        DAY=DAYS1(T)
        HOUR=HOUR1(T)
        CALL DATE_INCREASE(YEAR,MONTH,DAY,HOUR)
  
       IMAX=T+10800
       IF(IMAX >= ICOUNT1) IMAX=ICOUNT1
       DO I = T,IMAX 
       CALL COSINE_DIS(CLAT1(I),CLON1(I),CLAT1(I+1),CLON1(I+1),DISTANCE)
      
        IF (YEAR == YEAR1(I+1) .and. MONTH == MONS1(I+1) .and.          &
             DAY == DAYS1(I+1) .and. HOUR == HOUR1(I+1) .and. DISTANCE<= 444. ) THEN

         ICOUNT2=ICOUNT2 + 1
        CALL DATE_INCREASE(YEAR,MONTH,DAY,HOUR)
        ELSE 
         GOTO 226
        ENDIF
       ENDDO ! ENDDO FOR I
  226  CONTINUE

       IF(ICOUNT2>=5)THEN
         WRITE(851,'(I4.4,4x,2(I6,4x))') YEAR1(T), ICOUNT2, ICOUNT3
       DO P = T, T+ICOUNT2-1
        WRITE(851,'(I4.4,1x,3(I2.2,1x),1X,5(f8.2,1x),E13.4)')           &
        YEAR1(P),MONS1(P),DAYS1(P),HOUR1(P),CLAT1(P),CLON1(P),MSLP1(P), &
       MWIND1(P),MTPRECIP1(P),MVOR1(P)
        YEAR1(P) = -999
       ENDDO
         ICOUNT3=ICOUNT3+1
        GOTO 777
       ENDIF

  225  CONTINUE
  777  CONTINUE
       ENDDO  !ENDDO FOR T

       DEALLOCATE(YEAR1,MONS1,DAYS1,HOUR1,CLON1,CLAT1,MWIND1,MSLP1,MTPRECIP1,MVOR1)
       CLOSE(850);CLOSE(851)
      ENDSUBROUTINE RSMCFORMAT 

      SUBROUTINE FILTER_KOR_PENINSULA(BASIN_INPUT,BASIN_OUTPUT) 
      USE parameter_dsize
      IMPLICIT NONE
      INTEGER :: ICOUNT1,T,A1,ICOUNT2
      INTEGER :: YEAR,TCNUM,NUM
      CHARACTER(100) :: BASIN_INPUT,BASIN_OUTPUT
      INTEGER,ALLOCATABLE,DIMENSION(:) :: YEAR1,MONS1,DAYS1,HOUR1,TCDET1
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: CLON1,CLAT1,MWIND1,TAA1
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: MSLP1,MVOR1,MTPRECIP1
      LOGICAL :: KOR_PENIN,TCS

      OPEN(850, FILE=TRIM(BASIN_INPUT))
      OPEN(851, FILE=TRIM(BASIN_OUTPUT))

      NUM=0
!--------PRE-COUNT
      DO
       READ(850,*,IOSTAT=A1)  YEAR, ICOUNT1, TCNUM
       WRITE(*,*) YEAR, TCNUM, ICOUNT1
       IF(A1<0) exit
 
       ALLOCATE(YEAR1(ICOUNT1),MONS1(ICOUNT1),DAYS1(ICOUNT1))
       ALLOCATE(HOUR1(ICOUNT1),CLON1(ICOUNT1),CLAT1(ICOUNT1))
       ALLOCATE(MWIND1(ICOUNT1),MSLP1(ICOUNT1),MVOR1(ICOUNT1))
       ALLOCATE(MTPRECIP1(ICOUNT1))

       KOR_PENIN = .false.
       TCS = .false.
       ICOUNT2=0
      DO T = 1, ICOUNT1
       READ(850,'(I4,1x,3(I2,1x),1X,5(f8.2,1x),E13.4)')                 &
         YEAR1(T),MONS1(T),DAYS1(T),HOUR1(T),CLAT1(T),CLON1(T),         &
        MWIND1(T),MSLP1(T),MTPRECIP1(T),MVOR1(T)
        IF( CLAT1(T)>=30. .and. CLAT1(T) <= 45. .and.                  &
           CLON1(T)>=120. .and. CLON1(T) <= 135.  ) THEN
           ICOUNT2=ICOUNT2+1
        ENDIF
      ENDDO
          IF(ICOUNT2>= 1) KOR_PENIN=.true.

        IF( CLAT1(1)>=0. .and. CLAT1(1) < 30. .and.                  &
           CLON1(1)>=120. .and. CLON1(1) <= 180. ) THEN
             TCS = .true.
        ENDIF

      IF(KOR_PENIN == .true. .and. TCS == .false.) THEN     
       NUM=NUM+1
       WRITE(851,*) YEAR, ICOUNT1,NUM
       DO T = 1, ICOUNT1
        WRITE(851,'(I4,1x,3(I2,1x),1X,5(f8.2,1x),E13.4)')  &
          YEAR1(T),MONS1(T),DAYS1(T),HOUR1(T),CLAT1(T),CLON1(T),         &
         MWIND1(T),MSLP1(T),MTPRECIP1(T),MVOR1(T)
       ENDDO
      ENDIF
       DEALLOCATE(YEAR1,MONS1,DAYS1,HOUR1,CLON1,CLAT1,MWIND1,MSLP1,MTPRECIP1,MVOR1)
      ENDDO  
       CLOSE(850);CLOSE(851)
      ENDSUBROUTINE FILTER_KOR_PENINSULA

      SUBROUTINE FILTER_NH_SH(BASIN_INPUT,BASIN_OUTPUT1,BASIN_OUTPUT2) 
      USE parameter_dsize
      IMPLICIT NONE
      INTEGER :: ICOUNT1,T,A1,ICOUNT2,ICOUNT3
      INTEGER :: YEAR,TCNUM,NUM1,NUM2
      CHARACTER(100) :: BASIN_INPUT,BASIN_OUTPUT1,BASIN_OUTPUT2
      INTEGER,ALLOCATABLE,DIMENSION(:) :: YEAR1,MONS1,DAYS1,HOUR1,TCDET1
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: CLON1,CLAT1,MWIND1,TAA1
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: MSLP1,MVOR1,MTPRECIP1
      LOGICAL :: NH,SH

      OPEN(850, FILE=TRIM(BASIN_INPUT))
      OPEN(851, FILE=TRIM(BASIN_OUTPUT1))
      OPEN(852, FILE=TRIM(BASIN_OUTPUT2))

      NUM1=0
      NUM2=0
!--------PRE-COUNT
      DO
       READ(850,*,IOSTAT=A1)  YEAR, ICOUNT1, TCNUM
       WRITE(*,*) YEAR, TCNUM, ICOUNT1
       IF(A1<0) exit
 
       ALLOCATE(YEAR1(ICOUNT1),MONS1(ICOUNT1),DAYS1(ICOUNT1))
       ALLOCATE(HOUR1(ICOUNT1),CLON1(ICOUNT1),CLAT1(ICOUNT1))
       ALLOCATE(MWIND1(ICOUNT1),MSLP1(ICOUNT1),MVOR1(ICOUNT1))
       ALLOCATE(MTPRECIP1(ICOUNT1))

       NH = .false.
       SH = .false.
       ICOUNT2=0; ICOUNT3=0
      DO T = 1, ICOUNT1
       READ(850,'(I4,1x,3(I2,1x),1X,5(f8.2,1x),E13.4)')                 &
         YEAR1(T),MONS1(T),DAYS1(T),HOUR1(T),CLAT1(T),CLON1(T),         &
        MWIND1(T),MSLP1(T),MTPRECIP1(T),MVOR1(T)
        IF( CLAT1(T)>=10.) THEN
           ICOUNT2=ICOUNT2+1
        ELSEIF( CLAT1(T)<=-10.) THEN
           ICOUNT3=ICOUNT3+1
        ENDIF
      ENDDO
          IF(ICOUNT2>= 1) THEN
              NH=.true.
          ENDIF
          IF(ICOUNT3>= 1) THEN
              SH=.true.
          ENDIF

      IF( NH == .true. .and. SH == .false.) THEN     
       NUM1=NUM1+1
       WRITE(851,*) YEAR, ICOUNT1,NUM1
       DO T = 1, ICOUNT1
        WRITE(851,'(I4,1x,3(I2,1x),1X,5(f8.2,1x),E13.4)')  &
          YEAR1(T),MONS1(T),DAYS1(T),HOUR1(T),CLAT1(T),CLON1(T),         &
         MWIND1(T),MSLP1(T),MTPRECIP1(T),MVOR1(T)
       ENDDO
      ENDIF

      IF( NH == .false. .and. SH == .true.) THEN     
       NUM2=NUM2+1
       WRITE(852,*) YEAR, ICOUNT1,NUM2
       DO T = 1, ICOUNT1
        WRITE(852,'(I4,1x,3(I2,1x),1X,5(f8.2,1x),E13.4)')  &
          YEAR1(T),MONS1(T),DAYS1(T),HOUR1(T),CLAT1(T),CLON1(T),         &
         MWIND1(T),MSLP1(T),MTPRECIP1(T),MVOR1(T)
       ENDDO
      ENDIF

       DEALLOCATE(YEAR1,MONS1,DAYS1,HOUR1,CLON1,CLAT1,MWIND1,MSLP1,MTPRECIP1,MVOR1)
      ENDDO  
       CLOSE(850);CLOSE(851);CLOSE(852)
      ENDSUBROUTINE FILTER_NH_SH

      SUBROUTINE MONTHLY_FREQUENCY(BASIN_INPUT,BASIN_OUTPUT) 
      USE parameter_dsize
      IMPLICIT NONE
      INTEGER :: ICOUNT1,T,A1,M,J,Y
      INTEGER :: YEAR,TCNUM
      CHARACTER(100) :: BASIN_INPUT,BASIN_OUTPUT
      INTEGER,ALLOCATABLE,DIMENSION(:) :: YEAR1,MONS1,DAYS1,HOUR1,TCDET1
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: CLON1,CLAT1,MWIND1,TAA1
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: MSLP1,MVOR1,MTPRECIP1
      INTEGER,DIMENSION(13,12) :: MONTHLY

      OPEN(850, FILE=TRIM(BASIN_INPUT))
      OPEN(851, FILE=TRIM(BASIN_OUTPUT))
      MONTHLY(:,:)=0.

      DO
      READ(850,*,IOSTAT=A1)  YEAR, ICOUNT1, TCNUM
      WRITE(*,*) YEAR, TCNUM, ICOUNT1
      IF(A1<0) exit

      ALLOCATE(YEAR1(ICOUNT1),MONS1(ICOUNT1),DAYS1(ICOUNT1))
      ALLOCATE(HOUR1(ICOUNT1),CLON1(ICOUNT1),CLAT1(ICOUNT1))
      ALLOCATE(MWIND1(ICOUNT1),MSLP1(ICOUNT1),MVOR1(ICOUNT1))
      ALLOCATE(MTPRECIP1(ICOUNT1))

      DO T = 1, ICOUNT1
       READ(850,'(I4,1x,3(I2,1x),1X,5(f8.2,1x),E13.4)')                 &
         YEAR1(T),MONS1(T),DAYS1(T),HOUR1(T),CLAT1(T),CLON1(T),         &
        MWIND1(T),MSLP1(T),MTPRECIP1(T),MVOR1(T)
      ENDDO

       Y=YEAR1(1)-2009
      DO M = 1, 12
       IF( M == MONS1(1))THEN
         MONTHLY(Y,M)=MONTHLY(Y,M)+1
       ENDIF 
      ENDDO
       DEALLOCATE(YEAR1,MONS1,DAYS1,HOUR1,CLON1,CLAT1,MWIND1,MSLP1,MTPRECIP1,MVOR1)
      ENDDO  

      DO M = 1, 12
       WRITE(851,'(13(I5.5,2x))') MONTHLY(1:13,M)
      ENDDO
       CLOSE(850);CLOSE(851)
      ENDSUBROUTINE MONTHLY_FREQUENCY

      SUBROUTINE SEASONALITY(BASIN_INPUT,BASIN_OUTPUT1,BASIN_OUTPUT2,BASIN_OUTPUT3,BASIN_OUTPUT4) 
      USE parameter_dsize
      IMPLICIT NONE
      INTEGER :: ICOUNT1,T,A1,NUM
      INTEGER :: YEAR,DJF,MAM,JJA,SON
      CHARACTER(100) :: BASIN_INPUT,BASIN_OUTPUT1,BASIN_OUTPUT2,BASIN_OUTPUT3,BASIN_OUTPUT4
      INTEGER,ALLOCATABLE,DIMENSION(:) :: YEAR1,MONS1,DAYS1,HOUR1,TCDET1
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: CLON1,CLAT1,MWIND1,TAA1
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: MSLP1,MVOR1,MTPRECIP1
      REAL(KIND=4),DIMENSION(12) :: MONTHLY

      OPEN(850, FILE=TRIM(BASIN_INPUT))
      OPEN(851, FILE=TRIM(BASIN_OUTPUT1))
      OPEN(852, FILE=TRIM(BASIN_OUTPUT2))
      OPEN(853, FILE=TRIM(BASIN_OUTPUT3))
      OPEN(854, FILE=TRIM(BASIN_OUTPUT4))

!----------PRE-COUNT
     DJF=0;MAM=0;JJA=0;SON=0
      DO
      READ(850,*,IOSTAT=A1)  YEAR, ICOUNT1, NUM
      IF(A1<0) exit

      ALLOCATE(YEAR1(ICOUNT1),MONS1(ICOUNT1),DAYS1(ICOUNT1))
      ALLOCATE(HOUR1(ICOUNT1),CLON1(ICOUNT1),CLAT1(ICOUNT1))
      ALLOCATE(MWIND1(ICOUNT1),MSLP1(ICOUNT1),MVOR1(ICOUNT1))
      ALLOCATE(MTPRECIP1(ICOUNT1))

      DO T = 1, ICOUNT1
       READ(850,'(I4,1x,3(I2,1x),1X,5(f8.2,1x),E13.4)')                 &
         YEAR1(T),MONS1(T),DAYS1(T),HOUR1(T),CLAT1(T),CLON1(T),         &
        MWIND1(T),MSLP1(T),MTPRECIP1(T),MVOR1(T)
      ENDDO

      DO T = 1, ICOUNT1
       IF (MONS1(1) == 12 .or. MONS1(1) == 1 .or. MONS1(1) == 2 ) THEN
        IF(T==1) DJF=DJF+1
       ELSEIF (MONS1(1) == 3 .or. MONS1(1) == 4 .or. MONS1(1) == 5 ) THEN
        IF(T==1) MAM=MAM+1
       ELSEIF (MONS1(1) == 6 .or. MONS1(1) == 7 .or. MONS1(1) == 8 ) THEN
        IF(T==1) JJA=JJA+1
       ELSEIF (MONS1(1) == 9 .or. MONS1(1) == 10 .or. MONS1(1) == 11 ) THEN
        IF(T==1) SON=SON+1
       ENDIF
      ENDDO
       DEALLOCATE(YEAR1,MONS1,DAYS1,HOUR1,CLON1,CLAT1,MWIND1,MSLP1,MTPRECIP1,MVOR1)
      ENDDO
       CLOSE(850)

      OPEN(850, FILE=TRIM(BASIN_INPUT))

!------------REAL-COUNT
      DO
      READ(850,*,IOSTAT=A1)  YEAR, ICOUNT1, NUM
      IF(A1<0) exit

      ALLOCATE(YEAR1(ICOUNT1),MONS1(ICOUNT1),DAYS1(ICOUNT1))
      ALLOCATE(HOUR1(ICOUNT1),CLON1(ICOUNT1),CLAT1(ICOUNT1))
      ALLOCATE(MWIND1(ICOUNT1),MSLP1(ICOUNT1),MVOR1(ICOUNT1))
      ALLOCATE(MTPRECIP1(ICOUNT1))

      DO T = 1, ICOUNT1
       READ(850,'(I4,1x,3(I2,1x),1X,5(f8.2,1x),E13.4)')                 &
         YEAR1(T),MONS1(T),DAYS1(T),HOUR1(T),CLAT1(T),CLON1(T),         &
        MWIND1(T),MSLP1(T),MTPRECIP1(T),MVOR1(T)
      ENDDO

      DO T = 1, ICOUNT1
       IF (MONS1(1) == 12 .or. MONS1(1) == 1 .or. MONS1(1) == 2 ) THEN
       IF(T==1) WRITE(851,*) YEAR, ICOUNT1, DJF
       WRITE(851,'(I4,1x,3(I2,1x),1X,5(f8.2,1x),E13.4)')                 &
        YEAR1(T),MONS1(T),DAYS1(T),HOUR1(T),CLAT1(T),CLON1(T),MWIND1(T),MSLP1(T),MTPRECIP1(T),MVOR1(T)
       ELSEIF (MONS1(1) == 3 .or. MONS1(1) == 4 .or. MONS1(1) == 5 ) THEN
       IF(T==1) WRITE(852,*) YEAR, ICOUNT1, MAM
       WRITE(852,'(I4,1x,3(I2,1x),1X,5(f8.2,1x),E13.4)')                 &
        YEAR1(T),MONS1(T),DAYS1(T),HOUR1(T),CLAT1(T),CLON1(T),MWIND1(T),MSLP1(T),MTPRECIP1(T),MVOR1(T)
       ELSEIF (MONS1(1) == 6 .or. MONS1(1) == 7 .or. MONS1(1) == 8 ) THEN
       IF(T==1) WRITE(853,*) YEAR, ICOUNT1, JJA
       WRITE(853,'(I4,1x,3(I2,1x),1X,5(f8.2,1x),E13.4)')                 &
        YEAR1(T),MONS1(T),DAYS1(T),HOUR1(T),CLAT1(T),CLON1(T),MWIND1(T),MSLP1(T),MTPRECIP1(T),MVOR1(T)
       ELSEIF (MONS1(1) == 9 .or. MONS1(1) == 10 .or. MONS1(1) == 11 ) THEN
       IF(T==1) WRITE(854,*) YEAR, ICOUNT1, SON
       WRITE(854,'(I4,1x,3(I2,1x),1X,5(f8.2,1x),E13.4)')                 &
        YEAR1(T),MONS1(T),DAYS1(T),HOUR1(T),CLAT1(T),CLON1(T),MWIND1(T),MSLP1(T),MTPRECIP1(T),MVOR1(T)
       ENDIF
      ENDDO
       DEALLOCATE(YEAR1,MONS1,DAYS1,HOUR1,CLON1,CLAT1,MWIND1,MSLP1,MTPRECIP1,MVOR1)
      ENDDO
       CLOSE(850);CLOSE(851);CLOSE(852);CLOSE(853);CLOSE(854)
      ENDSUBROUTINE SEASONALITY

      SUBROUTINE ACCURACY(BASIN_RSMC,BEST,BEGINYEAR,FNL_TS,TS)
      IMPLICIT NONE
      INTEGER :: ICOUNT1,ICOUNT2,IMAX,T,I,J,A1,ID
      INTEGER :: YEAR,YEAR4,MONTH,DAY,HOUR,BEGINYEAR
      REAL :: TS,TY,FNL_TS
      REAL :: LON1,LAT1,LON2,LAT2,DISTANCE
      CHARACTER(100) :: BASIN_RSMC,BEST
      INTEGER,ALLOCATABLE,DIMENSION(:) :: YEAR1,MONS1,DAYS1,HOUR1,TCDET1
      INTEGER,ALLOCATABLE,DIMENSION(:) :: JYEAR,JMONS,JDAYS,JHOUR,JTC
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: JLAT,JLON,JWMS,JMSLP
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: CLON1,CLAT1,MWIND1,TAA1
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: MSLP1,MVOR1

!-----------------------------------------------------------------------
!     TC DETERMINATION COMPARED TO BEST TRACK FOR NH
!-----------------------------------------------------------------------

      TS=0.
      FNL_TS=0.

      ICOUNT2=0
       OPEN(851,FILE=TRIM(BEST))
      DO 
       READ(851,*,IOSTAT=A1) YEAR4, ICOUNT2
       IF(A1<0) GOTO 114

       ALLOCATE(JYEAR(ICOUNT2),JMONS(ICOUNT2),JDAYS(ICOUNT2))
       ALLOCATE(JHOUR(ICOUNT2),JTC(ICOUNT2),JLAT(ICOUNT2))
       ALLOCATE(JLON(ICOUNT2),JWMS(ICOUNT2),JMSLP(ICOUNT2))

      !Tropical storm = 34 knot
      !Typhoon  = 64 knot
      DO I = 1,ICOUNT2
        READ(851,*) JYEAR(I),JMONS(I),JDAYS(I),JHOUR(I), JTC(I),        &
                     JLAT(I), JLON(I), JWMS(I),JMSLP(I) 
!--------JTWC COUNT
        IF ( JYEAR(1) >= BEGINYEAR .and. JTC(I) >= 1 ) THEN 
           TS=TS+1 
        ENDIF
      ENDDO !ENDDO FOR I
       DEALLOCATE(JYEAR,JMONS,JDAYS,JHOUR,JTC,JLAT,JLON,JWMS,JMSLP)
      ENDDO !ENDDO FOR IMPLICIT
 114  CONTINUE
      CLOSE(851)

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      WRITE(*,*) " ACCURACY"
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

      OPEN(850, FILE=TRIM(BASIN_RSMC))

      ICOUNT1=0
      A1=0
      DO
      READ(850,*,IOSTAT=A1) YEAR4, ICOUNT1, ID
      IF(A1<0) GOTO 120

      ALLOCATE(YEAR1(ICOUNT1),MONS1(ICOUNT1),DAYS1(ICOUNT1))
      ALLOCATE(HOUR1(ICOUNT1),CLON1(ICOUNT1),CLAT1(ICOUNT1))
      ALLOCATE(MWIND1(ICOUNT1),MSLP1(ICOUNT1),TAA1(ICOUNT1))
      ALLOCATE(MVOR1(ICOUNT1),TCDET1(ICOUNT1))

      DO T = 1, ICOUNT1
       READ(850,'(I4.4,1x,3(I2.2,1x),1X,5(f8.2,1x),E13.4,2x,I1)')           &
       YEAR1(T),MONS1(T),DAYS1(T),HOUR1(T),CLAT1(T),CLON1(T),          &
        MWIND1(T),MSLP1(T), TAA1(T),MVOR1(T),TCDET1(T)
       
        IF ( YEAR1(1) >= BEGINYEAR .and. TCDET1(T) >= 1 ) THEN 
          FNL_TS=FNL_TS+1 
        ENDIF
      ENDDO ! ENDDO FOR T
      DEALLOCATE(YEAR1,MONS1,DAYS1,HOUR1,CLON1,CLAT1,MWIND1,MSLP1,TAA1, &
                 MVOR1,TCDET1)
      ENDDO ! ENDDO FOR IMPLICIT
 120  CONTINUE
      CLOSE(850)
      ENDSUBROUTINE ACCURACY

      SUBROUTINE GDMAP(BASIN_INPUT1,NX,NYH,LAT,LON,GMAP,DMAP)
      IMPLICIT NONE
      INTEGER :: ICOUNT1,ICOUNT2,IMAX,T,I,J,A1
      INTEGER :: YEAR4, NX,NYH
      CHARACTER(100) :: BASIN_INPUT1,BASIN_INPUT2
      INTEGER,ALLOCATABLE,DIMENSION(:) :: YEAR1,MONS1,DAYS1,HOUR1
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: CLON1,CLAT1,MWIND1
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: MSLP1,MVOR1,MTPRECIP1
      REAL(KIND=4),DIMENSION(NX) :: LON
      REAL(KIND=4),DIMENSION(-NYH:NYH) :: LAT
      REAL(KIND=4),DIMENSION(NX,-NYH:NYH) :: GMAP,DMAP

      GMAP(:,:)=0.
      DMAP(:,:)=0.
      OPEN(850, FILE=TRIM(BASIN_INPUT1))
      ICOUNT1=0
      A1=0
      DO
      READ(850,*,IOSTAT=A1) YEAR4, ICOUNT1
      IF(A1<0) GOTO 120

      ALLOCATE(YEAR1(ICOUNT1),MONS1(ICOUNT1),DAYS1(ICOUNT1))
      ALLOCATE(HOUR1(ICOUNT1),CLON1(ICOUNT1),CLAT1(ICOUNT1))
      ALLOCATE(MWIND1(ICOUNT1),MSLP1(ICOUNT1),MVOR1(ICOUNT1))
      ALLOCATE(MTPRECIP1(ICOUNT1))

      DO T = 1, ICOUNT1
       READ(850,'(I4,1x,3(I2,1x),1X,5(f8.2,1x),E13.4)')                 &
         YEAR1(T),MONS1(T),DAYS1(T),HOUR1(T),CLAT1(T),CLON1(T),         &
        MWIND1(T),MSLP1(T),MTPRECIP1(T),MVOR1(T)
      ENDDO

       DO J = -NYH,NYH
       DO I = 1, NX
         IF( CLAT1(1) >= LAT(J) .and. CLAT1(1) < LAT(J+1) .and.       &
             CLON1(1) >= LON(I) .and. CLON1(1) < LON(I+1) ) THEN
          GMAP(I,J)=GMAP(I,J)+1
         ENDIF
        ENDDO
        ENDDO

       DO J = -NYH,NYH
       DO I = 1, NX
         IF( CLAT1(ICOUNT1) >= LAT(J) .and. CLAT1(ICOUNT1) < LAT(J+1) .and.       &
             CLON1(ICOUNT1) >= LON(I) .and. CLON1(ICOUNT1) < LON(I+1) ) THEN
          DMAP(I,J)=DMAP(I,J)+1
         ENDIF
        ENDDO
        ENDDO

      DEALLOCATE(YEAR1,MONS1,DAYS1,HOUR1,CLON1,CLAT1,MWIND1,MSLP1,MVOR1,MTPRECIP1)
      ENDDO ! ENDDO FOR IMPLICIT
 120  CONTINUE
      CLOSE(850)
      ENDSUBROUTINE GDMAP

      SUBROUTINE VERTICAL_INTEGRATION(IDATA,PLEVS,K1,K2,ODATA)
      USE parameter_dsize
      IMPLICIT NONE
      INTEGER :: I,J,K,K1,K2
      REAL(KIND=4) :: SUM1
      REAL(KIND=4),DIMENSION(KB) :: PLEVS
      REAL(KIND=4),DIMENSION(0:IB1,-JB:JB,KB),intent(in) :: IDATA
      REAL(KIND=4),DIMENSION(0:IB1,-JB:JB),intent(out) :: ODATA

      DO J=-JB,JB
      DO I= 0,IB1
       SUM1=0.
       DO K=K1,K2-1
        SUM1=SUM1+0.5*(IDATA(I,J,K)+IDATA(I,J,K+1))*ABS(PLEVS(K+1)-PLEVS(K))/ABS(PLEVS(K2)-PLEVS(K1))
       ENDDO
      ODATA(I,J)=SUM1
      ENDDO
      ENDDO
      ENDSUBROUTINE

      SUBROUTINE NORMALIZE_DPSI_LAYER(DPSI,K1,K2)
      USE parameter_dsize
      IMPLICIT NONE

      INTEGER :: I,J,K,K1,K2,NPTS
      REAL(KIND=4) :: SUM2,SCALE
      REAL(KIND=4),DIMENSION(0:IB1,-JB:JB,KB) :: DPSI

      DO K=K1,K2

       SUM2=0.
       NPTS=0

       DO J=-JB,JB
       DO I=0,IB1
        SUM2=SUM2+DPSI(I,J,K)*DPSI(I,J,K)
        NPTS=NPTS+1
       ENDDO
       ENDDO

       IF(SUM2.GT.0.) THEN

        SCALE=SQRT(SUM2/FLOAT(NPTS))

        DO J=-JB,JB
        DO I=0,IB1
         DPSI(I,J,K)=DPSI(I,J,K)/SCALE
        ENDDO
        ENDDO

       ENDIF

      ENDDO

      ENDSUBROUTINE NORMALIZE_DPSI_LAYER

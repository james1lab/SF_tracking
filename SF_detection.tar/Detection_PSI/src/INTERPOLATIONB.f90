!23456789012345678901234567890123456789012345678901234567890123456789012
!*********************************************************************
!                                                                    *
!     Hyeong-Bin Cheong                                              *
!                                                                    *
!     Department of Environmental Atmospheric Sciences               *
!     Pukyong National University, Busan, Korea                      *
!                                                                    *
!--------------------------------------------------------------------*
!                                                                    *
!     25 APR 2014 : Interpolation to Polar-coordinate-grid           *
!                 : from NCEP grid data                              *
!                                                                    *
!                 : For use in Tropical Cyclone bogussing            *
!                                                                    *
!--------------------------------------------------------------------*
!                                                                    *
!*********************************************************************
      SUBROUTINE INTERPOLATION (isign,lon,lat,lon_TC_center,lat_TC_center       &
                             ,  psi_ncep1,psi_polar1)

!*********************************************************************
      USE parameter_pi
      USE parameter_dsize
      implicit none
      INTEGER,PARAMETER :: PIB=200, PJB=360, PIB1=PIB-1,PJB1=PJB-1
      !real(kind=4), dimension(0:IB1,-JB:JB) :: psi_ncep0
      real(kind=4), dimension(0:IB1,-JB:JB) :: psi_ncep1
      !real(kind=4), dimension(0:PIB, 0:PJB1) :: psi_polar0
      real(kind=4), dimension(0:PIB, 0:PJB1) :: psi_polar1
      real(kind=8), dimension(0:PIB,0:PJB1) :: lon_polar
      real(kind=8), dimension(0:PIB,0:PJB1) :: lat_polar
      real(kind=8), dimension(0:PIB) :: lon_phi_0_line
      real(kind=8), dimension(0:PIB) :: lat_phi_0_line
      real(kind=8), dimension(0:PIB) :: sum_1d
      real(kind=4), dimension(0:IB1) :: lon
      real(kind=4), dimension(-JB:JB) :: lat
!------
      real(kind=4) :: lon_TC_center, lat_TC_center
      real(kind=8) :: del_lon_ncep= 360.d0/ IB
      real(kind=8) :: del_lat_ncep= 180.d0/(JB*2)
      real(kind=8) :: dist_per_degree= 40000.d+03 / 360.d0
      real(kind=8) :: dist_per_radian
      real(kind=8) :: del_phi_polar= 360.d0/PJB
      real(kind=8) :: max_radi_polar
      real(kind=8) :: deg_of_max_radi_polar
      real(kind=8) :: del_radi_polar
      real(kind=8) :: del_degr_polar

!------
      real(kind=8) :: dist, deg_d, radius, phi
      real(kind=8) :: lon0, lat0, lon1, lat1, lon2, lat2
      real(kind=8) :: lon8, lat8, lon9, lat9
      real(kind=8) :: x0, y0, z0, x1, y1, z1, x2, y2, z2, xp, yp, zp
      real(kind=8) :: x0p, y0p, z0p
      real(kind=8) :: lon_pivot, lat_pivot
      real(kind=8) :: dx, dy, sum1, sum2,a1,a2,b1,b2
      integer      :: ibeg_TC_domain, jbeg_TC_domain
      integer      :: iend_TC_domain, jend_TC_domain
      integer      :: i, j, ii, jj, i9, j9, i9p1, j9p1, k, m, n
      integer      :: isign,icen, jcen
!      max_radi_polar = dist_per_degree * PIB  
      max_radi_polar = dist_per_degree * PIB * 0.027D0
      del_radi_polar = max_radi_polar / PIB
      dist_per_radian= 40000.d+03 / PI2

!     icen = NINT(lon_TC_center/ del_lon_ncep)
!     jcen = NINT(lat_TC_center/ del_lat_ncep)

      do i = 0, IB1
      if( lon_TC_center >= lon(i) .and. lon_TC_center < lon(i+1) ) then
           a1=abs(lon_TC_center - lon(i))
           a2=abs(lon_TC_center - lon(i+1))
           if( a2 >= a1 ) then
             icen = i 
           else
             icen = i+1 
           endif
       endif
      enddo 

      do j = -JB1, JB1 
      if( lat_TC_center >= lat(j) .and. lat_TC_center < lat(j+1) ) then
           b1=abs(lat_TC_center - lat(j))
           b2=abs(lat_TC_center - lat(j+1))
           if( b2 >= b1 ) then
             jcen = j 
           else
             jcen = j+1 
           endif
       endif
      enddo 

      
      ibeg_TC_domain = icen - iex*1.5
      iend_TC_domain = icen + iex*1.5
      jbeg_TC_domain = jcen - iex*1.5
      jend_TC_domain = jcen + iex*1.5

      deg_of_max_radi_polar= max_radi_polar / dist_per_degree
             del_degr_polar= deg_of_max_radi_polar / PIB


      write(*,*) ' lat=', lat(jcen)
      write(*,*) ' lon=', lon(icen)
!      write(*,*) ' del_lon_ncep=', del_lon_ncep
!      write(*,*) ' del_lat_ncep=', del_lat_ncep
!      write(*,*) ' ibeg_TC_domain=', ibeg_TC_domain
!      write(*,*) ' iend_TC_domain=', iend_TC_domain
!      write(*,*) ' jbeg_TC_domain=', jbeg_TC_domain
!      write(*,*) ' jend_TC_domain=', jend_TC_domain
!
!      write(*,*) '        max_radi_polar=', max_radi_polar
!      write(*,*) ' deg_of_max_radi_polar=', deg_of_max_radi_polar
!      write(*,*) '        del_degr_polar=', del_degr_polar
!      write(*,*) '        lon_TC_center =', lon_TC_center
!      write(*,*) '        lat_TC_center =', lat_TC_center

      if( isign == 1 ) then
       psi_polar1(:,:) = 0.d0
       psi_polar1(0,:) = psi_ncep1(icen,jcen)


!---- points on the meridian passing TC_center 

      do i=0,PIB

      lon_phi_0_line(i)= lon_TC_center
      lat_phi_0_line(i)= lat_TC_center - i * del_degr_polar

      end do

!-b-- rotation to make polar grids

      do j=0,PJB1

      call rotation_of_points_sphere_B                                  &
      (lon_phi_0_line, lat_phi_0_line, PIB+1,lon_TC_center * PI180,     &
       lat_TC_center * PI180, j*PI2/PJB,                                & ! rot_angle
       lon_polar(:,j), lat_polar(:,j))
      end do

!-e-- rotation to make polar grids

!-b-- interpolation to polar grids from NCEP-grid

      do j=0,PJB1
      do i=1,PIB

             i9  = lon_polar(i,j) / del_lon_ncep
             j9  = lat_polar(i,j) / del_lat_ncep

             i9p1= i9+1
             j9p1= j9+1

          if(i9p1>IB1) i9p1= i9p1-IB
          if(j9p1>JB ) stop ' invalid Data point: j9p1> JB '

!---- 4 points : (i9,j9) (i9+1,j9) (i9,j9+1) (i9+1,j9+1)

          dx= ( lon_polar(i,j) - i9 * del_lon_ncep ) / del_lon_ncep  !  [ 0<= dx <= 1 ]
          dy= ( lat_polar(i,j) - j9 * del_lat_ncep ) / del_lat_ncep

       sum1= psi_ncep1(i9,j9  ) * (1-dx) + psi_ncep1(i9p1,j9  ) * dx
       sum2= psi_ncep1(i9,j9p1) * (1-dx) + psi_ncep1(i9p1,j9p1) * dx

       psi_polar1(i,j)= sum1 * (1-dy) + sum2 * dy

      end do
      end do

      elseif (isign == -1) then
      psi_ncep1(:,:) = 0.
      psi_ncep1(icen,jcen) = psi_polar1(0,0) 

!-b-- interpolation to NCEP-grid from polar grid

         lon0= lon_TC_center
         lat0= lat_TC_center

           x0= DCOS( lat0 * PI180 ) * DCOS( lon0 * PI180 )
           y0= DCOS( lat0 * PI180 ) * DSIN( lon0 * PI180 )
           z0= DSIN( lat0 * PI180 )

           xp= 0.d0                 ! North-pole
           yp= 0.d0                 ! North-pole 
           zp= 1.d0

           x0p= y0 * zp - z0 * yp
           y0p= z0 * xp - x0 * zp
           z0p= x0 * yp - y0 * xp

           lon_pivot= DATAN2( y0p, x0p )                           ! perpendicular
           lat_pivot= DATAN2( z0p, DSQRT(x0p**2.d0+y0p**2.d0)  )   ! to Npole & TC

         lon1= lon_TC_center          ! of ref_line : phi=0 (north-south)
         lat1= lat_TC_center - 10.d0  ! arbitray degree
!
       call rotation_of_points_sphere_B                                 &  ! rotate towards N-pole
       (lon1,lat1,1,lon_pivot,lat_pivot,(90.d0-lat0)*PI180,lon8,lat8)

      do ii= ibeg_TC_domain, iend_TC_domain
      do jj= jbeg_TC_domain, jend_TC_domain

!--- (radi,phi) of NCEP grids 

         lon2= del_lon_ncep * ii      ! (lon,lat) of NCEP-grid
         lat2= del_lat_ncep * jj

           x2= DCOS( lat2 * PI180 ) * DCOS( lon2 * PI180 )
           y2= DCOS( lat2 * PI180 ) * DSIN( lon2 * PI180 )
           z2= DSIN( lat2 * PI180 )

            dist= DSQRT( (x2-x0)**2.d0 + (y2-y0)**2.d0 + (z2-z0)**2.d0 )
           deg_d= DASIN( dist/2.d0 ) * 2.d0 / PI180  ! degree
          radius= deg_d * dist_per_degree            ! = radius of polar coordinate

            i9  = radius / del_radi_polar
            i9p1= i9 + 1

         lon1= lon_TC_center          ! of ref_line : phi=0 (north-south)
         lat1= lat_TC_center - deg_d

         lon9= lon2 ; lat9= lat2

       call rotation_of_points_sphere_B                                 & ! rotate towards N-pole
       (lon9, lat9,1, lon_pivot, lat_pivot,(90.d0-lat0)*PI180,lon2,lat2)

           phi= lon2 - lon8  ! (degree)              ! align ref-line at longitude=0

           if(phi<  0.d0) phi= phi + 360.d0
           if(phi>=360.d0) phi= phi - 360.d0

            j9  = phi / del_phi_polar
            j9p1= j9 + 1

          if(i9p1>PIB ) goto 100
          if(j9p1>PJB1) j9p1= j9p1 - PJB

!---- 4 points : (i9,j9) (i9+1,j9) (i9,j9+1) (i9+1,j9+1)

          dx= ( radius - i9 * del_radi_polar ) / del_radi_polar  !  [ 0<= dx <= 1 ]
          dy= (    phi - j9 * del_phi_polar  ) / del_phi_polar   !  [ 0<= dy <= 1 ]

       sum1= psi_polar1(i9,j9)*(1-dx) + psi_polar1(i9p1,j9 ) * dx
       sum2= psi_polar1(i9,j9p1)*(1-dx)+psi_polar1(i9p1,j9p1) * dx

       psi_ncep1(ii,jj)= sum1 * (1-dy) + sum2 * dy  ! asymme  ! interpolated back to NECP data
  
  100 continue

      end do
      end do     
      psi_ncep1(icen,jcen) = psi_polar1(0,0)
      end if


!-e-- interpolation to NCEP-grid from polar grid

!*********************************************************************
      ENDSUBROUTINE INTERPOLATION
!*********************************************************************


!*********************************************************************
!                                                                    *
!     28 JAN 2014 : rotation of points on a sphere : method B        *
!                                                                    *
!--------------------------------------------------------------------*
!                                                                    *
!        lon ,lat  : coordinates of points (in) , in degree          *
!        lon1,lat1 : coordinates of points (out), in degree          *
!        maxn      ; # of points                                     *
!        rcenlon   : pivot point -lon,            in rad             *
!        rcenlat   : pivot point -lat,            in rad             *
!        rot0      : angle of counter-clockwise rotation, in rad     *
!                                                                    *
!        radius= 1                                                   *
!                                                                    *
!        F90 funct : atan2(y,x) = x + iy ... angle                   *
!*********************************************************************
      subroutine rotation_of_points_sphere_B                            &
      ( lon, lat, maxn, rcenlon, rcenlat, rot0, lon1, lat1 )
!--------------------------------------------------------------------!
      implicit none
      integer     , intent(in ) :: maxn
      real(kind=8), intent(in ) :: lon(maxn), lat(maxn)
      real(kind=8), intent(in ) :: rcenlon, rcenlat, rot0
      real(kind=8), intent(out) :: lon1(maxn), lat1(maxn)
!------
      real(kind=8), parameter   :: PI =   3.14159265358979312D-00
      real(kind=8), parameter   :: PI2=   PI*2
      real(kind=8), parameter   :: PI180= PI/180.d0
!------
      real(kind=8), dimension(maxn) :: x, y, z, xyarm, xzarm
      real(kind=8), dimension(maxn) :: xoc, yoc, zoc, cosbeta
      real(kind=8), dimension(maxn) :: xcd, ycd, zcd
      real(kind=8), dimension(maxn) :: xopcd, yopcd, zopcd
      real(kind=8)                  :: xp, yp, zp, cosrot0, sinrot0
      real(kind=8), dimension(maxn) :: xyangle, xzangle
!--------------------------------------------------------------------!

         lon1(:)= lon(:) * PI180
         lat1(:)= lat(:) * PI180

!-(1)-- [ sph 2 cart ]

      x(:)= DCOS(lat1(:)) * DCOS(lon1(:))
      y(:)= DCOS(lat1(:)) * DSIN(lon1(:))
      z(:)= DSIN(lat1(:))

       xp = DCOS(rcenlat) * DCOS(rcenlon)
       yp = DCOS(rcenlat) * DSIN(rcenlon)
       zp = DSIN(rcenlat)

!-(2)----------------------------------

      cosrot0= DCOS(rot0)
      sinrot0= DSIN(rot0)

      cosbeta(:)= xp * x(:) + yp * y(:) + zp * z(:)

          xoc(:)= xp * cosbeta(:)
          yoc(:)= yp * cosbeta(:)
          zoc(:)= zp * cosbeta(:)

          xcd(:)= x(:) - xoc(:)
          ycd(:)= y(:) - yoc(:)
          zcd(:)= z(:) - zoc(:)

        xopcd(:)= yp * zcd(:) - zp * ycd(:)
        yopcd(:)= zp * xcd(:) - xp * zcd(:)
        zopcd(:)= xp * ycd(:) - yp * xcd(:)

      x(:)= xoc(:) + xcd(:) * cosrot0 + xopcd(:) * sinrot0
      y(:)= yoc(:) + ycd(:) * cosrot0 + yopcd(:) * sinrot0
      z(:)= zoc(:) + zcd(:) * cosrot0 + zopcd(:) * sinrot0

!-(3)-- [ cart 2 sph ]

        xyarm(:)= dsqrt( x(:)**2.d0 + y(:)**2.d0 )

         lat1(:)= datan2( z(:), xyarm(:) )
         lon1(:)= datan2( y(:), x(:)     )

         lon1(:)= lon1(:) / PI180
         lat1(:)= lat1(:) / PI180

!*********************************************************************
      end subroutine rotation_of_points_sphere_B
!*********************************************************************


      Module PARAMETERS 
      IMPLICIT NONE
      REAL(KIND=8), PARAMETER :: G= 9.81
      REAL(KIND=8), PARAMETER :: PI=3.14159265358979312
      REAL(KIND=8), PARAMETER :: PI180=PI/180.
      REAL(KIND=8), PARAMETER :: RADIUS=6371220.D0
      ENDModule PARAMETERS 

      module parameter_pi
        implicit none
        integer, parameter :: real_04_300=selected_real_kind(P=04,R=300)&
                            , real_08_300=selected_real_kind(P=08,R=300)&
                            , real_16_300=selected_real_kind(P=16,R=300)
        real(kind= 4), parameter :: PI_04=3.141592741E-00
        real(kind= 8), parameter :: PI_08=3.14159265358979312D-00
        real(kind= 8), parameter :: PI=PI_08,PI2=PI*2,PI_2=PI/2.d0
        real(kind= 8), parameter :: PI180=PI/180.d0
      end module parameter_pi

!-----------------------------------------------------------------------
      module parameter_dsize
        implicit none
        integer,parameter :: KL=26
        integer,parameter :: IB=1440,JB=IB/4,KB=12, TB=1,IBH=IB/2
        !integer,parameter :: IB=192,JB=72,KB=26, TB=1,IBH=IB/2
        integer,parameter :: ib1=ib-1,jb1=jb-1,jbh=jb/2,jbw=jb*2
        integer,parameter :: iex= jb/4,iex1=iex-1,jbw1=jbw-1
      end module parameter_dsize

      module parameter_wsize
      USE parameter_dsize
        implicit none
        integer,parameter :: mt=IB/2,jl=(IB/2)-2,jlh=jl/2
      end module parameter_wsize

      module parameter_fsize
      USE parameter_dsize
        implicit none
        integer,parameter :: mt=IB/3,jl=IB/2,JL1=JL-1,jlh=jl/2,         &
                             JLHP=JLH+1, JLp1=JL+1,mth=mt/2
      end module parameter_fsize

      module parameter_sin_power_o_e
        implicit none 
        real(kind=8), parameter :: powero= 0.d0/1.0D+4
        real(kind=8), parameter :: powere= 1.d-00/1.D0
      end module parameter_sin_power_o_e

!-----------------------------------------------------------------------
      module parameter_earth
        implicit none
        real(kind=8),parameter :: radius = 6371220.D0
        real(kind=8),parameter ::  Omega = 7.292D-05
        real(kind=8),parameter ::  gravi = 9.800D0
        real(kind=8),parameter :: aOmega = radius*Omega
        real(kind=8),parameter :: aOmega2= aOmega**2
      end module parameter_earth

!-----------------------------------------------------------------------
      module common_trigono_metric_sphere
        use parameter_dsize
        implicit none
        real(kind=8), dimension(-jb:jb1)   :: SINLAT, TANLAT
        real(kind=8), dimension(-jb:jb1,4) :: COSLAT
      end module common_trigono_metric_sphere

!-----------------------------------------------------------------------
      module common_metrix
        use parameter_dsize
        use parameter_wsize
        real(kind=8),dimension(-MT:MT,-JB:JB) :: FWAVEJ
        real(kind=8),dimension(-MT:MT,3,0:JLH,2) :: AMATm,AMATm_
        real(kind=8),dimension(-MT:MT,3,0:JLH,2) :: DMATm,DMATm_
        real(kind=8),dimension(-MT:MT,0:JLH)  :: YMAT
        real(kind=8),dimension(0:JLH,2)  :: JCOL2JS
        real(kind=8),dimension(-MT:MT)   :: MSQUAR
        real(kind=8),dimension(-MT:MT,2) :: JL_mx
      end module common_metrix
      module common_highorder_filter_sphere
      USE parameter_dsize
      USE parameter_fsize
        implicit none
        real(kind=8), dimension(0:MT,3,0:JB,2) :: AMATm , DMATm
        real(kind=8), dimension(0:MT,3,0:JB,2) :: AMATm_, DMATm_
        real(kind=8), dimension(0:MT,3,0:JB,2) :: UMATm , UMATm_  ! u-stream
        real(kind=8), dimension(0:MT,3,0:JB,2) :: PMATm           ! u-stream
        real(kind=8), dimension(0:MT,3,0:JB,2) :: v1MATm, v2MATm  ! vor-(u,v)
        real(kind=8), dimension(0:MT,3,0:JB,2) :: ZMATm , ZMATm_
        real(kind=8), dimension(0:MT,3,0:JB,2) :: COS1m
        real(kind=8), dimension(0:JBW,0:JBW)   :: COSym0 , SINym0 ! in MAT_psi
!---
        real(kind=8), dimension(0:MT,3,0:JB,2) :: AMATm1_, DMATm1
!---
        real(kind=8), dimension(0:MT,5,0:JB,2) :: v5MATm          ! vor-(u,v)
        real(kind=8), dimension(0:MT,5,0:JB,2) :: ZMATm5, ZMATm5_
        real(kind=8), dimension(0:MT,5,0:JB,2) :: PMATm5          ! vor-(u,v)
        real(kind=8), dimension(0:MT,5,0:JB,2) :: UMATm5, UMATm5_
        real(kind=8), dimension(0:MT,5,0:JB,2) :: AMATm5 , DMATm5
        real(kind=8), dimension(0:MT,5,0:JB,2) :: AMATm5_, DMATm5_
!---
        real(kind=8), dimension(0:MT,3,0:JB,2) :: DMATmi_  ! 1st-order FEM
!       real(kind=8), dimension(0:MT,5,0:JB,2) :: DMATmi_  ! 2nd-order FEM
!---
        integer      :: adv_mx0= +1   ! (+1=m0, +2=all m) or (-1=none) : adv by spectral
!---
        real(kind=8) :: integ_pnm_s_cosk(0:JB,0:JB)  ! 0:JLH
        real(kind=8) ::       pnm_0_cosk(0:JB,0:JB)
!---
        integer      :: jcol2jS(0:JB,2)
        real(kind=8) :: msquar(-MT:MT)
        real(kind=8) :: rthetam(0:JBW), DELtheta(0:JBW)
        real(kind=8) :: ymat(-MT:MT,0:JB)
!       real(kind=8) :: FWAVEJ(-MT:MT,-JB:JB)   ! for FFT_DFS_235_SC
      end module common_highorder_filter_sphere
!--------------------------------------------------------------------c
      module common_legendre_m0
      USE parameter_dsize
        implicit none
        real(kind=8), dimension(0:(JBW*2+2)) :: dfact
        real(kind=8), dimension(0:(JBW*2+1),0:(JBW*2+1)) :: Qpnm,Spnm
      end module common_legendre_m0
!--------------------------------------------------------------------c
      module common_reduced_grid
      USE parameter_fsize
        implicit none
        integer      :: jlat(-MT:MT)
      end module common_reduced_grid  ! 16 MAY 2012
!--------------------------------------------------------------------c
      module common_SSPRK
        implicit none
        real(kind=8),parameter :: S11=3.D0/4.,S12=1.D0/4.,S13=1.D0/4.
        real(kind=8),parameter :: S21=1.D0/3.,S22=2.D0/3.,S23=2.D0/3.
      end module common_SSPRK
!--------------------------------------------------------------------c
!--------------------------------------------------------------------c
      module common_enm1_CosSinLat
      USE parameter_dsize
        implicit none
        real(kind=8), dimension(-JB:JB1  ) :: SINLAT5
        real(kind=8), dimension(-JB:JB1,2) :: COSLAT5
        real(kind=8), dimension(-JB:JB   ) :: SINLAT0
        real(kind=8), dimension(-JB:JB ,2) :: COSLAT0
      end module common_enm1_CosSinLat
!--------------------------------------------------------------------c
      module common_Z_GW_SZ2
        implicit none
        integer, parameter :: Ngrid= 36    ! Gaussian points
        real(kind=8) :: Z(Ngrid), GW(Ngrid), SZ2(Ngrid)
      end module common_Z_GW_SZ2

!c-beg-Module List ---------------------------------------------------c
!c--------------------------------------------------------------------c
!----
      module parameter_xdir_window
        implicit none
        integer, parameter :: MT= 600, IB= 600, MT1=MT-1, IB1=IB-1,IBH=IB/2, MTH= MT/2
! IB= 2^a 3^b 5^c for FFT &
      end module parameter_xdir_window

      module parameter_ydir_window
        implicit none
        integer, parameter :: JBW= 600, JBW1= JBW-1,JB = (JBW+1)/2, JBWp= JB*2
!! temp var= act not used JBW= even or odd  ! JBWp=even = dim of temp
!array in FFT
      end module parameter_ydir_window
!----
!c     u : IB=360, JBW=360, work1(0:IB,JBW)         FFT ... FullGrid
!c     v : IB=360, JBW=361, work1(0:IB1,JBW) ! IB1=IB-1 ... halfgrid
!c     w & others
!c       : IB=360, JBW=360, work1(0:IB1,JBW) ! IB1=IB-1 ... halfgrid
!c--------------------------------------------------------------------c
      module common_grid_boundary
        use parameter_xdir_window
        use parameter_ydir_window
!        real(kind=8) ::   lamb1=   0.d0,  lamb2=  45.d0
!        real(kind=8) ::  theta1= -10.d0, theta2= +30.d0  ! theta1>-90,
!        theta2<90
        real(kind=8) ::  rlamb1,  rlamb2
        real(kind=8) :: rtheta1, rtheta2
        real(kind=8) :: window_alph
        real(kind=8) :: rthetam(0:(JBW+1)), DELtheta(0:(JBW+1))
      end module common_grid_boundary
!c--------------------------------------------------------------------c
      module common_highorder_filter_window
        use parameter_xdir_window
        use parameter_ydir_window
        real(kind=8), dimension(0:MT,3,JBW) :: AMATm , DMATm
        real(kind=8), dimension(0:MT,3,JBW) :: AMATm_, DMATm_
        real(kind=8) :: msquar(0:MT)
        real(kind=8) :: ymat(0:MT,JBW)
      end module common_highorder_filter_window
!c----
!c-end-Module List ---------------------------------------------------c

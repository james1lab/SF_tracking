!23456789012345678901234567890123456789012345678901234567890123456789012
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c                                                                    c
c     Department of Environmental Atmospheric Sciences               c
c     Pukyong National University                                    c
c                                                                    c
c     Hyeong-Bin Cheong                                              c
c                                                                    c
c     01 Jan 2003                                                    c
c                                                                    c
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
!-----------------------------------------------------------------------
      subroutine sincos_meri
! ----------------------------------------------------------------------
       use parameter_pi
       use parameter_dsize
       use common_trigono_metric_sphere
       implicit none
       real(kind=8) :: dy,aa,bb
       integer :: j
! ----------------------------------------------------------------------

         DY = PI/JBW

      do j=0,JBW-1
         aa= DY * (j+0.5)
         bb= DY * (j+0.5-JB)
         SINLAT(j-JB  )= DSIN(bb)      ! SIN(LAT)
         COSLAT(j-JB,1)= DCOS(bb)      ! COS(LAT)
         COSLAT(j-JB,2)= DCOS(bb)**2.D0
         TANLAT(j-JB  )= DSIN(bb)/DCOS(bb)
      end do

! ----------------------------------------------------------------------
      end subroutine sincos_meri
!-----------------------------------------------------------------------

**********************************************************************
*     To give the UP-LIMIT truncation to escape from POLE PROBLEM    *
**********************************************************************
      SUBROUTINE POLECUT     ! To be free from POLE PROBLEM
       use parameter_dsize
       use parameter_wsize
       use common_trigono_metric_sphere
       use common_metrix
C--------------------------------------------------------------------C
      IMPLICIT  REAL*8 (A-H,O-Z)
C-----local-variable-------------------------------------------------C
      DIMENSION M_0_AMP(-JB:JB1)
      LOGICAL   JUSDOIT/.TRUE./
C--------------------------------------------------------------------C
          IF(JUSDOIT) THEN
             JUSDOIT=.FALSE.
C----
         pmm0= 1.d0
      DO k=1,MT

      END DO
         pmm0= pmm0**0.5d0

         write(*,*) ' (PMM(j=0))**0.5 = ', PMM0

          critj= 0.1D-13
            JJ7= 0
      DO J=1,JB1
            aaa= pmm0
         do mmm=1,MT
            aaa= aaa*COSLAT(J,1)
         end do
         if(aaa.LT.critj) then
            JJ7= J
            goto 111
         endif
      END DO
  111 continue
C----
!                                                JJ7= JB*0.67
       DO J=-JB,JB1
              mmm= (MT-0) * ( COSLAT(J,1)/COSLAT(JJ7,1) )**0.75d0
          M_0_AMP(J)= min(mmm,MT)
      END DO
      write(*,*) ' :----m-cut nearest Pole : ',mmm
      write(*,*) ' JJ7=                      ',JJ7
C----
       ENDIF
C
C---------------------------------------
C
      DO jj=-JB,JB1          ! delete more high wavenumbers
      DO mx=M_0_AMP(jj)+1,MT ! at higher LATITUDES = Fourier filter
         FWAVEJ(-mx,jj)= 0.
         FWAVEJ(+mx,jj)= 0.
      END DO
      END DO

C===========
      RETURN
      END
C
C
**********************************************************************
*                                                                    *
*     Laplacian of X = Y , Inverse Laplacian of Y = X                *
*     on the Spherical Domain including the Poles                    *
*                                                                    *
*    [CALL MAT200E] -> [CALL LAP200E]                                *
*                                                                    *
*     01 MAR 2005                                                    *
*                                                                    *
**********************************************************************
C                                     MSEL=0 : Laplacian TC1 -> AJX   
C                                          1 : Inverse                
C--------------------------------------------------------------------C
      SUBROUTINE LAP200E_JS2 ( TC1, AJX , MSEL )
       use parameter_pi
       use parameter_dsize
       use parameter_wsize
       use parameter_earth
       use common_trigono_metric_sphere
       use common_metrix
C--------------------------------------------------------------------C
      IMPLICIT  REAL*8 (A-H,O-Z)
C--------------------------------------------------------------------C
      DIMENSION TC1(-MT:MT,0:JL), AJX(-MT:MT,0:JL)
C--------------------------------------------------------------------C

C--------------------------------------------------------------------C
          IF(MSEL.eq.0) THEN           ! Laplacian of TC1 = AJX
C--------------------------------------------------------------------C

      DO js=1,2

c---- 1  To get YMAT, YMAT= DMAT*TC1

         do jcol=1,JLH-1
            jja= jcol2js(jcol-1,js) ! For jcol=1 js=1, jja=-1. This problem
            jjb= jcol2js(jcol  ,js) ! was cured by letting jcol2js(0,1)=+1,
            jjc= jcol2js(jcol+1,js) ! noticing [*MATm(1,1,js)=0] except for mx=0 js=2
          Do mx=-MT,MT
             a4= DMATm(mx,1,jcol,js)
             a5= DMATm(mx,2,jcol,js)
             a6= DMATm(mx,3,jcol,js) 
             ace=(a5+msquar(mx))*TC1(mx,jjb)
            YMAT(mx,jcol)= a4*TC1(mx,jja) + ace + a6*TC1(mx,jjc)
          END Do ! par
         end do
            jcol=0
            jjb= jcol2js(jcol  ,js)
            jjc= jcol2js(jcol+1,js)
          Do mx=-MT,MT
             a4= DMATm(mx,1,jcol,js)
             a5= DMATm(mx,2,jcol,js)
            YMAT(mx,jcol)=(a4+msquar(mx))*TC1(mx,jjb)+a5*TC1(mx,jjc)
          END Do ! par
            jcol=JLH
            jja= jcol2js(jcol-1,js)
            jjb= jcol2js(jcol  ,js)
          Do mx=-MT,MT
             a4= DMATm(mx,1,jcol,js)
             a5= DMATm(mx,2,jcol,js)
            YMAT(mx,jcol)= a4*TC1(mx,jja)+(a5+msquar(mx))*TC1(mx,jjb)
          END Do ! par

c---- 2  To get ZETA, AMAT*ZETA= YMAT

         do mc=0,JLH-1
            mc1= mc+1
          Do mx=-MT,MT
            YMAT(mx,mc1)= YMAT(mx,mc1)-YMAT(mx,mc )*AMATm_(mx,3,mc,js)
          END Do ! par
         end do

          Do mx=-MT,MT
            YMAT(mx,JLH)=  YMAT(mx,JLH) * AMATm_(mx,1,JLH,js) !! (1/*)
          END Do ! par

         do mco=JLH-1,1,-1
            mcop1=mco+1
          Do mx=-MT,MT
                 aaa =  YMAT(mx,mcop1)*AMATm_(mx,2,mco,js)
            YMAT(mx,mco)= (YMAT(mx,mco)-aaa) * AMATm_(mx,1,mco,js)
          END Do ! par
         end do

         do jcol=1,JLH
            jjj= jcol2js(jcol,js)
          Do mx=-MT,MT
            AJX(mx,jjj)= YMAT(mx,jcol)
          END Do ! par
         end do

      END DO ! js=1,2

      CALL GLOBAL0( AJX, XMAT0, +1 ) ! MAK=+1: glo-mean->0

C--------------------------------------------------------------------C
      ELSEIF(MSEL.eq.1) THEN           ! Inverse Laplacian of AJX= TC1
C--------------------------------------------------------------------C

      CALL GLOBAL0( AJX, XMAT0, +1 ) ! MAK=+1: glo-mean->0

      DO js=1,2

c---- 1  To get YMAT, YMAT= AMAT*ZETA

         do jcol=1,JLH-1
            jja= jcol2js(jcol-1,js)
            jjb= jcol2js(jcol  ,js)
            jjc= jcol2js(jcol+1,js)
          Do mx=-MT,MT
             a4= AMATm(mx,1,jcol,js)
             a5= AMATm(mx,2,jcol,js)
             a6= AMATm(mx,3,jcol,js)
            YMAT(mx,jcol)= a4*AJX(mx,jja)+a5*AJX(mx,jjb)+a6*AJX(mx,jjc)
          END Do ! par
         end do
            jcol=0
            jjb= jcol2js(jcol  ,js)
            jjc= jcol2js(jcol+1,js)
          Do mx=-MT,MT
             a4= AMATm(mx,1,jcol,js)
             a5= AMATm(mx,2,jcol,js)
            YMAT(mx,jcol)= a4*AJX(mx,jjb)+a5*AJX(mx,jjc)    
          END Do ! par
            jcol=JLH
            jja= jcol2js(jcol-1,js)
            jjb= jcol2js(jcol  ,js)
          Do mx=-MT,MT
             a4= AMATm(mx,1,jcol,js)
             a5= AMATm(mx,2,jcol,js)
            YMAT(mx,jcol)= a4*AJX(mx,jja)+a5*AJX(mx,jjb)
          END Do ! par

c---- 2  To get PSI, DMAT*PSI= YMAT

         do mc=0,JLH-1
            mc1= mc+1
          Do mx=-MT,MT
            YMAT(mx,mc1)= YMAT(mx,mc1)
     &                   -YMAT(mx,mc )*DMATm_(mx,3,mc,js)
          END Do ! par
         end do

          Do mx=-MT,MT
            YMAT(mx,JLH)=  YMAT(mx,JLH) * DMATm_(mx,1,JLH,js) !! (1/*)
          END Do ! par

         do mco=JLH-1,1,-1
            mcop1=mco+1
          Do mx=-MT,MT
                 aaa =  YMAT(mx,mcop1)*DMATm_(mx,2,mco,js)
            YMAT(mx,mco)= (YMAT(mx,mco)-aaa) * DMATm_(mx,1,mco,js)
          END Do ! par
         end do

         do jcol=1,JLH
            jjj= jcol2js(jcol,js)
          Do mx=-MT,MT
            TC1(mx,jjj)= YMAT(mx,jcol)
          END Do ! par
         end do

      END DO ! js=1,2

            TC1( 0, 0 )= 0.             

C--------------------------------------------------------------------C
       ENDIF
C--------------------------------------------------------------------C

C===============C
      RETURN
      END
C
C
**********************************************************************
*                                                                    *
*     SUBROUTINE : MATRICES and INVERSION                            *
*                                                                    *
**********************************************************************
*                                                                    *
*     Matrices for Laplacian of PSI                                  *
*                                                                    *
*    [CALL MAT200E] -> [CALL LAP200E]                                *
*                                                                    *
*     AMATm, DMATm, BMATm: Size=(0:JLHP,0:JLHP)                      *
*                          Used=(0:JLH ,0:JLH ) for all inversions   *
*                          except for 5-diagonal-matrix construction *
*                          in SUB MATS_BIH                           *
*                                                                    *
*     01 MAR 2005                                                    *
*                                                                    *
**********************************************************************
      SUBROUTINE MAT200E_JS2
       use parameter_pi
       use parameter_dsize
       use parameter_wsize
       use parameter_earth
       use common_trigono_metric_sphere
       use common_metrix
C--------------------------------------------------------------------C
      IMPLICIT  REAL*8 (A-H,O-Z)
C-----local variable-------------------------------------------------C
      DIMENSION YMATD(-MT:MT,3,0:JLH)
C--------------------------------------------------------------------C
      print*,'Calculating matrices for Laplacian'
C-----
      do js=1,2         ! meridional index used in SUB LAP---
         jsmo= MOD(js,2)
      do jcol=0,JLH                     ! mj=0,2,4 : js=even
             jcoljsm = jcol*2 - jsmo    ! mj=1,3,5 : js=odd
          if(jcoljsm.LT.0) jcoljsm= 1  !! 0th row for m1 m2 m0:n2 are unnece.
         jcol2js(jcol,js)= jcoljsm     !! and to avoid -1 array index
      end do
      end do
C-----
      do mx=-MT,MT
         MSQUAR(mx)= -mx**2     
      end do
C-----
C
**************************************************
*BEG  MATRIECS for LAPLACIAN OPERATOR            *
**************************************************

Cbeg-- Matrices for Y= ( D^2/Dlambda^2 + COS(LAT) D/Dphi COS(LAT) D/Dphi ) X
c                  js
C        DMATm(1,K, 1 ) :  m=1,3,..., n=1,3,...
C        DMATm(1,K, 2 ) :  m=1,3,..., n=2,4,...
C        DMATm(1,K, 3 ) :  m=2,4,..., n=1,3,...      ! Same for AMATm
C        DMATm(1,K, 4 ) :  m=2,4,..., n=2,4,...
C        DMATm(1,K, 5 ) :  m=0      , n=1,3,...
C        DMATm(1,K, 6 ) :  m=0      , n=0,2,4,.

C      Be careful of the identity that DMAT0(0,1,2)= DMAT0(1,1,2)= 0

C----- m1,n2
      Do mx=-MT+1,MT-1,2
      do j=4,JL-2,2                   ! m=1,3,...
         K= (j+0)/2                              ! n=2,4,...
         DMATm(mx,1,K,2)=  (j-2.d0)*(j-1.d0)/4.D0
         DMATm(mx,2,K,2)= -(dfloat(j)**2)/2.D0
         DMATm(mx,3,K,2)=  (j+1.d0)*(j+2.d0)/4.D0
      end do
         j=2
         K= (j+0)/2                              ! n=2,4,...
         DMATm(mx,2,K,2)= -(dfloat(j)**2)/2.D0      ! 1st row of 3-diag MATRIX
         DMATm(mx,3,K,2)=  (j+1.d0)*(j+2.d0)/4.D0
         DMATm(mx,1,K,2)=   0.
         j=JL
         K= (j+0)/2                              ! n=2,4,...
         DMATm(mx,1,K,2)=  (j-2.d0)*(j-1.d0)/4.D0   ! last row of 3-diag MATRIX
         DMATm(mx,2,K,2)= -(dfloat(j)**2)/2.D0
         DMATm(mx,3,K,2)=   0.
C----- m1,n1
      do j=3,JL-3,2                   ! m=1,3,...
         K= (j+1)/2                              ! n=1,3,...
         DMATm(mx,1,K,1)=  (j-2.d0)*(j-1.d0)/4.D0
         DMATm(mx,2,K,1)= -(dfloat(j)**2)/2.D0
         DMATm(mx,3,K,1)=  (j+1.d0)*(j+2.d0)/4.D0
      end do
         j=1
         K= (j+1)/2                              ! n=1,3,...
         DMATm(mx,2,K,1)= -(dfloat(j)**2)/2.D0      ! 1st row of 3-diag MATRIX
         DMATm(mx,3,K,1)=  (j+1.d0)*(j+2.d0)/4.D0
         DMATm(mx,1,K,1)=   0.
         j=JL-1
         K= (j+1)/2                              ! n=1,3,...
         DMATm(mx,1,K,1)=  (j-2.d0)*(j-1.d0)/4.D0   ! last row of 3-diag MATRIX
         DMATm(mx,2,K,1)= -(dfloat(j)**2)/2.D0
         DMATm(mx,3,K,1)=   0.
      END Do ! mx=1,3,...
C-----m2,n2
      Do mx=-MT,MT,2
      if(mx.NE.0) then
      do j=4,JL-2,2                   ! m=2,4,...
         K= (j+0)/2                              ! n=2,4,...
         DMATm(mx,1,K,2)=   dfloat(j)*(j-1.d0)/4.D0
         DMATm(mx,2,K,2)= -(dfloat(j)**2)/2.D0
         DMATm(mx,3,K,2)=   dfloat(j)*(j+1.d0)/4.D0
      end do
         j=2
         K= (j+0)/2                              ! n=2,4,...
         DMATm(mx,2,K,2)= -(dfloat(j)**2)/2.D0      ! 1st row of 3-diag MATRIX
         DMATm(mx,3,K,2)=   dfloat(j)*(j+1.d0)/4.D0
         DMATm(mx,1,K,2)=   0.
         j=JL
         K= (j+0)/2                              ! n=2,4,...
         DMATm(mx,1,K,2)=   dfloat(j)*(j-1.d0)/4.D0 ! last row of 3-diag MATRIX
         DMATm(mx,2,K,2)= -(dfloat(j)**2)/2.D0
         DMATm(mx,3,K,2)=   0.
C-----m2,n1
      do j=3,JL-3,2                   ! m=2,4,...
         K= (j+1)/2                              ! n=1,3,...
         DMATm(mx,1,K,1)=   dfloat(j)*(j-1.d0)/4.D0
         DMATm(mx,2,K,1)= -(dfloat(j)**2)/2.D0
         DMATm(mx,3,K,1)=   dfloat(j)*(j+1.d0)/4.D0
      end do
         j=1
         K= (j+1)/2                              ! n=1,3,...
         DMATm(mx,2,K,1)= -(dfloat(j)**2)/2.D-00    ! 1st row of 3-diag MATRIX
         DMATm(mx,3,K,1)=   dfloat(j)*(j+1.d0)/4.D0
         DMATm(mx,1,K,1)=   0.
         j=JL-1
         K= (j+1)/2                              ! n=1,3,...
         DMATm(mx,1,K,1)=   dfloat(j)*(j-1.d0)/4.D0 ! last row of 3-diag MATRIX
         DMATm(mx,2,K,1)= -(dfloat(j)**2)/2.D0
         DMATm(mx,3,K,1)=   0.
      endif
      END Do ! m=2,4,...
C-----m0,n1
         mx=0
      do j=3,JL-3,2                   ! m=0
         K= (j+1)/2                              ! n=1,3,...
         DMATm(mx,1,K,1)=  (j-2.d0)*(j-1.d0)/4.D0
         DMATm(mx,2,K,1)= -(dfloat(j)**2)/2.D0
         DMATm(mx,3,K,1)=  (j+1.d0)*(j+2.d0)/4.D0
      end do
         j=1
         K= (j+1)/2                              ! n=1,3,...
         DMATm(mx,2,K,1)= -(dfloat(j)**2)/2.D-00    ! 1st row of 3-diag MATRIX
         DMATm(mx,3,K,1)=  (j+1.d0)*(j+2.d0)/4.D-00
         DMATm(mx,1,K,1)=   0.
         j=JL-1
         K= (j+1)/2                              ! n=1,3,...
         DMATm(mx,1,K,1)=  (j-2.d0)*(j-1.d0)/4.D0   ! last row of 3-diag MATRIX
         DMATm(mx,2,K,1)= -(dfloat(j)**2)/2.D0
         DMATm(mx,3,K,1)=   0.
C-----m0,n2
      do j=2,JL-2,2                   ! m=0
         K= (j+0)/2                              ! n=0,2,...
         DMATm(mx,1,K,2)=  (j-2.d0)*(j-1.d0)/4.D0
         DMATm(mx,2,K,2)= -(dfloat(j)**2)/2.D0
         DMATm(mx,3,K,2)=  (j+1.d0)*(j+2.d0)/4.D0
      end do
         j=0
         K= (j+0)/2                              ! n=0,2,...
         DMATm(mx,1,K,2)= -(dfloat(j)**2)/2.D-00    ! 1st row of 3-diag MATRIX
         DMATm(mx,2,K,2)=  (j+1.d0)*(j+2.d0)/4.D0
         DMATm(mx,3,K,2)=   0.
         j=JL
         K= (j+0)/2                              ! n=0,2,...
         DMATm(mx,1,K,2)=  (j-2.d0)*(j-1.d0)/4.D0   ! last row of 3-diag MATRIX
         DMATm(mx,2,K,2)= -(dfloat(j)**2)/2.D0
         DMATm(mx,3,K,2)=   0.

Cend-- Matrices for Y= ( D^2/Dlambda^2 + COS(LAT) D/Dphi COS(LAT) D/Dphi ) X


Cbeg-- Matrices for Z= VORTicity * COS(LAT)^2

C-----m1
      Do mx=-MT+1,MT-1,2
      do K=2,JLH-1                            ! n=2,4,...
         AMATm(mx,1,K,2)=  -1/4.D-00
         AMATm(mx,2,K,2)=   1/2.D-00
         AMATm(mx,3,K,2)=  -1/4.D-00
      end do
         K=1                                  ! n=2,4,...
         AMATm(mx,2,K,2)=   1/2.D-00
         AMATm(mx,3,K,2)=  -1/4.D-00
         AMATm(mx,1,K,2)=   0.
         K=JLH                                ! n=2,4,...
         AMATm(mx,1,K,2)=  -1/4.D-00
         AMATm(mx,2,K,2)=   1/2.D-00
         AMATm(mx,3,K,2)=   0.
      do K=1,JLH                              ! n=1,3,...
      do I=1,3
         AMATm(mx,I,K,1)= AMATm(mx,I,K,2)
      end do
      end do
      END Do ! mx=1,3,...
C-----m0
         mx=0
      do K=1,JLH
      do I=1,3                ! m1    n2
         AMATm(mx,I,K,1)= AMATm(+1,I,K,2)     ! m=0, n=1,3,...
         AMATm(mx,I,K,2)= AMATm(+1,I,K,2)     ! m=0, n=0,2,4,.
      end do
      end do

      Do mx=-MT+1,MT-1,2
!        AMATm(mx,1,1,1)=   1/2.D-00 + 1/4.D-00  ! note
         AMATm(mx,2,1,1)=   1/2.D-00 + 1/4.D-00  ! note
      END Do
         mx=0
!        AMATm(mx,1,1,1)=   1/2.D-00 - 1/4.D-00  ! note
         AMATm(mx,2,1,1)=   1/2.D-00 - 1/4.D-00  ! note
         AMATm(mx,1,0,2)=   1/2.D-00                    
         AMATm(mx,2,0,2)=  -1/4.D-00                    
         AMATm(mx,3,0,2)=   0.                          
         AMATm(mx,1,1,2)=  -1/2.D-00                    
         AMATm(mx,2,1,2)=   1/2.D-00                    
         AMATm(mx,3,1,2)=  -1/4.D-00                   
C-----m2
      Do mx=-MT,MT,2
      if(mx.NE.0) then
      do K=1,JLH
      do I=1,3                ! m1  n1n2
         AMATm(mx,I,K,1)= AMATm(+1,I,K,1)           ! m2 : n=1,3,5...
         AMATm(mx,I,K,2)= AMATm(+1,I,K,2)           ! m2 : n=2,4,6...               
      end do
      end do
      endif
      END Do ! mx=2,4,...
      
Cend-- Matrices for Z= VORTicity * COS(LAT)^2
c
      do mx=-MT,MT             ! For varying JL, 20 FEB 2007
         imx= iabs(mx)
         mmm= JL-(JL-MT)*(dfloat(imx)/MT)**1.25d0
         if(MOD(mmm,2).ne.0) mmm= mmm-1
         JL_mx(mx,1)= mmm
         JL_mx(mx,2)= mmm/2
      end do ! mx=             ! For varying JL, 20 FEB 2007

      DO js=1,2                ! For varying JL, 20 FEB 2007
      do mx=-MT,MT
      do K=JL_mx(mx,2)+1,JLH
      do I=1,3
         AMATm(mx,I,K,js)= 0.d0
         DMATm(mx,I,K,js)= 0.d0
      end do
         AMATm(mx,2,K,js)= 1.d0
         DMATm(mx,2,K,js)= 1.d0
      end do ! K=
      if(JL_mx(mx,2).lt.JLH) then
      do K=JL_mx(mx,2),JL_mx(mx,2)
         AMATm(mx,3,K,js)= 0.d0
         DMATm(mx,3,K,js)= 0.d0
      end do ! K=
      endif
      end do ! mx=
      END DO ! js=             ! For varying JL, 20 FEB 2007

**************************************************
*END  MATRIECS for LAPLACIAN OPERATOR            *
**************************************************
C
**************************************************
*BEG  Time saving, prehandling of the MATRIX     *
**************************************************

c---- AJX*COS(LAT)^2                  = AJX*AMAT = SNM   -A-
c---- COSLAT d/dphi COSLAT d/dphi TC1 = DMAT*TC1 = SNM   -B-
c---- To get AJX, AJX= Laplacian of TC1, 1) SNM from -B- 2) AJX= AMAT_*SNM
c---- To get TC1, AJX= Laplacian of TC1, 1) SNM from -A- 2) TC1= DMAT_*SNM
c
c
Cbeg-------------------------------------------------- DMAT -> DMAT_
c
c                12......                12......     
c                123.....                .12.....
c        DMATx   .123....       DMATx_   ..12....
c                ........                ...12...
c                .....123                ........
c                ......12                ......12
c
C-----m0,m1,m2,(n1) and m0,m1,m2,(n2)
      DO js=1,2

         do mc=1,JLH-1
          Do mx=-MT,MT
             mx2= -MSQUAR(mx)
            YMATD( mx,1,mc)= DMATm(mx,1,mc,js)
            YMATD( mx,2,mc)= DMATm(mx,2,mc,js) - mx2
            YMATD( mx,3,mc)= DMATm(mx,3,mc,js)
          END Do
         end do
            mc=0
          Do mx=-MT,MT
             mx2= -MSQUAR(mx)
            YMATD( mx,1,mc)= DMATm(mx,1,mc,js) - mx2
            YMATD( mx,2,mc)= DMATm(mx,2,mc,js)
          END Do
            mc=JLH
          Do mx=-MT,MT
             mx2= -MSQUAR(mx)
            YMATD( mx,1,mc)= DMATm(mx,1,mc,js)
            YMATD( mx,2,mc)= DMATm(mx,2,mc,js) - mx2
          END Do
c-------------------
      do mc=0,JLH-1                    
         mc1= mc+1                                 
       Do mx=-MT,MT

          IF(mc.eq.0) then
         rat= 0.d0
          ELSE
         rat= YMATD( mx,1,mc1) / YMATD( mx,1,mc)
          ENDIF

cnext-sub   YMAT(mc )= YMAT(mc )*rat   
            YMATD( mx,2,mc1)= YMATD( mx,2,mc1)-YMATD( mx,2,mc )*rat    
cnext-sub   YMAT(mc1)= YMAT(mc1)-YMAT(mc )
            YMATD( mx,1,mc1)= YMATD( mx,2,mc1)
            YMATD( mx,2,mc1)= YMATD( mx,3,mc1)

          IF(mc.eq.0) then
            DMATm_( mx,1,mc ,js)= 0.d0
          ELSE
            DMATm_( mx,1,mc ,js)= 1.d0/YMATD( mx,1,mc ) !! (1/*)
          ENDIF

            DMATm_( mx,2,mc ,js)=      YMATD( mx,2,mc )                
            DMATm_( mx,3,mc ,js)= rat
       END Do ! par
      end do ! mc

       Do mx=-MT,MT
            DMATm_( mx,1,JLH,js)= 1.d0/YMATD( mx,1,JLH) !! (1/*)
       END Do ! par

       Do mx=-MT,MT            ! For varying JL, 20 FEB 2007
      do mc=JL_mx(mx,2)+1,JLH
            DMATm_( mx,1,mc ,js)= 0.d0
      end do ! mc
       END Do ! par            ! For varying JL, 20 FEB 2007

      END DO ! js=1,2
c
Cend-------------------------------------------------- DMAT -> DMAT_

Cbeg-------------------------------------------------- AMAT -> AMAT_
C-----m0,m1,m2,(n1) and m0,m1,m2,(n2)
      DO js=1,2

         do mc=1,JLH-1
          Do mx=-MT,MT
            YMATD( mx,1,mc)= AMATm(mx,1,mc,js)
            YMATD( mx,2,mc)= AMATm(mx,2,mc,js)
            YMATD( mx,3,mc)= AMATm(mx,3,mc,js)
          END Do
         end do
            mc=0
          Do mx=-MT,MT
            YMATD( mx,1,mc)= AMATm(mx,1,mc,js)
            YMATD( mx,2,mc)= AMATm(mx,2,mc,js)
          END Do
            mc=JLH
          Do mx=-MT,MT
            YMATD( mx,1,mc)= AMATm(mx,1,mc,js)
            YMATD( mx,2,mc)= AMATm(mx,2,mc,js)
          END Do
c-------------------
      do mc=0,JLH-1                    
         mc1= mc+1                               
       Do mx=-MT,MT

          IF(mc.eq.0) then
          if(mx.eq.0 .AND. js.eq.2) then
            rat= YMATD( mx,1,mc1) / YMATD( mx,1,mc)
          else
            rat= 0.d0
          endif 
          ELSE
            rat= YMATD( mx,1,mc1) / YMATD( mx,1,mc)
          ENDIF

cnext-sub   YMAT(mc )= YMAT(mc )*rat
            YMATD( mx,2,mc1)= YMATD( mx,2,mc1)-YMATD( mx,2,mc)*rat
cnext-sub   YMAT(mc1)= YMAT(mc1)-YMAT(mc )
            YMATD( mx,1,mc1)= YMATD( mx,2,mc1)
            YMATD( mx,2,mc1)= YMATD( mx,3,mc1)

          IF(mc.eq.0) then
          if(mx.eq.0 .AND. js.eq.2) then
            AMATm_( mx,1,mc ,js)= 1.d0/YMATD( mx,1,mc ) !! (1/*)
          else
            AMATm_( mx,1,mc ,js)= 0.d0
          endif
          ELSE
            AMATm_( mx,1,mc ,js)= 1.d0/YMATD( mx,1,mc ) !! (1/*)
          ENDIF

            AMATm_( mx,2,mc ,js)=      YMATD( mx,2,mc )
            AMATm_( mx,3,mc ,js)= rat
       END Do
      end do ! mc

       Do mx=-MT,MT
            AMATm_( mx,1,JLH,js)= 1.d0/YMATD( mx,1,JLH) !! (1/*)
       END Do

       Do mx=-MT,MT            ! For varying JL, 20 FEB 2007
      do mc=JL_mx(mx,2)+1,JLH
            AMATm_( mx,1,mc ,js)= 0.d0
      end do ! mc
       END Do ! par            ! For varying JL, 20 FEB 2007

      END DO ! js

Cend-------------------------------------------------- AMAT -> AMAT_

**************************************************
*END  Time saving, prehandling of the MATRIX     *
**************************************************

C===========
      RETURN
      END
C
C
**********************************************************************
*                                                                    *
*     TEST OF FFT-ROUTINE : WAVE1->GRID->WAVE2 : (WAVE1-WAVE2)=ERROR *
*                                                                    *
**********************************************************************
      SUBROUTINE TEST_FFT
       use parameter_pi
       use parameter_dsize
       use parameter_wsize
       use parameter_earth
       use common_trigono_metric_sphere
       use common_metrix
C--------------------------------------------------------------------C
      IMPLICIT  REAL*8 (A-H,O-Z)
C-----local-variables------------------------------------------------C
      DIMENSION WORK1(0:IB1,-JB:JB1),WORK2(0:IB1,-JB:JB1)
C--------------------------------------------------------------------C
      DIMENSION V1(-MT:MT,0:JL),V2(-MT:MT,0:JL)
C--------------------------------------------------------------------C

      do mj=0,JL
      do mx=-MT,MT
         V1(mx,mj)= 1.0D0
      end do
      end do

          if(JL.eq.(IB/2)) V1( 0,JL)= 0.
                           JLAST= JL
          if(JL.eq.(IB/2)) JLAST= JL-1
          if(MT.eq.(IB/2)) then
      do mj=0,JL
         V1(MT,mj)= 0.
      end do
       endif

         CALL FFT_DFS_235_SC( -1, WORK1, V1, JL, -1 )   ! is=1:->Wa, ip=1:cut

      DO ITEST=1,2
         CALL FFT_DFS_235_SC( +1, WORK1, V2, JL, -1 )   ! is=1:->Wa, ip=1:cut
         CALL FFT_DFS_235_SC( -1, WORK1, V2, JL, -1 )   ! is=1:->Wa, ip=1:cut
      END DO

         ISIGN= 1

         criter= 1.0D-9

         errsum= 0

      do mj=0,JLAST  
      do mx=0,0     
             error1= DABS( V1(-mx,mj)-V2(-mx,mj) )
             error2= DABS( V1( mx,mj)-V2( mx,mj) )
         IF((error1.GT.criter) .OR. (error2.GT.criter)) ISIGN= 0
         errsum= errsum + error1 + error2
      end do
      end do
      do mj=1,JL
      do mx=1,MT,2
             error1= DABS( V1(-mx,mj)-V2(-mx,mj) )
             error2= DABS( V1( mx,mj)-V2( mx,mj) )
         IF((error1.GT.criter) .OR. (error2.GT.criter)) ISIGN= 0
         errsum= errsum + error1 + error2
      end do
      end do
      do mj=1,JL  
      do mx=2,MT,2
             error1= DABS( V1(-mx,mj)-V2(-mx,mj) )
             error2= DABS( V1( mx,mj)-V2( mx,mj) )
         IF((error1.GT.criter) .OR. (error2.GT.criter)) ISIGN= 0
         errsum= errsum + error1 + error2
      end do
      end do

          IF(MT.eq.(IB/2)) then

      do j=-JB,JB1
      do i=0,IB1  
         WORK2(I,J)= 0.0D0
      end do
      end do
         WORK2(1, 1 )= 1.0D0
         WORK2(2,JB1)= 1.0D0

         CALL FFT_DFS_235_SC( +1, WORK2, V2, JL, -1 )   ! is=1:->Wa, ip=1:cut
         CALL FFT_DFS_235_SC( -1, WORK1, V2, JL, -1 )   ! is=1:->Wa, ip=1:cut

      do j=-JB,JB1
      do i=0,IB1  
             error1= DABS( WORK1(I,J)-WORK2(I,J) )
         IF((error1.GT.criter)                        ) ISIGN= 0
         errsum= errsum + error1             
      end do
      end do

       ENDIF

         errsum= errsum/( MT*2.0*JL + IB*JBW*(MT*2./IB) )        

             write(*,*) '     ================================='
             write(*,*) '       error1 : WAVE1->GRID->WAVE2    ' 
             write(*,*) '       error2 : GRID1->WAVE->GRID2    ' 
             write(*,*) '       total ERROR=(error1+error2)/2  '
             write(*,*) '     ================================='
          IF(ISIGN.eq.1) THEN

             write(*,*) '     ================================='
             write(*,*) '      TEST of FFT : It is All Right ! ' 
             write(*,*) '     ================================='
      ELSE
             write(*,*) '     ================================='
             write(*,*) '      TEST of FFT : Something wrong ! ' 
             write(*,*) '     ================================='
      ENDIF

          IF(MT.eq.(IB/2)) then
             write(*,*) '   1-WORK1(1,1) must be VERY near to 0.0'
             write(*,*) '   1-WORK1(1,1)= ', 1.D0-WORK1(1,1)
       ENDIF                       
             write(*,*) '     ================================='
             write(*,*) '     NORMALIZED total ERROR in FFT is ',errsum
             write(*,*) '     ================================='
             write(*,*) '                 IB=',IB
             write(*,*) '                 MT=',MT
             write(*,*) '     ================================='
c
C===============C
      RETURN
      END
C
C
C--------------------------------------------------------------------C
C                                                                    C
C     Double Fourier Transform on the Sphere : vectorized            C
C                                                                    C
C--------------------------------------------------------------------C
      SUBROUTINE FFT_DFS_235_SC( isign, PSI, ANM, JT, ipole ) ! is=1:->Wa, ip=1:cut
       use parameter_pi
       use parameter_dsize
       use parameter_wsize
       use parameter_earth
       use common_trigono_metric_sphere
       use common_metrix
C--------------------------------------------------------------------C
      IMPLICIT  REAL*8 (A-H,O-Z)
C--------------------------------------------------------------------C
      DIMENSION PSI(0:IB1,-JB:JB1),ANM(-MT:MT,0:JT)
C-----local-variables------------------------------------------------C
!     DIMENSION data0(-JB:JB,0:IB1) ! ,data5(-JB:JB,0:IB1)  ! 2001.07.06
      DIMENSION mxx2(0:JBW,2)                               ! 2001.07.06
      DIMENSION SHIFTC(0:JBW),SHIFTS(0:JBW)                 ! 2001.07.06
      DIMENSION TRIGSIB(IB*2),TRIGSJBW(JBW*2)
C-----
      DIMENSION data_SIN(-MT:MT,-JB:JB1),temp_SIN(-MT:MT)       ! mx=-MT,MT
      DIMENSION partRE_SIN(-MT:MT,0:JB),partIM_SIN(-MT:MT,0:JB) ! mx=-MT,MT
!     DIMENSION data_COS(-1:1,-JB:JB1),temp_COS(-1:1)           ! mx=0,(-1:1) for convenience 
!     DIMENSION partRE_COS(-1:1,0:JB),partIM_COS(-1:1,0:JB)     ! mx=0,(-1:1) for convenience
      DIMENSION SINHF(0:JB),COSPK(0:JB),SINPK(0:JB)             ! mx= all
C-----
      DIMENSION ALON(0:JB,0:IB1),BLON(0:JB,0:IB1)
      DIMENSION ALAS(0:MT,0:IB1),BLAS(0:MT,0:IB1)
!     DIMENSION ALAC(0:1 ,0:IB1),BLAC(0:1 ,0:IB1)
      DIMENSION COSFUN1(-JB:JB,0:JBW),COSFUN2(0:JBW,-JB:JB)     ! Extra array space 
      DIMENSION COSNM(0:JBW),COSJ(-JB:JB)                       ! to avoid Bank Conflict
C-----
      CHARACTER*4 FFTOPT
      LOGICAL   JUSDOIT/.TRUE./
C--------------------------------------------------------------------C
      IF(JUSDOIT) THEN
         JUSDOIT=.FALSE.

         do mx=0,JBW    ! 2001.07.06
            mxx2(mx,1)= mx*2
            mxx2(mx,2)= mx*2+1
         end do

                PIN= PI/IB
         do k=0,JBW    
            bb= PIN*dble(k)
            SHIFTC(k)= DCOS(bb)
            SHIFTS(k)= DSIN(bb)
         end do
C---
              FFTOPT='P235'
              J2N= 1
        do k=1,20
              J2N= J2N*2
           if(IB.eq.J2N) then
!             FFTOPT='P222'
              EXIT
           endif
        end do        ! 2004.04.02      
           write(*,*) ' IB, FFTSOPT=', IB, FFTOPT   

         CALL GPFASET_8_VEC(TRIGSIB ,IB )
         CALL GPFASET_8_VEC(TRIGSJBW,JBW)  ! for 2,3,5 prime factor 

            PIN= PI/JBW

         do j=0,JB                         ! For SINE and COSINE transform 
            aa= PIN*(j+0.5D-00)
            SINHF(j)= DSIN(aa)
         end do
         do k=0,JB
            bb= PIN*dble(k)
            COSPK(k)= DCOS(bb)
            SINPK(k)= DSIN(bb)
         end do

         do j=-JB,JB1
            sum= (j+JB+0.5d0)*PIN          ! For direct COS transform
         do mj=0,JBW1
            COSFUN1(j,mj)= DCOS(mj*sum)
            COSFUN2(mj,j)= DCOS(mj*sum)
         end do
         end do

      ENDIF

C----------------------------------------------------------------------C

          IF(JT.gt.(IB/2))  then
             write(*,*) ' ==   Invalid range of Y-transform   =='
             write(*,*) ' == JT must not be greater than IB/2 =='
             stop
       ENDIF

C-----------------------------

                          MLAST= MT         ! A part transform for Y-dir
         if(MT.eq.(IB/2)) MLAST= MT-1       ! Full range transform for Y-dir

         do 9211 J=-JB,JB    ! reset
         do 9211 mx=-MT,MT 
 9211       FWAVEJ(mx,J)= 0.

C=============================
          IF(isign.EQ.+1) THEN
C=============================

C-----(I,J)->(mx,J)

         do I=0,IB1
         Do J=0,JB1 
            BLON( J,I)= PSI(I, J )
            ALON( J,I)= PSI(I,-J )
         end do
            ALON(JB,I)= PSI(I,-JB)
            BLON(JB,I)= 0.d0
            BLON( 0,I)= 0.d0      ! to avoid the same point 
         END Do
         
         CALL GPFA_8_VEC( ALON,BLON,TRIGSIB, 1, IB, IB, 1, isign,JB,JB )

         do mx=1,MLAST  
                      kev= mxx2(mx,1) ! mx*2
                      kod= mxx2(mx,2) ! kev+1
            IBmx= IB-mx
         Do J=0,JB
            FWAVEJ(-mx, J)= ( BLON(J,mx)+BLON(J,IBmx))/IB ! FWAVEJ(*,JB)= 0.
            FWAVEJ(-mx,-J)= ( ALON(J,mx)+ALON(J,IBmx))/IB
            FWAVEJ( mx, J)= (-ALON(J,mx)+ALON(J,IBmx))/IB
            FWAVEJ( mx,-J)= ( BLON(J,mx)-BLON(J,IBmx))/IB
         END Do ! par 
         end do
         Do J=0,JB
            FWAVEJ( 0 , J)=    BLON(J,0 )/IB
            FWAVEJ( 0 ,-J)=    ALON(J,0 )/IB      ! always A is the last
                if(MT.eq.(IB/2)) then
            FWAVEJ(-MT, J)=    BLON(J,MT)/IB
            FWAVEJ(-MT,-J)=    ALON(J,MT)/IB
             endif
         END Do ! par 

         Do J=-JB,JB1 ! parallel
         do mx=2,MT,2
            FWAVEJ(-mx,J)= FWAVEJ(-mx,J)/COSLAT(J,1)
            FWAVEJ( mx,J)= FWAVEJ( mx,J)/COSLAT(J,1)
         end do
         END Do ! par

         IF(ipole.EQ.+1) CALL POLECUT

C-----(mx,J)->(mx,mj)

         Do J=-JB,JB1
         do mx=-MT,MT
            data_SIN(mx,J)= FWAVEJ(mx,J)
         end do
            data_SIN( 0,J)= 0.
!           data_COS(-1,J)= 0.
!           data_COS( 0,J)= FWAVEJ( 0,J)
!           data_COS(+1,J)= 0.
                 COSJ(J)  = FWAVEJ( 0,J)
         END Do

      CALL SIN_FTN
     &( data_SIN, partRE_SIN, partIM_SIN, temp_SIN, SINHF, COSPK, SINPK,
     &  ALAS, BLAS, TRIGSJBW, JBW, JBW-1, JB, MT, isign )
!     CALL COS_FTN
!    &( data_COS, partRE_COS, partIM_COS, temp_COS, SINHF, COSPK, SINPK,
!    &  ALAC, BLAC, TRIGSJBW, JBW, JBW-1, JB,  1, isign )

!------ This FT replaces COS_FTN caus'f poor vec efficiency

        do mj=0,JT
           sum= 0.
        do j=-JB,JB1
           sum= sum + COSFUN1(j,mj)*COSJ(J)
        end do
                      COSNM(mj)= sum/JB
          if(mj.eq.0) COSNM(mj)= sum/JBW
        end do

!------ This FT replaces COS_FTN caus'f poor vec efficiency

         Do mj=1,JT
            mjJB1= mj-JB-1
         do mx=-MT,MT
            ANM(mx,mj)= data_SIN(mx,mjJB1)  ! In SUB, mj=0 -> SIN(1)
         END Do
         end do
         do mj=0,JT
            ANM( 0,mj)=      COSNM(mj)
         end do
c------
         do mx=1,MT
            ANM(-mx,0)= 0.
            ANM( mx,0)= 0.
         end do
             if(JT.eq.(IB/2)) ANM( 0,JT)= 0.
             if(MT.eq.(IB/2)) then
         do mj=0,JT
            ANM(MT,mj)= 0.
         end do
          endif

C=============================
      ELSEIF(isign.EQ.-1) THEN
C=============================
C
             if(JT.eq.(IB/2)) ANM( 0,JT)= 0.
             if(MT.eq.(IB/2)) then
         do mj=0,JT
            ANM(MT,mj)= 0.
         end do
          endif
         do mx=1,MT
            ANM(-mx,0)= 0.
            ANM( mx,0)= 0.
         end do

C-----(mx,mj)->(mx,J)

         Do mj=0,JBW-1
            mjJB= mj-JB 
         do mx=-MT,MT
            data_SIN(mx,mjJB)= 0.
         end do
!           data_COS(-1,mjJB)= 0.
!           data_COS( 0,mjJB)= 0.
!           data_COS(+1,mjJB)= 0.
         END Do

         Do mj=1,JT
            mjJB1= mj-JB-1
         do mx=-MT,MT
            data_SIN(mx,mjJB1)= ANM(mx,mj)
         END Do
            data_SIN( 0,mjJB1)= 0.
         end do
         Do mj=0,JT
                 COSNM(mj)    = ANM( 0,mj)
         end do

      CALL SIN_FTN
     &( data_SIN, partRE_SIN, partIM_SIN, temp_SIN, SINHF, COSPK, SINPK,
     &  ALAS, BLAS, TRIGSJBW, JBW, JBW-1, JB, MT, isign )
!     CALL COS_FTN
!    &( data_COS, partRE_COS, partIM_COS, temp_COS, SINHF, COSPK, SINPK,
!    &  ALAC, BLAC, TRIGSJBW, JBW, JBW-1, JB,  1, isign )

!------ This FT replaces COS_FTN caus'f poor vec efficiency

        do j=-JB,JB1
           sum= 0.
        do mj=0,JT
           sum= sum + COSFUN2(mj,j)*COSNM(mj)
        end do
                      COSJ(j)= sum
        end do

!------ This FT replaces COS_FTN caus'f poor vec efficiency

         Do J=-JB,JB1
         do mx=-MT,MT
            FWAVEJ(mx,J)= data_SIN(mx,J)
         end do
            FWAVEJ( 0,J)=      COSJ(J)
         END Do

         Do J=-JB,JB1
         do mx=2,MT,2
            FWAVEJ( mx,J)= FWAVEJ( mx,J)*COSLAT(J,1)
            FWAVEJ(-mx,J)= FWAVEJ(-mx,J)*COSLAT(J,1)
         end do
         END Do

         IF(ipole.EQ.+1) CALL POLECUT
c
C-----(mx,J)->(I,J)

         do I=0,IB1
         dO J=0,JB
            BLON(J,I)= 0.
            ALON(J,I)= 0.
         end do
         end do

         do mx=1,MLAST  
                      kev= mxx2(mx,1) ! mx*2
                      kod= mxx2(mx,2) ! kev+1
            IBmx= IB-mx
         Do J=1,JB
            BLON(J,  mx)= ( FWAVEJ( mx,-J)+FWAVEJ(-mx, J))/2.d0
            BLON(J,IBmx)= (-FWAVEJ( mx,-J)+FWAVEJ(-mx, J))/2.d0
            ALON(J,  mx)= ( FWAVEJ(-mx,-J)-FWAVEJ( mx, J))/2.d0
            ALON(J,IBmx)= ( FWAVEJ(-mx,-J)+FWAVEJ( mx, J))/2.d0
         END Do
            J=0
            BLON(J,  mx)= ( FWAVEJ( mx,-J)               )/2.d0
            BLON(J,IBmx)= (-FWAVEJ( mx,-J)               )/2.d0
            ALON(J,  mx)= ( FWAVEJ(-mx,-J)               )/2.d0
            ALON(J,IBmx)= ( FWAVEJ(-mx,-J)               )/2.d0
         end do ! mx=
            mx=0
         Do J=0,JB
            BLON(J,  mx)=   FWAVEJ( mx, J)
            ALON(J,  mx)=   FWAVEJ( mx,-J)
         END Do
            BLON(0,  mx)=   0.  ! to avoid the same input
                if(MT.eq.(IB/2)) then
         Do J=0,JB
            BLON(J,  MT)=   FWAVEJ(-MT, J)
            ALON(J,  MT)=   FWAVEJ(-MT,-J)
         END Do
            BLON(0,  MT)=   0.  ! to avoid the same input
             endif

         CALL GPFA_8_VEC( ALON,BLON,TRIGSIB, 1, IB, IB, 1, isign,JB,JB )

         do I=0,IB1
         DO J=0,JB1
            PSI(I, J )= BLON(J ,I)
            PSI(I,-J )= ALON(J ,I)
         end do
            PSI(I,-JB)= ALON(JB,I)
         END DO

       ENDIF                  
C=============================
C
C===========
      RETURN
      END
C
C
**********************************************************************
*
*-----BEGIN--FFT_P235 : 2004.04.02
*
*     called in FFT_DFS_235_SC, below CALL REALFT( )
*
**********************************************************************

      INCLUDE './FFT_module/GPFASET_8_VEC.FOR'
      INCLUDE './FFT_module/GPFA_8_VEC.FOR'
      INCLUDE './FFT_module/GPFA2F_8_VEC.FOR'
      INCLUDE './FFT_module/GPFA3F_8_VEC.FOR'
      INCLUDE './FFT_module/GPFA5F_8_VEC.FOR'

**********************************************************************
*                                                                    *
*     VISCOSITY-FILTERING(SMOOTHING) BY INVERSION OF ELLIPTIC EQS.   *
*     with COMPLEX TRIDIAGONAL SYSTEM                                *
*                                                                    *
*    [1-LAP], [1+LAP^2], [1-LAP^3], [1+LAP^4]                        *
*                                                                    *
*     remarks : Optimization must be done by inputting two variables *
*                                                                    *
*     01 MAR 2005                                                    *
*                                                                    *
**********************************************************************
      SUBROUTINE ZVISFILT8_JS2( V3, D3, gamma0, LAP_DIM )
       use parameter_pi
       use parameter_dsize
       use parameter_wsize
       use parameter_earth
       use common_trigono_metric_sphere
       use common_metrix
C--------------------------------------------------------------------C
      IMPLICIT  REAL*8 (A-H,O-Z)
C--------------------------------------------------------------------C
      DIMENSION V3(-MT:MT,0:JL),D3(-MT:MT,0:JL)
C-----local-variable-------------------------------------------------C
      DIMENSION AJX_RE(-MT:MT,0:JL),ZDMATmi_a_RE(-MT:MT,3,0:JLH,2,6)
      DIMENSION AJX_IM(-MT:MT,0:JL),ZDMATmi_a_IM(-MT:MT,3,0:JLH,2,6)
      COMPLEX*16 zalpha(8),ZZDMATmi_a(-MT:MT,3,0:JLH,2,6)
C--------------------------------------------------------------------C
      DATA gam_old/0.d0/
C--------------------------------------------------------------------C

      IF(LAP_DIM.gt.6) STOP ' != LAP_DIM must not be larger than 6 !!!'

         gam_new= gamma0
      IF(gam_old.NE.gam_new) THEN
         print*,'gam_new=',gam_new
         print*,'Calculating matrices for HSF'
         gam_old= gam_new        

            if(LAP_DIM.EQ.4) then
               zalpha(1)= -dcmplx(+1.d0,+1.d0)/DSQRT(2.d0)
               zalpha(2)= -dcmplx(-1.d0,+1.d0)/DSQRT(2.d0)
               zalpha(3)= -dcmplx(-1.d0,-1.d0)/DSQRT(2.d0)
               zalpha(4)= -dcmplx(+1.d0,-1.d0)/DSQRT(2.d0)
        elseif(LAP_DIM.EQ.8) then
               do k=1,8
                  xx=(PI+(k-1)*PI2)/8.d0
                 ccc= DCOS(xx) 
                 sss= DSIN(xx) 
               zalpha(k)= -dcmplx(ccc,sss)
               end do
        elseif(LAP_DIM.EQ.6) then
               do k=1,6
                  xx=(PI+(k-1)*PI2)/6.d0
                 ccc= DCOS(xx)
                 sss= DSIN(xx)
               zalpha(k)= -dcmplx(ccc,sss)
               end do
        elseif(LAP_DIM.EQ.5) then
               do k=1,5
                  xx=(   (k-1)*PI2)/5.d0
                 ccc= DCOS(xx)
                 sss= DSIN(xx)
               zalpha(k)= -dcmplx(ccc,sss)
               end do
        elseif(LAP_DIM.EQ.3) then
               zalpha(1)= -dcmplx(+1.d0, 0.d0       )      
               zalpha(2)= -dcmplx(-1.d0, DSQRT(3.d0))/2.d0
               zalpha(3)= -dcmplx(-1.d0,-DSQRT(3.d0))/2.d0
        elseif(LAP_DIM.EQ.2) then
               zalpha(1)= -dcmplx( 0.d0,+1.D0)      
               zalpha(2)= -dcmplx( 0.d0,-1.D0)
        elseif(LAP_DIM.EQ.1) then
               zalpha(1)= -dcmplx( 1.d0, 0.D0)      
         endif

          DO i=1,LAP_DIM 
                    zalpha(i)=  zalpha(i)*gamma0
             CALL ZMAT200S_JS2( zalpha(i), ZZDMATmi_a(-MT,1,0,1,i) ) 
          do k3=1,2
          do k2=0,JLH
          do k1=1,3
          do mx=-MT,MT
            ZDMATmi_a_RE(mx,k1,k2,k3,i)= REal(ZZDMATmi_a(mx,k1,k2,k3,i))
            ZDMATmi_a_IM(mx,k1,k2,k3,i)= IMag(ZZDMATmi_a(mx,k1,k2,k3,i))
          end do
          end do
          end do
          end do
          END DO ! i=1,LAP_DIM 

      ENDIF ! JUSTDOIT

!-beg--filtering---------

           do mj=0,JL
           do mx=-MT,MT
              AJX_RE(mx,mj)= V3(mx,mj)
              AJX_IM(mx,mj)= D3(mx,mj)
           end do
           end do

       DO i=1,LAP_DIM
          CALL ZLAP200S_JS2( AJX_RE, AJX_IM,
     &         ZDMATmi_a_RE(-MT,1,0,1,i), ZDMATmi_a_IM(-MT,1,0,1,i) )
       END DO ! i=1,LAP_DIM

           do mj=0,JL
           do mx=-MT,MT
              V3(mx,mj)= AJX_RE(mx,mj)
              D3(mx,mj)= AJX_IM(mx,mj)
           end do
           end do

!-end--filtering---------

C===============C
      RETURN
      END
C
**********************************************************************
*                                                                    *
*     To solve for psi; COMPLEX VARIABLES                            *
*     psi + alpha* ( LAPLACian of psi ) = X_i,j ,                    *
*     which arises from the high-order spectral filter               *
*                                                                    *
*    [CALL ZMAT200S] -> [CALL ZLAP200S] : COMPLEX-variable version   *
*                                                                    *
*     01 MAR 2005                                                    *
*                                                                    *
**********************************************************************
      SUBROUTINE ZMAT200S_JS2 ( zalpha, ZDMATmi_ )
       use parameter_pi
       use parameter_dsize
       use parameter_wsize
       use parameter_earth
       use common_trigono_metric_sphere
       use common_metrix
C--------------------------------------------------------------------C
      IMPLICIT  REAL*8 (A-H,O-Z)
C--------------------------------------------------------------------C
      COMPLEX*16 zalpha,ZDMATmi_(-MT:MT,3,0:JLH,2)
C-----local variable-------------------------------------------------C
      COMPLEX*16 ZYMATD(-MT:MT,3,0:JLH),zrat
C--------------------------------------------------------------------C
C
      if(zalpha.eq.0.d0) stop 'The zalpha is zero: SUB ZMAT200S_VEC'
C
**************************************************
*BEG  MATRIECS for LAPLACIAN OPERATOR            * SEMI-IMPLICIT
**************************************************

Cbeg-- Matrices for Y= ( D^2/Dlambda^2 + COS(LAT) D/Dphi COS(LAT) D/Dphi ) X

      DO js=1,2
      DO K=0,JLH
      DO i=1,3
      DO mx=-MT,MT
         ZDMATmi_(mx,i,K,js)= AMATm(mx,i,K,js) + zalpha*DMATm(mx,i,K,js)
      END DO
      END DO
      END DO
      END DO

**************************************************
*END  MATRIECS for LAPLACIAN OPERATOR            * SEMI-IMPLICIT
**************************************************
C

C
**************************************************
*BEG  Time saving, prehandling of the MATRIX     * SEMI-IMPLICIT
**************************************************

Cbeg-------------------------------------------------- DMAT -> ZDMAT_
C-----m0,m1,m2,(n1) and m0,m1,m2,(n2)
      DO js=1,2

         do mc=1,JLH-1
          DO mx=-MT,MT
             mx2= -MSQUAR(mx)
            ZYMATD( mx,1,mc)= ZDMATmi_(mx,1,mc,js)
            ZYMATD( mx,2,mc)= ZDMATmi_(mx,2,mc,js) - mx2*zalpha  !  mx2<0
            ZYMATD( mx,3,mc)= ZDMATmi_(mx,3,mc,js)
          END Do
         end do
            mc=0
          DO mx=-MT,MT
             mx2= -MSQUAR(mx)
            ZYMATD( mx,1,mc)= ZDMATmi_(mx,1,mc,js) - mx2*zalpha  !
            ZYMATD( mx,2,mc)= ZDMATmi_(mx,2,mc,js)
          END Do
            mc=JLH
          DO mx=-MT,MT
             mx2= -MSQUAR(mx)
            ZYMATD( mx,1,mc)= ZDMATmi_(mx,1,mc,js)
            ZYMATD( mx,2,mc)= ZDMATmi_(mx,2,mc,js) - mx2*zalpha  !
          END Do
c-------------------
      do mc=0,JLH-1  
         mc1= mc+1   
       Do mx=-MT,MT

          IF(mc.eq.0) then
          if(mx.eq.0 .AND. js.eq.2) then
            zrat= ZYMATD( mx,1,mc1) / ZYMATD( mx,1,mc)
          else
            zrat= 0.d0
          endif
          ELSE
            zrat= ZYMATD( mx,1,mc1) / ZYMATD( mx,1,mc)
          ENDIF

cnext-sub   ZYMAT(mc )= ZYMAT(mc )*zrat
            ZYMATD( mx,2,mc1)= ZYMATD( mx,2,mc1)-ZYMATD( mx,2,mc )*zrat   
cnext-sub   ZYMAT(mc1)= ZYMAT(mc1)-ZYMAT(mc )
            ZYMATD( mx,1,mc1)= ZYMATD( mx,2,mc1)
            ZYMATD( mx,2,mc1)= ZYMATD( mx,3,mc1)

          IF(mc.eq.0) then
          if(mx.eq.0 .AND. js.eq.2) then
            ZDMATmi_( mx,1,mc ,js)= 1.d0/ZYMATD( mx,1,mc ) !! (1/*)
          else
            ZDMATmi_( mx,1,mc ,js)= 0.d0
          endif
          ELSE
            ZDMATmi_( mx,1,mc ,js)= 1.d0/ZYMATD( mx,1,mc ) !! (1/*)
          ENDIF

            ZDMATmi_( mx,2,mc ,js)=      ZYMATD( mx,2,mc )       
            ZDMATmi_( mx,3,mc ,js)= zrat
       END Do ! par
      end do ! mc

       Do mx=-MT,MT
            ZDMATmi_( mx,1,JLH,js)= 1.d0/ZYMATD( mx,1,JLH) !! (1/*)
       END Do ! par

       Do mx=-MT,MT            ! For varying JL, 20 FEB 2007
      do mc=JL_mx(mx,2)+1,JLH
            ZDMATmi_( mx,1,mc ,js)= 0.d0
      end do ! mc
       END Do ! par            ! For varying JL, 20 FEB 2007

      END DO ! js ! js=1,2
Cend-------------------------------------------------- DMAT -> DMAT_

**************************************************
*END  Time saving, prehandling of the MATRIX     * SEMI-IMPLICIT
**************************************************

C===========
      RETURN
      END
C
C
**********************************************************************
*                                                                    *
*     To get psi or Div from : COMPLEX VARIABLES                     *
*                                                                    *
*     psi + zalpha * ( Laplacian of psi ) = Y  : Global Ave[Y] !=0   *
*     Div + zalpha * ( Laplacian of Div ) = Z  : Global Ave[Z]  =0   *
*                                               because [Div]  =0    *
*    [CALL ZMAT200S] -> [CALL ZLAP200S] : COMPLEX-variable version   *
*                                                                    *
*     01 MAR 2005                                                    *
*                                                                    *
**********************************************************************
      SUBROUTINE ZLAP200S_JS2 ( AJX_RE, AJX_IM, ZDMATmi_RE, ZDMATmi_IM )
       use parameter_pi
       use parameter_dsize
       use parameter_wsize
       use parameter_earth
       use common_trigono_metric_sphere
       use common_metrix
C--------------------------------------------------------------------C
      IMPLICIT  REAL*8 (A-H,O-Z)
C--------------------------------------------------------------------C
      DIMENSION AJX_RE(-MT:MT,0:JL),ZDMATmi_RE(-MT:MT,3,0:JLH,2)
      DIMENSION AJX_IM(-MT:MT,0:JL),ZDMATmi_IM(-MT:MT,3,0:JLH,2)
C-----local-variable-------------------------------------------------C
      DIMENSION ZYMAT_RE(-MT:MT,0:JLH),ZYMAT_IM(-MT:MT,0:JLH)
      REAL*8    zaaar,ajx0r,tc10r,parRE,zaaai,ajx0i,tc10i,parIM
C--------------------------------------------------------------------C

         ajx0r= 0.d0
         ajx0i= 0.d0
      do mj=0,JL,2
            dd= DFLOAT(mj)**2-1.D-00
         ajx0r= ajx0r - AJX_RE(0,mj)/dd
         ajx0i= ajx0i - AJX_IM(0,mj)/dd
      end do

c-------------- mx>0, mx<0 ------------c

      DO js=1,2

c---- 1  To get YMAT, YMAT= AMAT*ZETA

         do jcol=1,JLH-1
            jja= jcol2js(jcol-1,js)
            jjb= jcol2js(jcol  ,js)
            jjc= jcol2js(jcol+1,js)
          Do mx=-MT,MT
             a4= AMATm(mx,1,jcol,js)
             a5= AMATm(mx,2,jcol,js)
             a6= AMATm(mx,3,jcol,js)
           ZYMAT_RE(mx,jcol)= a4*AJX_RE(mx,jja)+a5*AJX_RE(mx,jjb)
     &                       +a6*AJX_RE(mx,jjc)
           ZYMAT_IM(mx,jcol)= a4*AJX_IM(mx,jja)+a5*AJX_IM(mx,jjb)
     &                       +a6*AJX_IM(mx,jjc)
          END Do ! par
         end do
            jcol=0
            jjb= jcol2js(jcol  ,js)
            jjc= jcol2js(jcol+1,js)
          Do mx=-MT,MT
             a4= AMATm(mx,1,jcol,js)
             a5= AMATm(mx,2,jcol,js)
           ZYMAT_RE(mx,jcol)= a4*AJX_RE(mx,jjb)+a5*AJX_RE(mx,jjc)                   
           ZYMAT_IM(mx,jcol)= a4*AJX_IM(mx,jjb)+a5*AJX_IM(mx,jjc)                   
          END Do ! par
            jcol=JLH
            jja= jcol2js(jcol-1,js)
            jjb= jcol2js(jcol  ,js)
          Do mx=-MT,MT
             a4= AMATm(mx,1,jcol,js)
             a5= AMATm(mx,2,jcol,js)
           ZYMAT_RE(mx,jcol)= a4*AJX_RE(mx,jja)+a5*AJX_RE(mx,jjb)
           ZYMAT_IM(mx,jcol)= a4*AJX_IM(mx,jja)+a5*AJX_IM(mx,jjb)
          END Do ! par

c---- 2  To get PSI, DMAT*PSI= YMAT

         do mc=0,JLH-1 
            mc1= mc+1
          Do mx=-MT,MT
           ZYMAT_RE(mx,mc1)=  ZYMAT_RE(mx,mc1)
     &                       -ZYMAT_RE(mx,mc )*ZDMATmi_RE(mx,3,mc,js)
     &                       +ZYMAT_IM(mx,mc )*ZDMATmi_IM(mx,3,mc,js)
           ZYMAT_IM(mx,mc1)=  ZYMAT_IM(mx,mc1)
     &                       -ZYMAT_RE(mx,mc )*ZDMATmi_IM(mx,3,mc,js)
     &                       -ZYMAT_IM(mx,mc )*ZDMATmi_RE(mx,3,mc,js)
          END Do ! par
         end do

          Do mx=-MT,MT
                     zaaar =  ZYMAT_RE(mx,JLH)*ZDMATmi_RE(mx,1,JLH,js) !! (1/*)
     &                       -ZYMAT_IM(mx,JLH)*ZDMATmi_IM(mx,1,JLH,js) !! (1/*)
                     zaaai =  ZYMAT_RE(mx,JLH)*ZDMATmi_IM(mx,1,JLH,js) !! (1/*)
     &                       +ZYMAT_IM(mx,JLH)*ZDMATmi_RE(mx,1,JLH,js) !! (1/*)
           ZYMAT_RE(mx,JLH)=  zaaar
           ZYMAT_IM(mx,JLH)=  zaaai
          END Do ! par

         do mco=JLH-1,1,-1
            mcop1=mco+1
          Do mx=-MT,MT
                zaaar=  ZYMAT_RE(mx,mcop1)*ZDMATmi_RE(mx,2,mco,js)
     &                 -ZYMAT_IM(mx,mcop1)*ZDMATmi_IM(mx,2,mco,js)
                zaaai=  ZYMAT_RE(mx,mcop1)*ZDMATmi_IM(mx,2,mco,js)
     &                 +ZYMAT_IM(mx,mcop1)*ZDMATmi_RE(mx,2,mco,js)
                parRE=  ZYMAT_RE(mx,mco)-zaaar
                parIM=  ZYMAT_IM(mx,mco)-zaaai
           ZYMAT_RE(mx,mco)= parRE*ZDMATmi_RE(mx,1,mco,js)
     &                      -parIM*ZDMATmi_IM(mx,1,mco,js)
           ZYMAT_IM(mx,mco)= parRE*ZDMATmi_IM(mx,1,mco,js)
     &                      +parIM*ZDMATmi_RE(mx,1,mco,js)
          END Do ! par
         end do

         do jcol=1,JLH
            jjj= jcol2js(jcol,js)
          Do mx=-MT,MT
            AJX_RE(mx,jjj)= ZYMAT_RE(mx,jcol)
            AJX_IM(mx,jjj)= ZYMAT_IM(mx,jcol)
          END Do ! par
         end do

      END DO ! js=1,2

            AJX_RE( 0, 0 )= 0.d0
            AJX_IM( 0, 0 )= 0.d0

c----AJX->TC1      m=0, Y-even    ( mx=0, js=0 )

         tc10r= 0.d0
         tc10i= 0.d0
      do mj=0,JL,2
            dd= DFLOAT(mj)**2-1.D-00
         tc10r= tc10r - AJX_RE(0,mj)/dd
         tc10i= tc10i - AJX_IM(0,mj)/dd
      end do

            AJX_RE( 0, 0 )= ajx0r - tc10r   ! global-mean correction
            AJX_IM( 0, 0 )= ajx0i - tc10i   ! global-mean correction

C===============C
      RETURN
      END
c
c
**********************************************************************
C
C     In this DFS_global Model,
C     X(j)= SUM_mj ANM(mj)*HALFSINCOSINE is used instead of USUAL
C     form [ X(j)= (1/2) ANM(0) + SUM_mj=1^N ANM(mj)*HALFSINCOSINE ].
C
C     At exit 'CALL GPFA_8_VEC', the coefficients are all normalized.
C
C     Due to the difference in (1/2)ANM(0), the normalization factors
C     are different for wavenum=0 and Nyquist from USUAL routines.
C
**********************************************************************
      SUBROUTINE SIN_FTN
     &( data, partRE, partIM, temp, SINHF, COSPK, SINPK,
     &  ALAT, BLAT, TRIGS, N, N1, ND2, MT, isign )          ! ND2=N/2
**********************************************************************
      IMPLICIT  REAL*8 ( A-H, O-Z )
C---------------------------------------------------------------------
      DIMENSION data(-MT:MT,0:N1),TRIGS(N*2)
C---------------------------------------------------------------------
      DIMENSION partRE(-MT:MT,0:ND2),partIM(-MT:MT,0:ND2),temp(-MT:MT)
      DIMENSION SINHF(0:ND2),COSPK(0:ND2),SINPK(0:ND2)
      DIMENSION ALAT(0:MT,0:N1),BLAT(0:MT,0:N1)
C---------------------------------------------------------------------
C     Calculates the Cosine Fourier transform of a set of n-real valued
C     data points. OUTPUT is NORMALIZED.
C-----
C     f_j= F_1 SIN(pi*(j+0.5)*1/N) + ...... + F_N SIN(pi*(j+0.5)*N/N)
C     F_k= [ sum_j=1^j=N-1 f_j SIN(pi*(j+0.5)*k/N) ] * (2/N)
C     F_N= [ sum_j=0^j=N-1 f_j SIN(pi*(j+0.5)*N/N) ] * (1/N)
C-----
C     FOUR1,REALFT : ARRAY is bounded as 1:N
C     COS_FT       : ARRAY is bounded as 0:N-1
C     SIN_FT       : ARRAY is bounded as 0:N-1
C     REALFT = REALFTN except the NORMALIZATION in REALFTN
C-----
C---------------------------------------------------------------------
C     ISIGN=+1     : INPUT=GRIDS OUTPUT=WAVES
C                                1st data : SIN_1
C                                2nd data : SIN_2 ......
C     ISIGN=-1     : INPUT=WAVES OUTPUT=GRIDS
C                 
C---------------------------------------------------------------------
!     PI = DATAN(1.D-00)*4.D-00
!     PIN= PI/dble(N)
C---------------------------------------------------------------------
!        qCALL= qCALL+1.0D-00
!     IF(qCALL.eq.1.D-00) THEN         ! For a Variable transform
!        do j=0,ND2                    ! Calculates once only
!           aa= PIN*(j+0.5D-00)
!           SINHF(j)= DSIN(aa)
!        end do
!        do k=0,ND2
!           bb= PIN*dble(k)
!           COSPK(k)= DCOS(bb)
!           SINPK(k)= DSIN(bb)
!        end do
!     ENDIF
C---------------------------------------------------------------------

C=============================
          IF(isign.EQ.+1) THEN         ! GRIDS->WAVES
C=============================
C-----                                 ! variable transform
      do j=0,ND2-1
         nj= N1-j
      DO m=-MT,MT
         aa= (data(m,j )-data(m,nj))/2+(data(m,j )+data(m,nj))*SINHF(j)
         bb= (data(m,nj)-data(m,j ))/2+(data(m,nj)+data(m,j ))*SINHF(j)
         data(m, j)= aa
         data(m,nj)= bb
      END DO
      end do
C-----
C-beg------------------------------------------! 2pi periodic FFT ---
!     CALL REALFT( data,N, isign )     ! CALL non-NORMALIZING ROUTINE

         do I=0,N1
         Do J=0,MT
            BLAT( J,I)= data( J,I)
            ALAT( J,I)= data(-J,I)
         end do
            BLAT( 0,I)= 0.d0      ! to avoid the same point 
         END Do

         CALL GPFA_8_VEC( ALAT,BLAT,TRIGS, 1, N, N, 1, isign,MT,MT )

!!!           Output with isign=+1 : BLAT(Nyquist)= SIN or COS (Nyquist)

         do k=1,ND2-1
                      kev= k*2
                      kod= kev+1
            Nk= N-k
         Do m=0,MT
            partRE( m, k )= ( BLAT(m, k )+BLAT(m,Nk))/N
            partRE(-m, k )= ( ALAT(m, k )+ALAT(m,Nk))/N
            partIM( m, k )= (-ALAT(m, k )+ALAT(m,Nk))/N
            partIM(-m, k )= ( BLAT(m, k )-BLAT(m,Nk))/N
         END Do
         end do
         Do m=0,MT
            partRE( m, 0 )=   BLAT(m, 0 )/N
            partRE(-m, 0 )=   ALAT(m, 0 )/N
            partIM( m, 0 )=   0.d0
            partIM(-m, 0 )=   0.d0
            partRE( m,ND2)=   BLAT(m,ND2)/N
            partRE(-m,ND2)=   ALAT(m,ND2)/N
            partIM( m,ND2)=   0.d0
            partIM(-m,ND2)=   0.d0
         END Do

C-end------------------------------------------! 2pi periodic FFT ---

C----- The followings (1-9) are for 'data' is output of SUB REALFT
!1
!     DO m=-MT,MT
!        partRE(m, 0 )= data(m, 0 )        ! COS_0   compo = data(0) 
!        partRE(m,ND2)= data(m, 1 )        ! COS_N/2 compo = data(1)
!        partIM(m, 0 )= 0.                 ! SIN_0   compo
!     END DO
!     do k=1,ND2-1
!        kev= k*2
!        kod= kev+1
!     DO m=-MT,MT
!        partRE(m,k)= data(m,kev)          ! COS compo.
!        partIM(m,k)= data(m,kod)          ! SIN compo.
!     END DO
!9    end do
C-----
      do k=1,ND2-1
         kev= k*2
      DO m=-MT,MT
         data(m,kev)= partRE(m,k)*SINPK(k)+partIM(m,k)*COSPK(k)
      END DO
      end do
      DO m=-MT,MT
         data(m,0)= partRE(m,ND2)        ! SIN_N (=last) compo.
         data(m,1)= partRE(m, 0 )        ! Factor ()/2 deleted because it is
!        data(m,1)= partRE(m, 0 )/2.D-00 ! already done after [CALL GPFA_8_VEC].
      END DO
      do k=1,ND2-1                     ! recurrence
         kod= k*2+1                    ! SIN_k <- COS_2k and SIN_2k (REALFT)
      DO m=-MT,MT
         data(m,kod)= (partRE(m,k)*COSPK(k)-partIM(m,k)*SINPK(k))
     &              +  data(m,kod-2)
      END DO
      end do
C-----
      do m=-MT,MT
         temp(m)   = data(m, 0 )
      END DO
      do j=0,N-2
      do m=-MT,MT
         data(m,j )= data(m,j+1)
      END DO
      end do
      do m=-MT,MT
         data(m,N1)= temp(m)
      END DO
C------
C=============================
      ELSEIF(isign.EQ.-1) THEN         ! WAVES->GRIDS
C=============================
C-----
      DO m=-MT,MT
         temp(m)  = data(m,N1 )        ! To make 1st=SIN_N, 2nd=SIN_1 ...
      END DO 
      do j=N1,1,-1                     ! For here, this is convenient.
      DO m=-MT,MT
         data(m,j)= data(m,j-1)
      END DO 
      end do
      DO m=-MT,MT
         data(m,0)= temp(m)
      END DO 
C-----
      DO m=-MT,MT
!          data(m, 0 )= data(m, 0 )*2. ! See the remarks box
!        partRE(m, 0 )= data(m, 1 )*2. 
           data(m, 0 )= data(m, 0 )    ! Factor (*2.) was deleted
         partRE(m, 0 )= data(m, 1 )    ! to use 'CALL GPFA_8_VEC'
         partIM(m, 0 )= 0.  
         partRE(m,ND2)= data(m, 0 )
      END DO 
      do k=1,ND2-1                     ! SIN_k -> COS_2k and SIN_2k  
         kev= k*2                      !          in REALFT
         kop= kev+1
         kom= kev-1
      DO m=-MT,MT
         partRE(m,k)= data(m,kev)*SINPK(k)
     &              +(data(m,kop)-data(m,kom))*COSPK(k)  
         partIM(m,k)= data(m,kev)*COSPK(k)
     &              -(data(m,kop)-data(m,kom))*SINPK(k)
      END DO 
      end do
      DO m=-MT,MT
         data(m, 0 )= partRE(m, 0 )
         data(m, 1 )= partRE(m,ND2)
      END DO 
      do k=1,ND2-1
         kev= k*2
         kod= kev+1
      DO m=-MT,MT
         data(m,kev)= partRE(m, k )     ! COS compo in REALFT
         data(m,kod)= partIM(m, k )     ! SIN compo in REALFT
      END DO 
      end do
C-----
C-beg------------------------------------------! 2pi periodic FFT ---
!     CALL REALFT( data,N, isign )     ! CALL non-NORMALIZING ROUTINE

      do k=0,N1
      dO m=0,MT
         BLAT(m,k)= 0.
         ALAT(m,k)= 0.
      end do
      end do

      do k=1,ND2-1
                   kev= k*2
                   kod= kev+1
         Nk= N-k
      Do m=1,MT
         BLAT(m, k)= ( data(-m,kod)+data( m,kev))/2.d0
         BLAT(m,Nk)= (-data(-m,kod)+data( m,kev))/2.d0
         ALAT(m, k)= ( data(-m,kev)-data( m,kod))/2.d0
         ALAT(m,Nk)= ( data(-m,kev)+data( m,kod))/2.d0
      END Do
         m=0
         BLAT(m, k)= ( data(-m,kod)             )/2.d0
         BLAT(m,Nk)= (-data(-m,kod)             )/2.d0
         ALAT(m, k)= ( data(-m,kev)             )/2.d0
         ALAT(m,Nk)= ( data(-m,kev)             )/2.d0
      end do
         k=0
      Do m=0,MT
         BLAT(m, k)=   data( m,k  )
         ALAT(m, k)=   data(-m,k  )
      END Do
         BLAT(0, k)=   0. ! to avoid the same input 
         k=ND2
      Do m=0,MT
         BLAT(m, k)=   data( m,1  )
         ALAT(m, k)=   data(-m,1  )
      END Do
         BLAT(0, k)=   0. ! to avoid the same input 

         CALL GPFA_8_VEC( ALAT,BLAT,TRIGS, 1, N, N, 1, isign,MT,MT )

         do I=0,N1
         Do J=0,MT
            data( J,I)= BLAT( J,I)
            data(-J,I)= ALAT( J,I)
         end do
         END Do

C-end------------------------------------------! 2pi periodic FFT ---
      do j=0,ND2-1
         nj=N1-j                       ! GRIDS in REALFT -> GRIDS in COS_FT
      DO m=-MT,MT
         ty= data(m,j )-data(m,nj)
         tx=(data(m,nj)+data(m,j ))/(SINHF(j)*2.)
         data(m, j)= (tx+ty)/2.
         data(m,nj)= (tx-ty)/2.
      END DO 
      end do
C-----
C=============================         ! isign = +-1
       ENDIF
C=============================         ! isign = +-1

C------------------------ NORMALIZATION
      if(isign.eq.+1) then
            sca1N= 1.D-00/N
            sca2N= 2.D-00/N
         do i=0,N-2
         DO m=-MT,MT
c           data(m,i )= data(m,i )*sca2N  ! NMZ is Done in 'GPFA_8_VEC'
         END DO 
         end do
         DO m=-MT,MT
c           data(m,N1)= data(m,N1)*sca1N  ! NMZ is Done in 'GPFA_8_VEC'
         END DO 
      endif
C------------------------ NORMALIZATION
C===========
      RETURN
      END
C
C
**********************************************************************
*                                                                    *
*     Y (:SANM2) = 1/COS(LAT))*(D/DPhi) X (:SANMV)                   *
*                                                                    *
**********************************************************************
      SUBROUTINE ADVECT_Y
     I( SANMV, SANM2 ,MT, JL )
C--------------------------------------------------------------------C
      IMPLICIT  REAL*8 (A-H,O-Z)
C--------------------------------------------------------------------C
      DIMENSION SANM2(-MT:MT,0:JL),SANMV(-MT:MT,0:(JL+1))
C--------------------------------------------------------------------C
C-m=1,3,...
      do mj=1,JL             ! (1/COS(LAT))*(D/DPhi) (v*COS(LAT)*Vor)
         mjp1=mj+1
         mjm1=mj-1
      Do mx=-MT+1,MT-1,2 ! parallel
      SANM2(mx,mj)=  ((mjp1)*SANMV(mx,mjm1)-(mjm1)*SANMV(mx,mjp1))/2.D0
      END Do ! par
      end do
C-m=2,4,...
      do mj=1,JL             ! (1/COS(LAT))*(D/DPhi) (v*COS(LAT)*Vor)
         mjp1=mj+1
         mjm1=mj-1
         mjp2=mj+2
         mjm2=mj-2
      Do mx=-MT,-2,2 ! parallel 
      SANM2(mx,mj)=  ((mjp2)*SANMV(mx,mjm1)-(mjm2)*SANMV(mx,mjp1))/2.D0
      END Do ! par
      Do mx= +2,MT,2 ! parallel 
      SANM2(mx,mj)=  ((mjp2)*SANMV(mx,mjm1)-(mjm2)*SANMV(mx,mjp1))/2.D0
      END Do ! par
      end do
C-m=0
         mx=0                ! (1/COS(LAT))*(D/DPhi) (v*COS(LAT)*Vor)
      do mj=1,JL-1
      SANM2(mx,mj)=  ((mj+1)*SANMV(mx,mj-1)-(mj-1)*SANMV(mx,mj+1))/2.D0
      end do
      SANM2(mx,0 )=          SANMV(mx,0+1) /2.D0
      SANM2(mx,1 )=   ( 1+1)*SANMV(mx,  0)
                             ! for global conservation: Cheong(JCP2000)
         mj=JL               ! JL should be even number
      SANM2(mx,mj)=  ((mj+1)*SANMV(mx,mj-1)                      )/2.D0
C
C===============C
      RETURN
      END
C
C
**********************************************************************
*                                                                    *
*     To make GLOBAL AVERAGE zero ( When MAKE_0 = +1 )               *
*                                                                    *
**********************************************************************
      SUBROUTINE GLOBAL0 ( AJX, sum, MAKE_0 )  ! MAKE_0 =+1 : Make 0
       use parameter_pi
       use parameter_dsize
       use parameter_wsize
       use parameter_earth
       use common_trigono_metric_sphere
       use common_metrix
C--------------------------------------------------------------------C
      IMPLICIT  REAL*8 (A-H,O-Z)
C--------------------------------------------------------------------C
      DIMENSION AJX(-MT:MT,0:JL)
C--------------------------------------------------------------------C

          sum= 0.                      ! global mean
      do mj=0,JL,2
           dd= DFLOAT(mj)**2-1.D-00
          sum= sum - AJX(0,mj)/dd
      end do

      IF(MAKE_0.eq.+1) AJX(0,0)= AJX(0,0) - sum  ! global-mean subtracted

C===============C
      RETURN
      END
C
C
**********************************************************************
*                                                                    *
*     U*COS(LAT), V*COS(LAT) FROM STREAMFUNCTION                     *
*                                                                    *
*     09 NOV 2006                                                    *
*                                                                    *
**********************************************************************
      SUBROUTINE PSItoUVC                ! SANMU : - of Y-diff.
!     SUBROUTINE PSItoUVC_FullWaveSpace  !SANMU : - of Y-diff.
     I( P2, SANMU,SANM2, MT, JL )        ! SANMV : + of X-diff.
C--------------------------------------------------------------------C
      IMPLICIT  REAL*8 (A-H,O-Z)
C--------------------------------------------------------------------C
      DIMENSION P2(-MT:MT,0:JL)
      DIMENSION SANMU(-MT:MT,0:JL),SANM2(-MT:MT,0:JL)
C--------------------------------------------------------------------C

C-psi:m=1,3,...  U : y-dif
                                            !  u*COS(Lat)=
      do mj=1,JL-2                          ! -(Y-dif OF PSI)*COS(Lat)
         mjp1=mj+1
         mjm1=mj-1
      Do mx=-MT+1,MT-1,2 ! parallel
         SANMU(mx,mj)=-((mjm1)*P2(mx,mjm1)-(mjp1)*P2(mx,mjp1))/2.D0
      END Do ! par
      end do
         mj=JL-1
         mjm1=mj-1
      Do mx=-MT+1,MT-1,2 ! parallel
         SANMU(mx,mj)= -(mjm1)*P2(mx,mjm1) /2.D0
      END Do ! par
         mj=JL
         mjm1=mj-1
      Do mx=-MT+1,MT-1,2 ! parallel
         SANMU(mx,mj)= -(mjm1)*P2(mx,mjm1) /2.D0
      END Do ! par
c
C                V : x-dif
c
      do mj=1,JL                            !!
      Do mx=-MT+1,MT-1,2 ! parallel
         SANM2(mx,mj)=  P2(-mx,mj)*(-mx)    !  X-dif of PSI =  v*COS(LAT)
      END Do ! par
      end do
c
C-psi:m=2,4,...  u : y-dif
      do mj=1,JL-2                          !  u=
         mjp1=mj+1                          ! -(Y-dif OF ([PSI^*]*[COSLAT]))
         mjm1=mj-1
      Do mx=-MT,-2,2 ! parallel
         SANMU(mx,mj)= -(mj  )*(P2(mx,mjm1)-P2(mx,mjp1))/2.D0
      END Do ! par
      Do mx= +2,MT,2 ! parallel
         SANMU(mx,mj)= -(mj  )*(P2(mx,mjm1)-P2(mx,mjp1))/2.D0
      END Do ! par
      end do
         mj=JL-1
         mjp1=mj+1
         mjm1=mj-1
      Do mx=-MT,-2,2 ! parallel
         SANMU(mx,mj)= -(mj  )* P2(mx,mjm1)             /2.D0
     &                                     -P2(mx,mjp1)
      END Do ! par
      Do mx= +2,MT,2 ! parallel
         SANMU(mx,mj)= -(mj  )* P2(mx,mjm1)             /2.D0
     &                                     -P2(mx,mjp1)
      END Do ! par
         mj=JL
         mjm1=mj-1
      Do mx=-MT,-2,2 ! parallel
         SANMU(mx,mj)= -(mj  )* P2(mx,mjm1) /2.D0  !! +1 level
      END Do ! par
      Do mx= +2,MT,2 ! parallel
         SANMU(mx,mj)= -(mj  )* P2(mx,mjm1) /2.D0  !! +1 level
      END Do ! par
c
C                V : x-dif
c
      do mj=0,JL
      Do mx=-MT,MT,2 ! parallel             ! v=
         SANM2(mx,mj)=  P2(-mx,mj)*(-mx)    ! X-dif of [PSI^*]
      END Do ! par
      end do
c
C-psi:m=0        U : y-dif
         mx=0                               !  u*COS(Lat)=
      do mj=1,JL-2                          ! -(Y-dif OF PSI)*COS(Lat)
         SANMU(mx,mj)=-((mj-1)*P2(mx,mj-1)-(mj+1)*P2(mx,mj+1))/2.D0
      end do
         mj=JL-1
         SANMU(mx,mj)=-((mj-1)*P2(mx,mj-1)                   )/2.D0
         SANMU(mx,JL)=   0.d0
         SANMU(mx,0 )=  ( 0+1)*P2(mx,0+1 ) /2.D0
c
C                V : x-dif = 0
c
C===============C
      RETURN
      END
C

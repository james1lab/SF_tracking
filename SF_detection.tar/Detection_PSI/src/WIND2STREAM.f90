!23456789012345678901234567890123456789012345678901234567890123456789012
!                                                                    c
!     Department of Environmental Atmospheric Sciences               c
!     Pukyong National University                                    c
!                                                                    c
!-----------------------------------------------------------------------
!-----------------------------------------------------------------------
!
!                    WIND2STREAM.f
!     Streamfunction calculated from horizontal wind
!
!                                               In-Hyuk Kwon 06 OCT 2009
!                                               Hyeong-Bin Cheong
!
!-----------------------------------------------------------------------
      SUBROUTINE WIND2STREAM( uwnd,vwnd,psi )
! ----------------------------------------------------------------------
       use parameter_dsize
       use parameter_wsize
       use common_trigono_metric_sphere
       implicit none
       real,dimension(0:IB1,-JB:JB1),intent(in)  :: uwnd,vwnd
       real,dimension(0:IB1,-JB:JB1),intent(out) :: psi
       real(kind=8),dimension(0:IB1,-JB:JB1) :: SORK1,SORK2
       real(kind=8),dimension(-MT:MT,0:JL)     :: SANM1,SANM2,V1,D1,P1
       real(kind=8),dimension(-MT:MT,0:(JL+1)) :: SANMU,SANMV
       integer :: i,j,mx,mj
! ----------------------------------------------------------------------

      do j=-JB,JB1
      do i=0,IB1
         SORK1(I,J)= uwnd(I,J) / COSLAT(J,2)
         SORK2(I,J)= vwnd(I,J) / COSLAT(J,2)
      end do
      end do

      CALL FFT_DFS_235_SC( +1, SORK1, SANMU, JL+1, -1 )   ! is=1:->Wa, ip=1:cut
      CALL FFT_DFS_235_SC( +1, SORK2, SANMV, JL+1, -1 )   ! is=1:->Wa, ip=1:cut

      CALL ADVECT_Y( SANMU, SANM1, MT, JL  )
      CALL ADVECT_Y( SANMV, SANM2, MT, JL  )

      do mj=0,JL
      do mx=-MT,MT
         V1(mx,mj)= SANMV(-mx,mj)*(-mx) - SANM1(mx,mj)
         D1(mx,mj)= SANMU(-mx,mj)*(-mx) + SANM2(mx,mj)
      end do
      end do

      CALL LAP200E_JS2( P1, V1, 1  )
      
      CALL FFT_DFS_235_SC( -1, sork1, P1, JL, -1 )

       psi(:,:)= SORK1(:,:)
        
! ----------------------------------------------------------------------
      END SUBROUTINE WIND2STREAM
!-----------------------------------------------------------------------

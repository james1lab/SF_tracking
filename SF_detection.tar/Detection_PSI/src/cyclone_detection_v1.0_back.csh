#!/bin/csh -xf

######################################################################## 
# Code developer: Dr. Jae-Deok Lee (ruio1084@gmail.com)
# Department of Atmospheric Science, Kongju National University
# ERA5 reanalysis data (2001-2020).
# Please email me if you have any query
#
######################################################################## 

set curdir = ($PWD ) # DO NOT CHANGE
set years=$1            # START YEAR

cat <<EOF> CYCLONE_TRACKING.f90
      PROGRAM CYCLONE_TRACKING
      USE PARAMETER_DSIZE
      USE PARAMETER_WSIZE
      USE PARAMETER_EARTH
      USE parameter_pi
      USE COMMON_TRIGONO_METRIC_SPHERE
      USE COMMON_ENM1_CosSinLat

      IMPLICIT NONE
      INTEGER :: I,J,K,T,P,Q,TIMESET,IIP,IIM,JJP,JJM,II,JJ,DIS
      INTEGER :: JS1,JE1,JS2,JE2,ICOUNT,ICOUNT1,ICOUNT2
      INTEGER :: IS1,IE1,IS2,IE2,IPERIOD,IYEAR,IMONTH,IDAY,IHOUR
      INTEGER :: EYEAR
      INTEGER :: YEAR,MONTH,DAY,HOUR
      INTEGER :: NX,NY,NZ,NT
      INTEGER :: LAP_DIM,AREA
      INTEGER,ALLOCATABLE,DIMENSION(:) :: YEAR1,MONS1,DAYS1,HOUR1
      REAL(KIND=4) :: MVOR,MWIND,SUM1,SUM2,VORTICITY,DISTAN
      REAL(KIND=4) :: PSICAND,WMAX,PMIN,XVIS,MCUT,LAND,NORMALP
      REAL(KIND=8) :: GAMMA0
      REAL(KIND=4),PARAMETER :: PSIMIN=-0.5,MRADIUS=300.,LRADIUS=100
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: LAT,LON
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:) :: FRORK1,FRORK2,IDATA4
      REAL(KIND=8),ALLOCATABLE,DIMENSION(:,:) :: FWORK1,FWORK2,FWORK3
      REAL(KIND=8),ALLOCATABLE,DIMENSION(:,:) :: ANM1,ANM2,IDATA8
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:) :: WMAG,LANDSEA,TOPO
!-----850, 700, 500, 300, 200 hPa
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:) :: MSLP,DMSLP,SST,VOR2D,MSLP2D
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:) :: DVOR2D,DMSLP2D
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:) :: THETA500,THETA300,THETA700,HEIGHT
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:) :: DPSI1000,DPSI850,DPSI700,DPSI500
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:) :: DPSI_MERGE,DVORT_MERGE

      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:,:) :: UGRD,VGRD,VORT,HGT
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:,:) :: PSI,TMP,THETA
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:,:) :: DVORT,IDVORT,DHGT
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:,:) :: DUGRD,DVGRD
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:,:) :: DATA1,DATA2
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:,:) :: DATA3,DATA4
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:,:) :: DATA5,DATA6
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:,:) :: DATA7,DATA8
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:,:) :: DPSI
      REAL(KIND=4),DIMENSION(12) :: PLEVS

      CHARACTER(4) :: CYEAR
      CHARACTER(2) :: CMONTH,CDAY,CHOUR
      CHARACTER(200),DIMENSION(300) :: FILE
      CHARACTER(200),DIMENSION(10) :: VARIABLES
      CHARACTER(200) :: VAR
      LOGICAL::DETER

      DATA PLEVS / 1000, 950, 900, 850, 800, 750, 700, 650, 600, 500, 300, 200 /

      ALLOCATE (LAT(-JB:JB),LON(0:IB1))

!-----------------------------------------------------------------------
!     LON/LAT CALCULATION
!-----------------------------------------------------------------------

      DO I = 0,IB1
      LON(I) = 360.*(1.*I/IB)
      ENDDO

      DO J = -JB,JB
      LAT(J) = 180.*(1.*J/JBW)
      ENDDO

!-----------------------------------------------------------------------
!     Begin
!-----------------------------------------------------------------------

!------------------------------------------------------------------------
!      SUBROUTINE CALL
!------------------------------------------------------------------------
!
!     FILTERING PART
!     FULL GRID FILTERING USING FINITE ELEMENT METHOD (FEM)
!
!                   PROVIDED FROM PUKYOUNG NAT. UNIV.
!                             NUMERICAL WEATHER PREDICTION & DYNAMIC LAB.
!                                                     PROF. H.-B. CHEONG.
!------------------------------------------------------------------------

      CALL SINCOS_MERI
      CALL MAT200E_JS2
      CALL COS_SIN_LAT
      CALL TEST_FFT_FULLGRID
      CALL MAT200E_JS2_FEM
      CALL MATM_VOR_UV_JS2_FEM

!-------ERA5 pressure levels: 1000, 850, 700, 500, 300, 200
! Output txt  : 100~
!  Input bin  : 200~
! Output bin  : 300~

      OPEN(100, file="../Archive/${years}/ETCs.txt")
!---Original data
      OPEN(300, file="../Archive/${years}/MSLP.bin",                  &
               access="direct",form="unformatted",recl=IB*(JBW+1)*4)
!      OPEN(301, file="../Archive/${years}/THETA.bin",                 &
!               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
!      OPEN(302, file="../Archive/${years}/TOPO.bin",                          &
!               access="direct",form="unformatted",recl=IB*(JBW+1)*4)
!      OPEN(303, file="../Archive/${years}/UGRD.bin",                  &
!               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
!      OPEN(304, file="../Archive/${years}/VGRD.bin",                  &
!               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
!      OPEN(305, file="../Archive/${years}/VORT.bin",                  &
!               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
!      OPEN(306, file="../Archive/${years}/HGT.bin",                  &
!               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)

!---Filtered  data
      OPEN(400, file="../Archive/${years}/DMSLP.bin",                  &
               access="direct",form="unformatted",recl=IB*(JBW+1)*4)
      OPEN(401, file="../Archive/${years}/DUGRD.bin",                  &
               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
      OPEN(402, file="../Archive/${years}/DVGRD.bin",                  &
               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
!      OPEN(403, file="../Archive/${years}/DVORT.bin",                 &
!               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
      OPEN(404, file="../Archive/${years}/DPSI.bin",                 &
               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
!      OPEN(407, file="../Archive/${years}/IDVORT.bin",                        &
!               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
!      OPEN(408, file="../Archive/${years}/DHGT.bin",                 &
!               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
      OPEN(410, file="../Archive/${years}/DPSI_MERGE.bin",                 &
               access="direct",form="unformatted",recl=IB*(JBW+1)*4)
!      OPEN(411, file="../Archive/${years}/DVORT_MERGE.bin",                 &
!               access="direct",form="unformatted",recl=IB*(JBW+1)*4)

!      OPEN(500, file="../Archive/${years}/DUGRD_12.bin",                  &
!               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
!      OPEN(501, file="../Archive/${years}/DVGRD_12.bin",                  &
!               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
!      OPEN(502, file="../Archive/${years}/DUGRD_40.bin",                  &
!               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
!      OPEN(503, file="../Archive/${years}/DVGRD_40.bin",                  &
!               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)

!      GOTO 800
      IYEAR = ${years}
      EYEAR = ${years}
      IMONTH = 1
      IDAY = 1
      IHOUR = 0
      T = 1

      DO 
      IF( IYEAR > EYEAR ) GOTO 999

!-----Set the serching period !!!
!      IF(IMONTH >=1 .and. IMONTH<= 1) THEN

      WRITE(CYEAR,'(I4.4)') IYEAR
      WRITE(CMONTH,'(I2.2)') IMONTH
      WRITE(CDAY,'(I2.2)') IDAY
      WRITE(CHOUR,'(I2.2)') IHOUR

      WRITE(*,'(4(A,2x))') CYEAR,CMONTH,CDAY,CHOUR

      OPEN(200, file="/data4/jdlee/DATA/ERA5/bin/"//CYEAR//"/mslPRES."     &
                                          //CYEAR//CMONTH//CDAY//CHOUR, &
               access="direct",form="unformatted",recl=IB*(JBW+1)*4)
      OPEN(201, file="/data4/jdlee/DATA/ERA5/bin/"//CYEAR//"/LANDSEA."     &
                                          //CYEAR//CMONTH//CDAY//CHOUR, &
               access="direct",form="unformatted",recl=IB*(JBW+1)*4)
      OPEN(202, file="/data4/jdlee/DATA/ERA5/bin/"//CYEAR//"/SST."     &
                                          //CYEAR//CMONTH//CDAY//CHOUR, &
               access="direct",form="unformatted",recl=IB*(JBW+1)*4)
      OPEN(203, file="/data4/jdlee/DATA/ERA5/bin/"//CYEAR//"/TOPO."     &
                                          //CYEAR//CMONTH//CDAY//CHOUR, &
               access="direct",form="unformatted",recl=IB*(JBW+1)*4)
      OPEN(204, file="/data4/jdlee/DATA/ERA5/bin/"//CYEAR//"/UGRD."     &
                                          //CYEAR//CMONTH//CDAY//CHOUR, &
               access="direct",form="unformatted",recl=IB*(JBW+1)*4)
      OPEN(205, file="/data4/jdlee/DATA/ERA5/bin/"//CYEAR//"/VGRD."     &
                                          //CYEAR//CMONTH//CDAY//CHOUR, &
               access="direct",form="unformatted",recl=IB*(JBW+1)*4)
      OPEN(206, file="/data4/jdlee/DATA/ERA5/bin/"//CYEAR//"/TMP."     &
                                          //CYEAR//CMONTH//CDAY//CHOUR, &
               access="direct",form="unformatted",recl=IB*(JBW+1)*4)
      OPEN(207, file="/data4/jdlee/DATA/ERA5/bin/"//CYEAR//"/HGT."     &
                                          //CYEAR//CMONTH//CDAY//CHOUR, &
               access="direct",form="unformatted",recl=IB*(JBW+1)*4)

!-----2-Dimensional variables
      ALLOCATE (IDATA4(0:IB1,-JB:JB),IDATA8(0:IB1,-JB:JB)) 
      ALLOCATE (FRORK1(0:IB1,-JB:JB),FRORK2(0:IB1,-JB:JB)) 
      ALLOCATE (FWORK1(0:IB1,-JB:JB),FWORK2(0:IB1,-JB:JB)) 
      ALLOCATE (FWORK3(0:IB1,-JB:JB)) 
      ALLOCATE (WMAG(0:IB1,-JB:JB),MSLP(0:IB1,-JB:JB))
      ALLOCATE (DMSLP(0:IB1,-JB:JB))
      ALLOCATE (MSLP2D(0:IB1,-JB:JB), VOR2D(0:IB1,-JB:JB))
      ALLOCATE (DMSLP2D(0:IB1,-JB:JB), DVOR2D(0:IB1,-JB:JB))
      ALLOCATE (LANDSEA(0:IB1,-JB:JB),TOPO(0:IB1,-JB:JB),SST(0:IB1,-JB:JB))

!-----3-Dimensional variables
      ALLOCATE ( UGRD(0:IB1,-JB:JB,KB),  VGRD(0:IB1,-JB:JB,KB))
      ALLOCATE ( TMP(0:IB1,-JB:JB,KB), THETA(0:IB1,-JB:JB,KB) )
      ALLOCATE ( HGT(0:IB1,-JB:JB,KB) )
      ALLOCATE ( DHGT(0:IB1,-JB:JB,KB) )
      ALLOCATE ( THETA700(0:IB1,-JB:JB) )
      ALLOCATE ( THETA500(0:IB1,-JB:JB) )
      ALLOCATE ( THETA300(0:IB1,-JB:JB) )
      ALLOCATE ( DPSI1000(0:IB1,-JB:JB) )
      ALLOCATE ( DPSI850(0:IB1,-JB:JB) )
      ALLOCATE ( DPSI700(0:IB1,-JB:JB) )
      ALLOCATE ( DPSI500(0:IB1,-JB:JB) )
      ALLOCATE ( HEIGHT(0:IB1,-JB:JB) )
      ALLOCATE (DUGRD(0:IB1,-JB:JB,KB), DVGRD(0:IB1,-JB:JB,KB))
      ALLOCATE (DATA1(0:IB1,-JB:JB,KB), DATA2(0:IB1,-JB:JB,KB))
      ALLOCATE (DATA3(0:IB1,-JB:JB,KB), DATA4(0:IB1,-JB:JB,KB))
      ALLOCATE (DATA5(0:IB1,-JB:JB,KB), DATA6(0:IB1,-JB:JB,KB))
      ALLOCATE (DATA7(0:IB1,-JB:JB,KB), DATA8(0:IB1,-JB:JB,KB))
      ALLOCATE (VORT(0:IB1,-JB:JB,KB), DVORT(0:IB1,-JB:JB,KB))
      ALLOCATE (PSI(0:IB1,-JB:JB,KB), DPSI(0:IB1,-JB:JB,KB))
      ALLOCATE (IDVORT(0:IB1,-JB:JB,KB))
      ALLOCATE (DPSI_MERGE(0:IB1,-JB:JB), DVORT_MERGE(0:IB1,-JB:JB))
!-----Filtering variables
      ALLOCATE ( ANM1(-MT:MT,-JB:JB), ANM2(-MT:MT,-JB:JB) )
!-----------------------------------------------------------------------

      READ(200,rec=1) MSLP(:,:)
      READ(201,rec=1) LANDSEA(:,:)
      READ(202,rec=1) SST(:,:)
      READ(203,rec=1) TOPO(:,:)
      DO K = 1,KB
       READ(204,rec=K) UGRD(:,:,K)
       READ(205,rec=K) VGRD(:,:,K)
       READ(206,rec=K) TMP(:,:,K)
       READ(207,rec=K) HGT(:,:,K)
      ENDDO
      CLOSE(200);CLOSE(201);CLOSE(202);CLOSE(203);CLOSE(204);CLOSE(205)
      CLOSE(206);CLOSE(207)

      DO J = -JB,JB
      DO I = 0,IB1
       IF(SST(I,J) > 1.E+4) SST(I,J) =18.+273.15
       IF(SST(I,J) ==  0. ) SST(I,J) =18.+273.15
      ENDDO
      ENDDO

      IDATA4(:,:) =0.
      CALL REVERS( MSLP(:,:), IDATA4(:,:) )
      MSLP(:,:) = IDATA4(:,:)/100.

      IDATA4(:,:) =0.
      CALL REVERS( SST(:,:), IDATA4(:,:) )
      SST(:,:) = IDATA4(:,:)-273.15

      IDATA4(:,:) =0.
      CALL REVERS( LANDSEA(:,:), IDATA4(:,:) )
      LANDSEA(:,:) = IDATA4(:,:)

      IDATA4(:,:) =0.
      CALL REVERS( TOPO(:,:), IDATA4(:,:) )
      TOPO(:,:) = IDATA4(:,:)/9.81

      DO K = 1, KB
       IDATA4(:,:) =0.
       CALL REVERS( UGRD(:,:,K), IDATA4(:,:) )
       UGRD(:,:,K) = IDATA4(:,:)
 
       IDATA4(:,:) =0.
       CALL REVERS( VGRD(:,:,K), IDATA4(:,:) )
       VGRD(:,:,K) = IDATA4(:,:)

       IDATA4(:,:) =0.
       CALL REVERS( TMP(:,:,K), IDATA4(:,:) )
       TMP(:,:,K) = IDATA4(:,:)

       IDATA4(:,:) =0.
       CALL REVERS( HGT(:,:,K), IDATA4(:,:) )
       HGT(:,:,K) = IDATA4(:,:)

       THETA(:,:,K)=TMP(:,:,K)*(PLEVS(K)/1000.)**0.286
      ENDDO

      TMP(:,:,:) = TMP(:,:,:)-273.15


       DMSLP(:,:)=0.; DUGRD(:,:,:)=0. ; DVGRD(:,:,:)=0. 
       DVORT(:,:,:)=0. ; DPSI(:,:,:)=0. ; IDVORT(:,:,:)=0.
       DHGT(:,:,:)=0.; DPSI(:,:,:)=0.

!------------------------------------------------------------------------
!      MAIN CALCULATION
!------------------------------------------------------------------------
      DATA1(:,:,:)=0.
      DATA2(:,:,:)=0.

      MCUT = 14
      LAP_DIM=4
      XVIS=1.0
      GAMMA0= VISCO(LAP_DIM,XVIS,MCUT)
       FWORK1(:,:)=MSLP(:,:)
       CALL FILTERING_SUBS(FWORK1,GAMMA0,LAP_DIM)
       DATA1(:,:,1)= FWORK1(:,:)

      MCUT = 60
      LAP_DIM=4
      XVIS=1.0
      GAMMA0= VISCO(LAP_DIM,XVIS,MCUT)
       FWORK2(:,:)=MSLP(:,:)
       CALL FILTERING_SUBS(FWORK1,GAMMA0,LAP_DIM)
       DATA2(:,:,1)= FWORK2(:,:)

       DMSLP(:,:)=DATA2(:,:,1)-DATA1(:,:,1)

      DATA1(:,:,:)=0.
      DATA2(:,:,:)=0.
      DATA3(:,:,:)=0.
      DATA4(:,:,:)=0.
      DATA5(:,:,:)=0.
      DATA6(:,:,:)=0.
      DATA7(:,:,:)=0.
      DATA8(:,:,:)=0.

!------Vertical Loop Calculations
      DO K = 1, KB

      MCUT = 14
      LAP_DIM=4
      XVIS=1.0
      GAMMA0= VISCO(LAP_DIM,XVIS,MCUT)

       FWORK1(:,:)=UGRD(:,:,K)
       CALL FILTERING_SUBS(FWORK1,GAMMA0,LAP_DIM)
       DATA1(:,:,K)= FWORK1(:,:)

       FWORK1(:,:)=VGRD(:,:,K)
       CALL FILTERING_SUBS(FWORK1,GAMMA0,LAP_DIM)
       DATA3(:,:,K)= FWORK1(:,:)

       FWORK1(:,:)=HGT(:,:,K)
       CALL FILTERING_SUBS(FWORK1,GAMMA0,LAP_DIM)
       DATA5(:,:,K)= FWORK1(:,:)

      MCUT = 60
      LAP_DIM=4
      XVIS=1.0
      GAMMA0= VISCO(LAP_DIM,XVIS,MCUT)
       FWORK1(:,:)=UGRD(:,:,K)
       CALL FILTERING_SUBS(FWORK1,GAMMA0,LAP_DIM)
       DATA2(:,:,K)= FWORK1(:,:)

       FWORK1(:,:)=VGRD(:,:,K)
       CALL FILTERING_SUBS(FWORK1,GAMMA0,LAP_DIM)
       DATA4(:,:,K)= FWORK1(:,:)

       FWORK1(:,:)=HGT(:,:,K)
       CALL FILTERING_SUBS(FWORK1,GAMMA0,LAP_DIM)
       DATA6(:,:,K)= FWORK1(:,:)

       DUGRD(:,:,K)= DATA2(:,:,K)-DATA1(:,:,K)
       DVGRD(:,:,K)= DATA4(:,:,K)-DATA3(:,:,K)
       DHGT(:,:,K)= DATA6(:,:,K)-DATA5(:,:,K)

!-----Vorticity Calculation
       FWORK1(:,:) =0.
       FWORK2(:,:) =0.
       CALL FDM_DIFF_CODE_DX (LAT,LON,DVGRD(:,:,K),FWORK1)
       CALL FDM_DIFF_CODE_DY (LAT,LON,DUGRD(:,:,K),FWORK2)
       DVORT(:,:,K)=FWORK1(:,:)-FWORK2(:,:)

       FWORK1(:,:) =0.
       FWORK2(:,:) =0.
       CALL FDM_DIFF_CODE_DX (LAT,LON,VGRD(:,:,K),FWORK1)
       CALL FDM_DIFF_CODE_DY (LAT,LON,UGRD(:,:,K),FWORK2)
       VORT(:,:,K)=FWORK1(:,:)-FWORK2(:,:)

!-----------------------------------------------------------------------
!-----Laplacian inversion part to get the streamfunction of relative vorticity
!-----i.e., VORTICITY FIELD -> STREAMFUNCTION
!-----------------------------------------------------------------------
      IDATA8(:,:) =0.
!-----Filtered Vorticity (synoptic and mesoscale) 
      IDATA8(:,:)=DVORT(:,:,K)
      CALL FFT_DFS_235_SC_FULLGRID_X_TRANS                              &
      ( +1, IDATA8(:,:), ANM1, JBW, -1 ) ! IS=1:->WA, IP=1:CUT

!-----Laplacian inversion
      CALL LAP200E_JS2_FEM ( ANM2, ANM1 , 1 )

!----------VORTICITY FIELD -> STREAMFUNCTION
      CALL FFT_DFS_235_SC_FULLGRID_X_TRANS                              &
      ( -1, IDATA8(:,:), ANM2, JBW, -1 ) ! IS=1:->WA, IP=1:CUT
      DPSI(:,:,K) = IDATA8(:,:)*1.E7

!-----Filtered Vorticity (synoptic and mesoscale) 
      IDATA8(:,:)=DPSI(:,:,K)
      CALL FFT_DFS_235_SC_FULLGRID_X_TRANS                              &
      ( +1, IDATA8(:,:), ANM1, JBW, -1 ) ! IS=1:->WA, IP=1:CUT

!-----Laplacian inversion
      CALL LAP200E_JS2_FEM ( ANM1, ANM2 , 0 )

!----------STREAMFUNCTION -> VORTICITY FIELD 
      CALL FFT_DFS_235_SC_FULLGRID_X_TRANS                              &
      ( -1, IDATA8(:,:), ANM2, JBW, -1 ) ! IS=1:->WA, IP=1:CUT
      IDVORT(:,:,K) = IDATA8(:,:)

      DO J = -JB,JB
      DO I= 0,IB1
       DPSI(I,J,K)= DPSI(I,J,K)*(LAT(J)/ABS(LAT(J)))
      ENDDO
      ENDDO
      ENDDO ! ENDDO FOR K 

      CALL VERTICAL_INTEGRATION(DPSI,PLEVS,3,7,DPSI_MERGE)
!      CALL VERTICAL_INTEGRATION(DVORT,PLEVS,3,7,DVORT_MERGE)

      WRITE(300,rec=T) MSLP(:,:)
!      WRITE(301,rec=T) THETA(:,:,:)
!      IF( T==1) THEN
!      WRITE(302,rec=1) TOPO(:,:)
!      ENDIF
!      WRITE(303,rec=T) UGRD(:,:,:)
!      WRITE(304,rec=T) VGRD(:,:,:)
!      WRITE(305,rec=T) VORT(:,:,:)
!      WRITE(306,rec=T) HGT(:,:,:)

       WRITE(400,rec=T) DMSLP(:,:)
       WRITE(401,rec=T) DUGRD(:,:,:)
       WRITE(402,rec=T) DVGRD(:,:,:)
!       WRITE(403,rec=T) DVORT(:,:,:)
       WRITE(404,rec=T) DPSI(:,:,:)
!       WRITE(407,rec=T) IDVORT(:,:,:)
!       WRITE(408,rec=T) DHGT(:,:,:)
       WRITE(410,rec=T) DPSI_MERGE(:,:)
!       WRITE(411,rec=T) DVORT_MERGE(:,:)

!       WRITE(500,rec=T) DATA1(:,:,:)
!       WRITE(501,rec=T) DATA3(:,:,:)
!       WRITE(502,rec=T) DATA2(:,:,:)
!       WRITE(503,rec=T) DATA4(:,:,:)

!-----------------------------------------------------------------------
!     SEARCHING POTENTIAL VORTEX ON NHP
!-----------------------------------------------------------------------

      DO J = -JB,JB
       IF(LAT(J) >= -88.) THEN 
        JS1 = J
       GOTO 201 
       ENDIF
      ENDDO
 201  CONTINUE

      DO J = -JB,JB
       IF(LAT(J) >= -10.) THEN 
        JE1 = J
       GOTO 202 
       ENDIF
      ENDDO
 202  CONTINUE

      DO J = -JB,JB
       IF(LAT(J) >= 10.) THEN 
        JS2 = J
       GOTO 203 
       ENDIF
      ENDDO
 203  CONTINUE

      DO J = -JB,JB
       IF(LAT(J) >= 88.) THEN 
        JE2 = J
       GOTO 204 
       ENDIF
      ENDDO
 204  CONTINUE

     DO J= JE1,JS2
     DO I= 0,IB1
      DPSI_MERGE(I,J) = 1.E+9
     ENDDO
     ENDDO


!------------------------------------------------------
      ICOUNT=0
 104  CONTINUE 
      PSICAND=MINVAL(DPSI_MERGE(:,:))
       IF( PSICAND > PSIMIN .or. ICOUNT > 500) GOTO 105

       DO J= -JB,JB
       DO I= 0,IB1
       IF( PSICAND == DPSI_MERGE(I,J) ) THEN

       AREA=40
       DETER=.TRUE.

       JJP=J+AREA
       JJM=J-AREA
       IF( JJP > JB ) JJP=JB
       IF( JJM < -JB ) JJM=-JB

      DO Q = JJM,JJP
      DO P = 0,IB1
       CALL COSINE_DIS(LAT(J),LON(I),LAT(Q),LON(P),distan)
       IF( DPSI_MERGE(P,Q) >= 100 .and. DISTAN <= MRADIUS )THEN
        DETER=.FALSE.
        GOTO 666
       ENDIF
      ENDDO
      ENDDO
 666  CONTINUE

      DO Q = JJM,JJP
      DO P = 0,IB1
       CALL COSINE_DIS(LAT(J),LON(I),LAT(Q),LON(P),distan)
       IF( DPSI_MERGE(P,Q) > PSIMIN .and. DISTAN <= LRADIUS )THEN
        DETER=.FALSE.
        GOTO 667
       ENDIF
      ENDDO
      ENDDO
 667  CONTINUE



      VOR2D(:,:) = 0.
      MSLP2D(:,:) = 1.E+9
      DVOR2D(:,:) = 0.
      DMSLP2D(:,:) = 1.E+9

      DO Q = JJM,JJP
      DO P = 0,IB1
       CALL COSINE_DIS(LAT(J),LON(I),LAT(Q),LON(P),distan)
       IF(  DISTAN <= MRADIUS ) THEN
        IF(  DPSI_MERGE(P,Q) <= PSIMIN ) THEN
         MSLP2D(P,Q)=MSLP(P,Q)
         DMSLP2D(P,Q)=DMSLP(P,Q)
         VOR2D(P,Q)=VORT(P,Q,4)*ABS(LAT(Q))/LAT(Q)
         DVOR2D(P,Q)=DVORT(P,Q,4)*ABS(LAT(Q))/LAT(Q)
        ENDIF
       ENDIF
      ENDDO
      ENDDO

      WMAG(:,:)=0.
      THETA700(:,:)=-1.E+9
      THETA500(:,:)=-1.E+9
      THETA300(:,:)=-1.E+9
      HEIGHT(:,:)=-1.E+9
      DPSI1000(:,:)=1.E+9
      DPSI850(:,:)=1.E+9
      DPSI700(:,:)=1.E+9
      DPSI500(:,:)=1.E+9


      DO Q = JJM,JJP
      DO P = 0,IB1
       CALL COSINE_DIS(LAT(J),LON(I),LAT(Q),LON(P),distan)
        IF(  DISTAN <= MRADIUS ) THEN
         IF(  DPSI_MERGE(P,Q) <= PSIMIN ) THEN
        WMAG(P,Q) = SQRT(UGRD(P,Q,1)**2+VGRD(P,Q,1)**2)
        THETA700(P,Q) = THETA(P,Q,7)
        THETA500(P,Q) = THETA(P,Q,10)
        THETA300(P,Q) = THETA(P,Q,11)
        HEIGHT(P,Q) = TOPO(P,Q)
        DPSI1000(P,Q) = DPSI(P,Q,1)
        DPSI850(P,Q) = DPSI(P,Q,4)
        DPSI700(P,Q) = DPSI(P,Q,7)
        DPSI500(P,Q) = DPSI(P,Q,10)
       ENDIF
      ENDIF
      ENDDO
      ENDDO
 
      IF( MAXVAL(VOR2D(:,:))*ABS(LAT(J))/LAT(J) == 0 ) DETER = .FALSE.
 
      IF(DETER==.TRUE.)THEN
      ICOUNT=ICOUNT+1

      WRITE(100,'(I4.4,1x,3(I2.2,1x),1x,14(f10.2,1x),E13.4)')            &
      IYEAR,IMONTH,IDAY,IHOUR,LAT(J),LON(I),MINVAL(MSLP2D(:,:)),        &  
      MAXVAL(WMAG(:,:)),PSICAND,MINVAL(DPSI1000(:,:)),                  &
      MINVAL(DPSI850(:,:)),MINVAL(DPSI700(:,:)),MINVAL(DPSI500(:,:)),   &
      MAXVAL(THETA700(:,:)),MAXVAL(THETA500(:,:)),MAXVAL(THETA300(:,:)),& 
      SST(I,J),MAXVAL(HEIGHT(:,:)),MAXVAL(VOR2D(:,:))*ABS(LAT(J))/LAT(J)

      WRITE(*,'(I4.4,1x,3(I2.2,1x),1x,14(f10.2,1x),E13.4)')            &
      IYEAR,IMONTH,IDAY,IHOUR,LAT(J),LON(I),MINVAL(MSLP2D(:,:)),        &  
      MAXVAL(WMAG(:,:)),PSICAND,MINVAL(DPSI1000(:,:)),                  &
      MINVAL(DPSI850(:,:)),MINVAL(DPSI700(:,:)),MINVAL(DPSI500(:,:)),   &
      MAXVAL(THETA700(:,:)),MAXVAL(THETA500(:,:)),MAXVAL(THETA300(:,:)),& 
      SST(I,J),MAXVAL(HEIGHT(:,:)),MAXVAL(VOR2D(:,:))*ABS(LAT(J))/LAT(J)
      
      DO Q = JJM,JJP
      DO P = 0,IB1
       CALL COSINE_DIS(LAT(J),LON(I),LAT(Q),LON(P),distan)
        IF ( DISTAN <= MRADIUS ) THEN
         IF ( DPSI_MERGE(P,Q) <= PSIMIN ) THEN
          DPSI_MERGE(P,Q) = 1.E+9
         ENDIF
        ENDIF
      ENDDO
      ENDDO

      ELSEIF(DETER==.FALSE.)THEN
      DO Q = JJM,JJP
      DO P = 0,IB1
       CALL COSINE_DIS(LAT(J),LON(I),LAT(Q),LON(P),distan)
        IF ( DISTAN <= MRADIUS ) THEN
         IF ( DPSI_MERGE(P,Q) <= PSIMIN ) THEN
          DPSI_MERGE(P,Q) = 1.E+9
         ENDIF
        ENDIF
      ENDDO
      ENDDO

     ENDIF

      GOTO 104
       ENDIF

      ENDDO
      ENDDO

 105  CONTINUE

      CALL DATE_INCREASE(IYEAR,IMONTH,IDAY,IHOUR)

!      ENDIF     ! ENDIF FOR MONTH
      T=T+1

!-----1-Dimensional variables
!-----2-Dimensional variables
      DEALLOCATE (IDATA4,IDATA8,FRORK1,FRORK2,FWORK1,FWORK2,FWORK3)
      DEALLOCATE (ANM1,ANM2)
!-----3Dimensional variables
      DEALLOCATE (MSLP,DMSLP,MSLP2D,WMAG,VOR2D)
      DEALLOCATE (DMSLP2D,DVOR2D)
      DEALLOCATE (PSI,DPSI,THETA,TMP,HGT,DHGT)
      DEALLOCATE (DPSI1000,DPSI850,DPSI700,DPSI500,DPSI_MERGE)
      DEALLOCATE (UGRD,DUGRD,VGRD,DVGRD,LANDSEA,DVORT_MERGE)
      DEALLOCATE (DATA1,DATA2,DATA3,DATA4,DATA5,DATA6)
      DEALLOCATE (DATA7,DATA8)
      DEALLOCATE (VORT,IDVORT,DVORT,SST,TOPO)
      DEALLOCATE (THETA700,THETA500,THETA300,HEIGHT)

      ENDDO     ! ENDDO for IMPLICIT DO
 999  CONTINUE
      CLOSE(300);CLOSE(301);CLOSE(302);CLOSE(303);CLOSE(304)
      CLOSE(305);CLOSE(306);CLOSE(307);CLOSE(308);CLOSE(309)
      CLOSE(310);CLOSE(311);CLOSE(312);CLOSE(313);CLOSE(314)
      CLOSE(315);CLOSE(316);CLOSE(317);CLOSE(318);CLOSE(319)

!---------------------------------------------------------------------------------------

      CONTAINS
!-----------------------------------------------------------------------
      REAL FUNCTION VISCO( IA, B, IC )
      IMPLICIT NONE
      REAL  :: B,IC
      REAL(KIND=8) :: VISCO_
      INTEGER :: IA
       VISCO_ = (IC*(IC+1.0D0))**IA
       VISCO_ =  1.D0/(B*VISCO_)
       VISCO  =  VISCO_**(1.D0/IA)
      END FUNCTION VISCO
      ENDPROGRAM CYCLONE_TRACKING
EOF

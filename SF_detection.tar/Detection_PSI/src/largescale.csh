#!/bin/csh -xf

######################################################################## 
# Code developer: Dr. Jae-Deok Lee (ruio1084@gmail.com)
# Department of Atmospheric Science, Kongju National University
# ERA5 reanalysis data (2001-2020).
# Please email me if you have any query
#
######################################################################## 

set curdir = ($PWD ) # DO NOT CHANGE
set years=$1            # START YEAR

cat <<EOF> CYCLONE_TRACKING.f90
      PROGRAM CYCLONE_TRACKING
      USE PARAMETER_DSIZE
      USE PARAMETER_WSIZE
      USE PARAMETER_EARTH
      USE COMMON_TRIGONO_METRIC_SPHERE
      USE COMMON_ENM1_CosSinLat

      IMPLICIT NONE
      INTEGER :: I,J,K,T,P,Q,TIMESET,IIP,IIM,JJP,JJM
      INTEGER :: JS1,JE1,JS2,JE2,ICOUNT,ICOUNT1,ICOUNT2,II,JJ
      INTEGER :: IS1,IE1,IS2,IE2,IPERIOD,IYEAR,IMONTH,IDAY,IHOUR
      INTEGER :: EYEAR
      INTEGER :: YEAR,MONTH,DAY,HOUR
      INTEGER :: NX,NY,NZ,NT
      INTEGER :: LAP_DIM,AREA
      INTEGER,ALLOCATABLE,DIMENSION(:) :: YEAR1,MONS1,DAYS1,HOUR1
      REAL(KIND=4) :: MVOR,MWIND,SUM1,SUM2,VORTICITY,VORMIN
      REAL(KIND=4) :: PSICAND,WMAX,MINP,XVIS,MCUT,PSIMAX
      REAL(KIND=8) :: GAMMA0
      REAL(KIND=4),PARAMETER :: PSIMIN=-1.0
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:) :: LAT,LON
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:) :: FRORK1,FRORK2,IDATA4
      REAL(KIND=8),ALLOCATABLE,DIMENSION(:,:) :: FWORK1,FWORK2,FWORK3
      REAL(KIND=8),ALLOCATABLE,DIMENSION(:,:) :: ANM1,ANM2,IDATA8
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:) :: WMAG,LANDSEA
!-----850, 700, 500, 300, 200 hPa
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:) :: GMAP,DMAP,PSI_MERGED,VOR_MERGED
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:) :: MSLP,DMSLP,SST,VOR2D,MSLP2D
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:) :: THETA500,THETA300

      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:,:) :: UGRD,VGRD,VORT
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:,:) :: PSI,TMP,DTMP
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:,:) :: DVORT,THETA
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:,:) :: DUGRD,DVGRD
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:,:) :: DATA1,DATA2
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:,:) :: DATA3,DATA4
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:,:) :: DATA5,DATA6
      REAL(KIND=4),ALLOCATABLE,DIMENSION(:,:,:) :: DPSI,DTHETA
      REAL(KIND=4),DIMENSION(6) :: PLEVS

      CHARACTER(4) :: CYEAR
      CHARACTER(2) :: CMONTH,CDAY,CHOUR
      CHARACTER(200),DIMENSION(300) :: FILE
      CHARACTER(200),DIMENSION(10) :: VARIABLES
      CHARACTER(200) :: VAR,DATE1
      LOGICAL::DETER

      DATA PLEVS / 1000, 850, 700, 500, 300, 200 /

      ALLOCATE (LAT(-JB:JB),LON(0:IB1))

!-----------------------------------------------------------------------
!     LON/LAT CALCULATION
!-----------------------------------------------------------------------

      DO I = 0,IB1
      LON(I) = 360.*(1.*I/IB)
      ENDDO

      DO J = -JB,JB
      LAT(J) = 180.*(1.*J/JBW)
      ENDDO

!-----------------------------------------------------------------------
!     Begin
!-----------------------------------------------------------------------

!------------------------------------------------------------------------
!      SUBROUTINE CALL
!------------------------------------------------------------------------
!
!     FILTERING PART
!     FULL GRID FILTERING USING FINITE ELEMENT METHOD (FEM)
!
!                   PROVIDED FROM PUKYOUNG NAT. UNIV.
!                             NUMERICAL WEATHER PREDICTION & DYNAMIC LAB.
!                                                     PROF. H.-B. CHEONG.
!------------------------------------------------------------------------

      CALL SINCOS_MERI
      CALL MAT200E_JS2
      CALL COS_SIN_LAT
      CALL TEST_FFT_FULLGRID
      CALL MAT200E_JS2_FEM
      CALL MATM_VOR_UV_JS2_FEM

!-------ERA5 pressure levels: 1000, 850, 700, 500, 300, 200

      OPEN(100, file="../Archive/${years}/ETCs.txt")
!      OPEN(101, file="./Archive/SORTED_ETCs.txt")
!      OPEN(102, file="./Archive/LIST_ETCs.txt")
!      OPEN(103, file="./Archive/KOREA_ETCs.txt")
!      OPEN(104, file="./Archive/KOREA_DJF_ETCs.txt")
!      OPEN(105, file="./Archive/KOREA_MAM_ETCs.txt")
!      OPEN(106, file="./Archive/KOREA_JJA_ETCs.txt")
!      OPEN(107, file="./Archive/KOREA_SON_ETCs.txt")
!      OPEN(108, file="./Archive/KOREA_MONTHLY_ETCs.txt")
!      OPEN(109, file="./Archive/NH.txt")
!      OPEN(110, file="./Archive/SH.txt")

      OPEN(300, file="../Archive/${years}/MSLP.bin",                  &
               access="direct",form="unformatted",recl=IB*(JBW+1)*4)
      OPEN(301, file="../Archive/${years}/DMSLP.bin",                  &
               access="direct",form="unformatted",recl=IB*(JBW+1)*4)
      OPEN(302, file="../Archive/${years}/UGRD.bin",                  &
               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
      OPEN(303, file="../Archive/${years}/DUGRD.bin",                  &
               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
      OPEN(304, file="../Archive/${years}/VGRD.bin",                  &
               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
      OPEN(305, file="../Archive/${years}/DVGRD.bin",                  &
               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
      OPEN(306, file="../Archive/${years}/VORT.bin",                 &
               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
      OPEN(307, file="../Archive/${years}/DVORT.bin",                 &
               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
      OPEN(313, file="../Archive/${years}/TMP.bin",                 &
               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
      OPEN(314, file="../Archive/${years}/THETA.bin",                 &
               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
      OPEN(315, file="../Archive/${years}/DTHETA.bin",                 &
               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
      OPEN(316, file="../Archive/${years}/SST.bin",                 &
               access="direct",form="unformatted",recl=IB*(JBW+1)*4)

!      GOTO 800
      IYEAR = ${years}
      EYEAR = ${years}
      IMONTH = 1
      IDAY = 1
      IHOUR = 0
      T = 1

      DO 
      IF( IYEAR > EYEAR ) GOTO 999

!-----Set the serching period !!!
!      IF(IMONTH >=1 .and. IMONTH<= 1) THEN

      WRITE(CYEAR,'(I4.4)') IYEAR
      WRITE(CMONTH,'(I2.2)') IMONTH
      WRITE(CDAY,'(I2.2)') IDAY
      WRITE(CHOUR,'(I2.2)') IHOUR

      WRITE(*,'(4(A,2x))') CYEAR,CMONTH,CDAY,CHOUR
      WRITE(DATE1,'(4(A))') CYEAR,CMONTH,CDAY,CHOUR
      print*, TRIM(DATE1)
stop

      OPEN(200, file="/data4/jdlee/DATA/ERA5/bin/"//CYEAR//"/mslPRES."     &
                                          //CYEAR//CMONTH//CDAY//CHOUR, &
               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
      OPEN(201, file="/data4/jdlee/DATA/ERA5/bin/"//CYEAR//"/LANDSEA."     &
                                          //CYEAR//CMONTH//CDAY//CHOUR, &
               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
      OPEN(202, file="/data4/jdlee/DATA/ERA5/bin/"//CYEAR//"/UGRD."     &
                                          //CYEAR//CMONTH//CDAY//CHOUR, &
               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
      OPEN(203, file="/data4/jdlee/DATA/ERA5/bin/"//CYEAR//"/VGRD."     &
                                          //CYEAR//CMONTH//CDAY//CHOUR, &
               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
      OPEN(204, file="/data4/jdlee/DATA/ERA5/bin/"//CYEAR//"/TMP."     &
                                          //CYEAR//CMONTH//CDAY//CHOUR, &
               access="direct",form="unformatted",recl=IB*(JBW+1)*KB*4)
      OPEN(205, file="/data4/jdlee/DATA/ERA5/bin/"//CYEAR//"/SST."     &
                                          //CYEAR//CMONTH//CDAY//CHOUR, &
               access="direct",form="unformatted",recl=IB*(JBW+1)*4)

!-----2-Dimensional variables
      ALLOCATE (IDATA4(0:IB1,-JB:JB),IDATA8(0:IB1,-JB:JB)) 
      ALLOCATE (FRORK1(0:IB1,-JB:JB),FRORK2(0:IB1,-JB:JB)) 
      ALLOCATE (FWORK1(0:IB1,-JB:JB),FWORK2(0:IB1,-JB:JB)) 
      ALLOCATE (FWORK3(0:IB1,-JB:JB)) 
      ALLOCATE (WMAG(0:IB1,-JB:JB),MSLP(0:IB1,-JB:JB))
      ALLOCATE (DMSLP(0:IB1,-JB:JB))
      ALLOCATE (MSLP2D(0:IB1,-JB:JB))
      ALLOCATE (LANDSEA(0:IB1,-JB:JB))
      ALLOCATE (SST(0:IB1,-JB:JB))

!-----3-Dimensional variables
      ALLOCATE ( UGRD(0:IB1,-JB:JB,KB),  VGRD(0:IB1,-JB:JB,KB))
      ALLOCATE ( TMP(0:IB1,-JB:JB,KB), THETA(0:IB1,-JB:JB,KB) )
      ALLOCATE ( DTHETA(0:IB1,-JB:JB,KB) )
      ALLOCATE ( THETA500(0:IB1,-JB:JB) )
      ALLOCATE ( THETA300(0:IB1,-JB:JB) )
      ALLOCATE (DUGRD(0:IB1,-JB:JB,KB), DVGRD(0:IB1,-JB:JB,KB))
      ALLOCATE (DATA1(0:IB1,-JB:JB,KB), DATA2(0:IB1,-JB:JB,KB))
      ALLOCATE (DATA3(0:IB1,-JB:JB,KB), DATA4(0:IB1,-JB:JB,KB))
      ALLOCATE (DATA5(0:IB1,-JB:JB,KB), DATA6(0:IB1,-JB:JB,KB))
      ALLOCATE (VORT(0:IB1,-JB:JB,KB), DVORT(0:IB1,-JB:JB,KB))
      ALLOCATE (PSI(0:IB1,-JB:JB,KB), DPSI(0:IB1,-JB:JB,KB))
      ALLOCATE (PSI_MERGED(0:IB1,-JB:JB), VOR_MERGED(0:IB1,-JB:JB))
      ALLOCATE (VOR2D(0:IB1,-JB:JB))
!-----Filtering variables
      ALLOCATE ( ANM1(-MT:MT,-JB:JB), ANM2(-MT:MT,-JB:JB) )
!-----------------------------------------------------------------------

      READ(200,rec=1) MSLP(:,:)
      READ(201,rec=1) LANDSEA(:,:)
      READ(202,rec=1) UGRD(:,:,:)
      READ(203,rec=1) VGRD(:,:,:)
      READ(204,rec=1) TMP(:,:,:)
      READ(205,rec=1) SST(:,:)
      CLOSE(200); CLOSE(201); CLOSE(202);CLOSE(203);CLOSE(204);CLOSE(205)

      DO J = -JB,JB
      DO I = 0,IB1
       IF(SST(I,J) > 1.E+4) SST(I,J) =18.+273.15
       IF(SST(I,J) ==  0. ) SST(I,J) =18.+273.15
      ENDDO
      ENDDO

      IDATA4(:,:) =0.
      CALL REVERS( MSLP(:,:), IDATA4(:,:) )
      MSLP(:,:) = IDATA4(:,:)/100.

      IDATA4(:,:) =0.
      CALL REVERS( SST(:,:), IDATA4(:,:) )
      SST(:,:) = IDATA4(:,:)-273.15

      IDATA4(:,:) =0.
      CALL REVERS( LANDSEA(:,:), IDATA4(:,:) )
      LANDSEA(:,:) = IDATA4(:,:)

      DO K = 1, KB
       IDATA4(:,:) =0.
       CALL REVERS( UGRD(:,:,K), IDATA4(:,:) )
       UGRD(:,:,K) = IDATA4(:,:)
 
       IDATA4(:,:) =0.
       CALL REVERS( VGRD(:,:,K), IDATA4(:,:) )
       VGRD(:,:,K) = IDATA4(:,:)

       IDATA4(:,:) =0.
       CALL REVERS( TMP(:,:,K), IDATA4(:,:) )
       TMP(:,:,K) = IDATA4(:,:)
      ENDDO

      DO K = 1,6
      THETA(:,:,K)=TMP(:,:,K)*(PLEVS(K)/1000.)**0.286
      ENDDO

      TMP(:,:,:) = TMP(:,:,:)-273.15

!------------------------------------------------------------------------
!      MAIN CALCULATION
!------------------------------------------------------------------------

      MCUT = 10.
      LAP_DIM=4
      XVIS=1.D0
      GAMMA0= VISCO(LAP_DIM,XVIS,MCUT)

       FWORK1(:,:)=MSLP(:,:)
       CALL FILTERING_SUBS(FWORK1,GAMMA0,LAP_DIM)
       DMSLP(:,:)= MSLP(:,:)-FWORK1(:,:)

!------Vertical Loop Calculations
      DO K = 1, KB
       FWORK1(:,:)=UGRD(:,:,K)
       CALL FILTERING_SUBS(FWORK1,GAMMA0,LAP_DIM)
       EUGRD(:,:,K)= FWORK1(:,:)

       FWORK1(:,:)=VGRD(:,:,K)
       CALL FILTERING_SUBS(FWORK2,GAMMA0,LAP_DIM)
       EVGRD(:,:,K)= FWORK1(:,:)

       FWORK1(:,:)=VGRD(:,:,K)
       CALL FILTERING_SUBS(FWORK2,GAMMA0,LAP_DIM)
       EVGRD(:,:,K)= FWORK1(:,:)

       FWORK1(:,:)=THETA(:,:,K)
       CALL FILTERING_SUBS(FWORK2,GAMMA0,LAP_DIM)
       ETHETA(:,:,K)= FWORK1(:,:)

       FWORK1(:,:)=THETA(:,:,K)
       CALL FILTERING_SUBS(FWORK2,GAMMA0,LAP_DIM)
       ETHETA(:,:,K)= FWORK1(:,:)
      ENDDO ! ENDDO FOR K 

      WRITE(300,rec=T) MSLP(:,:)
      WRITE(301,rec=T) DMSLP(:,:)
      WRITE(302,rec=T) UGRD(:,:,:)
      WRITE(303,rec=T) DUGRD(:,:,:)
      WRITE(304,rec=T) VGRD(:,:,:)
      WRITE(305,rec=T) DVGRD(:,:,:)
      WRITE(306,rec=T) VORT(:,:,:)
      WRITE(307,rec=T) DVORT(:,:,:)
      WRITE(308,rec=T) PSI(:,:,:)
      WRITE(309,rec=T) DPSI(:,:,:)
      WRITE(310,rec=T) PSI_MERGED(:,:)
      WRITE(311,rec=T) VOR_MERGED(:,:)
      WRITE(313,rec=T) TMP(:,:,:)
      WRITE(314,rec=T) THETA(:,:,:)
      WRITE(315,rec=T) DTHETA(:,:,:)
      WRITE(316,rec=T) SST(:,:)

      CALL DATE_INCREASE(IYEAR,IMONTH,IDAY,IHOUR)

      write(312,rec=T) PSI_MERGED(:,:)
!      ENDIF     ! ENDIF FOR MONTH
      T=T+1

!-----1-Dimensional variables
!-----2-Dimensional variables
      DEALLOCATE (IDATA4,IDATA8,FRORK1,FRORK2,FWORK1,FWORK2,FWORK3)
      DEALLOCATE (ANM1,ANM2)
!-----3Dimensional variables
      DEALLOCATE (MSLP,DMSLP,MSLP2D)
      DEALLOCATE (WMAG,PSI_MERGED,VOR_MERGED,VOR2D)
      DEALLOCATE (PSI,DPSI,THETA,DTHETA,TMP)
      DEALLOCATE (UGRD,DUGRD,VGRD,DVGRD,LANDSEA)
      DEALLOCATE (DATA1,DATA2,DATA3,DATA4,DATA5,DATA6)
      DEALLOCATE (VORT,DVORT,SST)
      DEALLOCATE (THETA500,THETA300)

      ENDDO     ! ENDDO for IMPLICIT DO
 999  CONTINUE
      CLOSE(300);CLOSE(301);CLOSE(302);CLOSE(303);CLOSE(304)
      CLOSE(305);CLOSE(306);CLOSE(307);CLOSE(308);CLOSE(309)
      CLOSE(310);CLOSE(311);CLOSE(312);CLOSE(313);CLOSE(314)
      CLOSE(315);CLOSE(316);CLOSE(317);CLOSE(318);CLOSE(319)

!---------------------------------------------------------------------------------------

      CONTAINS
!-----------------------------------------------------------------------
      REAL FUNCTION VISCO( IA, B, IC )
      IMPLICIT NONE
      REAL  :: B,IC
      REAL(KIND=8) :: VISCO_
      INTEGER :: IA
       VISCO_ = (IC*(IC+1.0D0))**IA
       VISCO_ =  1.D0/(B*VISCO_)
       VISCO  =  VISCO_**(1.D0/IA)
      END FUNCTION VISCO
      ENDPROGRAM CYCLONE_TRACKING
EOF

!23456789012345678901234567890123456789012345678901234567890123456789012
!**********************************************************************
      SUBROUTINE FOUR1( data, nn, ndimyb,ndimye,nbe,nen, isign )
!**********************************************************************
      implicit none
!C--------------------------------------------------------------------C
      integer :: nn, ndimyb, ndimye, nbe, nen, isign
      real(kind=8) :: data(ndimyb:ndimye,2*nn),FOUR1S(20,2)
      LOGICAL :: JUSDOIT=.TRUE.
!c----
      real(kind=8) :: pi,pi2,theta,tempr,tempi,wr,wi,wpr,wpi,wtemp
      integer :: i,j,m,n,jsw,mmax,mmmax,ip1,jp1,istep
!C--------------------------------------------------------------------C
!C                                When nn>2**20,
!C                                dimension of FOUR1S must be increased.
!C--------------------------------------------------------------------C
      IF(JUSDOIT) THEN
         JUSDOIT=.FALSE.

      PI = DATAN(1.D-00)*4.d-00
      PI2= PI*2.d-00

      do mmax=1,20 ! IB
         theta= PI2/(2**mmax)
         FOUR1S(mmax,1)= -2.D0*DSIN(0.5d-00*theta)**2
         FOUR1S(mmax,2)=       DSIN(        theta)
      end do

      ENDIF

      n=2*nn
      j=1
      do i=1,n,2 ! 11
        if(j.gt.i)then
                ip1=i+1
                jp1=j+1
            DO jsw=nbe,nen ! 1,ndimy    ! parallel 
                  tempr =data(jsw,j  )
                  tempi =data(jsw,jp1)
           data(jsw,j  )=data(jsw,i  )
           data(jsw,jp1)=data(jsw,ip1)
           data(jsw,i  )=tempr      
           data(jsw,ip1)=tempi       
            END DO ! par 
        endif
        m=n/2
    1   if ((m.ge.2).and.(j.gt.m)) then
            j=j-m
            m=m/2
        goto 1
        endif
        j=j+m
      enddo ! 11
      mmax=2
               mmmax= 0
    2 if (n.gt.mmax) then
               mmmax= mmmax+1
          istep=2*mmax
!c         theta=PI2/(isign*mmax)
!c
!c        FOUR1S(mmax,1)= DSIN(0.5d-00*PI2/mmax)**2
!c        FOUR1S(mmax,2)= DSIN(        PI2/mmax)
!c
!c         wpr=-2.d-00*DSIN(0.5d-00*theta)**2
!c         wpi=DSIN(theta)

          wpr= FOUR1S(mmmax,1)
          wpi= FOUR1S(mmmax,2)*isign
          wr=1.d-00
          wi=0.d-00
          do m=1,mmax,2 ! 13
             do i=m,n,istep ! 12
               j=i+mmax

                    jp1=j+1
                    ip1=i+1
                DO jsw=nbe,nen ! 1,ndimy    ! parallel
                      tempr =wr*data(jsw,j  )-wi*data(jsw,jp1)
                      tempi =wr*data(jsw,jp1)+wi*data(jsw,j  )
               data(jsw,j  )=data(jsw,i  )-tempr       
               data(jsw,jp1)=data(jsw,ip1)-tempi       
               data(jsw,i  )=data(jsw,i  )+tempr       
               data(jsw,ip1)=data(jsw,ip1)+tempi       
                END DO ! par

             enddo ! 12
             wtemp=wr
             wr=wr*wpr-wi*wpi+wr
             wi=wi*wpr+wtemp*wpi+wi
          enddo ! 13
          mmax=istep
      goto 2
      endif
!C
!c---------------------------------------------------------------------
      END SUBROUTINE FOUR1
!**********************************************************************
!C
!**********************************************************************
      SUBROUTINE REALFT( data, n,ndimyb,ndimye,nbe,nen, isign, normali )
!**********************************************************************
      implicit none
!C--------------------------------------------------------------------C
      integer :: n, ndimyb, ndimye, nbe, nen, isign, normali
      real(kind=8) :: data(ndimyb:ndimye,n)  ! ndimy : dimension of Y-dir grids
!c----
      real(kind=8) :: pi,theta,c1,c2,wpr,wpi,wr,wi,wrs,wis
      real(kind=8) :: h1r,h1i,h2r,h2i,wrsh2r,wrsh2i,wish2r,wish2i
      real(kind=8) :: aaa,bbb,wtemp,sca1N,sca2N
      integer :: jsw,n2p3,i,i1,i2,i3,i4
!C---------------------------------------------------------------------
      PI = DATAN(1.D-00)*4.D-00

      if(normali.EQ.1) then
!C------------------------ H.-B. CHEONG 1998.05.01 : NORMALIZATION
      do jsw=nbe,nen ! 1,ndimy
      if(isign.eq.-1) data(jsw,1)= data(jsw,1)*2.D-00
      if(isign.eq.-1) data(jsw,2)= data(jsw,2)*2.D-00 ! 2001.07.06
      end do
!C------------------------ H.-B. CHEONG 1998.05.01 : NORMALIZATION
      endif

      theta= PI/(n/2.d-00)
      c1=0.5d-00
      if (isign.eq.1) then
          c2=-0.5d-00
          CALL FOUR1(data,n/2,ndimyb,ndimye,nbe,nen,+1)
      else
          c2= 0.5d-00
          theta=-theta
      endif
      wpr=-2.d-00*DSIN(0.5d-00*theta)**2
      wpi=DSIN(theta)
      wr=1.d-00+wpr
      wi=wpi
      n2p3=n+3
      do i=2,n/4 ! 11
         i1=2*i-1
         i2=i1+1
         i3=n2p3-i2
         i4=i3+1
         wrs=wr
         wis=wi
      DO jsw=nbe,nen ! 1,ndimy    ! parallel computing for dim1 in data(dim1,dim2)
         h1r= c1*(data(jsw,i1)+data(jsw,i3))
         h1i= c1*(data(jsw,i2)-data(jsw,i4))
         h2r=-c2*(data(jsw,i2)+data(jsw,i4))
         h2i= c2*(data(jsw,i1)-data(jsw,i3))
              wrsh2r = wrs*h2r
              wrsh2i = wrs*h2i
              wish2r = wis*h2r
              wish2i = wis*h2i
                 aaa =     wrsh2r-wish2i
                 bbb =     wrsh2i+wish2r

         data(jsw,i1)= h1r+aaa             
         data(jsw,i2)= h1i+bbb             
         data(jsw,i3)= h1r-aaa              
         data(jsw,i4)=-h1i+bbb

!        data(jsw,i1)= h1r+wrs*h2r-wis*h2i
!        data(jsw,i2)= h1i+wrs*h2i+wis*h2r
!        data(jsw,i3)= h1r-wrs*h2r+wis*h2i
!        data(jsw,i4)=-h1i+wrs*h2i+wis*h2r
      END DO ! par
         wtemp=wr
         wr=wr*wpr-wi*wpi+wr
         wi=wi*wpr+wtemp*wpi+wi
      end do ! 11
      if (isign.eq.1) then
      DO jsw=nbe,nen ! 1,ndimy    ! parallel computing for dim1 in data(dim1,dim2)
          h1r=data(jsw,1)
          data(jsw,1)=h1r+data(jsw,2)
          data(jsw,2)=h1r-data(jsw,2)
      END DO ! par
      else
      DO jsw=nbe,nen ! 1,ndimy    ! parallel computing for dim1 in data(dim1,dim2)
          h1r=data(jsw,1)
          data(jsw,1)=c1*(h1r+data(jsw,2))
          data(jsw,2)=c1*(h1r-data(jsw,2))
      END DO ! par
          CALL FOUR1(data,n/2,ndimyb,ndimye,nbe,nen,-1)
      endif

      if(normali.EQ.1) then
!------------------------ H.-B. CHEONG 1998.05.01 : NORMALIZATION
      if(isign.eq.+1) then
            sca1N= 1.D-00/N
            sca2N= 2.D-00/N
         do i=3,N
         DO jsw=nbe,nen ! 1,ndimy    ! parallel computing for dim1 in data(dim1,dim2)
            data(jsw,i)= data(jsw,i)*sca2N
         END DO ! par
         end do
         DO jsw=nbe,nen ! 1,ndimy    ! parallel computing for dim1 in data(dim1,dim2)
            data(jsw,1)= data(jsw,1)*sca1N
            data(jsw,2)= data(jsw,2)*sca1N
         END DO ! par
      endif
!------------------------ H.-B. CHEONG 1998.05.01 : NORMALIZATION
      endif
!
!---------------------------------------------------------------------
      END SUBROUTINE REALFT
!*********************************************************************
!
!
!*********************************************************************
!
!     In this DFS_global Model,
!     X(j)= SUM_mj ANM(mj)*HALFSINCOSINE is used instead of USUAL
!     form [ X(j)= (1/2) ANM(0) + SUM_mj=1^N ANM(mj)*HALFSINCOSINE ].
!
!     At exit 'CALL GPFA_8_VEC', the coefficients are all normalized.
!
!     Due to the difference in (1/2)ANM(0), the normalization factors
!     are different for wavenum=0 and Nyquist from USUAL routines.
!
!*********************************************************************
      SUBROUTINE SIN_FTN                                                &
      ( data, partRE, partIM, temp, SINHF, COSPK, SINPK,                &
       ALAT, BLAT, TRIGS, N, N1, ND2, MT, isign )          ! ND2=N/2
!**********************************************************************
      implicit none
!C--------------------------------------------------------------------C
      integer :: N, N1, ND2, MT, isign
!C---------------------------------------------------------------------
      real(kind=8) :: data(-MT:MT,0:N1),TRIGS(N*2)
!C---------------------------------------------------------------------
      real(kind=8) :: partRE(-MT:MT,0:ND2),partIM(-MT:MT,0:ND2)
      real(kind=8) :: temp(-MT:MT)
      real(kind=8) :: SINHF(0:ND2),COSPK(0:ND2),SINPK(0:ND2)
      real(kind=8) :: ALAT(0:MT,0:N1),BLAT(0:MT,0:N1)
!c----
      real(kind=8) :: aa,bb,tx,ty,sca1N,sca2N
      integer :: j,nj,m,k,kev,kod,kop,kom,nk,i
!C---------------------------------------------------------------------
!C     Calculates the Cosine Fourier transform of a set of n-real valued
!C     data points. OUTPUT is NORMALIZED.
!C-----
!C     f_j= F_1 SIN(pi*(j+0.5)*1/N) + ...... + F_N SIN(pi*(j+0.5)*N/N)
!C     F_k= [ sum_j=1^j=N-1 f_j SIN(pi*(j+0.5)*k/N) ] * (2/N)
!C     F_N= [ sum_j=0^j=N-1 f_j SIN(pi*(j+0.5)*N/N) ] * (1/N)
!C-----
!C     FOUR1,REALFT : ARRAY is bounded as 1:N
!C     COS_FT       : ARRAY is bounded as 0:N-1
!C     SIN_FT       : ARRAY is bounded as 0:N-1
!C     REALFT = REALFTN except the NORMALIZATION in REALFTN
!C-----
!C---------------------------------------------------------------------
!C     ISIGN=+1     : INPUT=GRIDS OUTPUT=WAVES
!C                                1st data : SIN_1
!C                                2nd data : SIN_2 ......
!C     ISIGN=-1     : INPUT=WAVES OUTPUT=GRIDS
!C                 
!C---------------------------------------------------------------------
!     PI = DATAN(1.D-00)*4.D-00
!     PIN= PI/dble(N)
!C---------------------------------------------------------------------
!        qCALL= qCALL+1.0D-00
!     IF(qCALL.eq.1.D-00) THEN         ! For a Variable transform
!        do j=0,ND2                    ! Calculates once only
!           aa= PIN*(j+0.5D-00)
!           SINHF(j)= DSIN(aa)
!        end do
!        do k=0,ND2
!           bb= PIN*dble(k)
!           COSPK(k)= DCOS(bb)
!           SINPK(k)= DSIN(bb)
!        end do
!     ENDIF
!C---------------------------------------------------------------------

!C=============================
          IF(isign.EQ.+1) THEN         ! GRIDS->WAVES
!C=============================
!C-----                                 ! variable transform
      do j=0,ND2-1
         nj= N1-j
      DO m=-MT,MT
         aa= (data(m,j )-data(m,nj))/2+(data(m,j )+data(m,nj))*SINHF(j)
         bb= (data(m,nj)-data(m,j ))/2+(data(m,nj)+data(m,j ))*SINHF(j)
         data(m, j)= aa
         data(m,nj)= bb
      END DO
      end do
!C-----
!C-beg------------------------------------------! 2pi periodic FFT ---
!     CALL REALFT( data,N, isign )     ! CALL non-NORMALIZING ROUTINE

         do I=0,N1
         Do J=0,MT
            BLAT( J,I)= data( J,I)
            ALAT( J,I)= data(-J,I)
         end do
            BLAT( 0,I)= 0.d0      ! to avoid the same point 
         END Do

         CALL GPFA_8_VEC( ALAT,BLAT,TRIGS, 1, N, N, 1, isign,MT,MT )

!!!           Output with isign=+1 : BLAT(Nyquist)= SIN or COS (Nyquist)

         do k=1,ND2-1
                      kev= k*2
                      kod= kev+1
            Nk= N-k
         Do m=0,MT
            partRE( m, k )= ( BLAT(m, k )+BLAT(m,Nk))/N
            partRE(-m, k )= ( ALAT(m, k )+ALAT(m,Nk))/N
            partIM( m, k )= (-ALAT(m, k )+ALAT(m,Nk))/N
            partIM(-m, k )= ( BLAT(m, k )-BLAT(m,Nk))/N
         END Do
         end do
         Do m=0,MT
            partRE( m, 0 )=   BLAT(m, 0 )/N
            partRE(-m, 0 )=   ALAT(m, 0 )/N
            partIM( m, 0 )=   0.d0
            partIM(-m, 0 )=   0.d0
            partRE( m,ND2)=   BLAT(m,ND2)/N
            partRE(-m,ND2)=   ALAT(m,ND2)/N
            partIM( m,ND2)=   0.d0
            partIM(-m,ND2)=   0.d0
         END Do

!C-end------------------------------------------! 2pi periodic FFT ---

!C----- The followings (1-9) are for 'data' is output of SUB REALFT
!1
!     DO m=-MT,MT
!        partRE(m, 0 )= data(m, 0 )        ! COS_0   compo = data(0) 
!        partRE(m,ND2)= data(m, 1 )        ! COS_N/2 compo = data(1)
!        partIM(m, 0 )= 0.                 ! SIN_0   compo
!     END DO
!     do k=1,ND2-1
!        kev= k*2
!        kod= kev+1
!     DO m=-MT,MT
!        partRE(m,k)= data(m,kev)          ! COS compo.
!        partIM(m,k)= data(m,kod)          ! SIN compo.
!     END DO
!9    end do
!C-----
      do k=1,ND2-1
         kev= k*2
      DO m=-MT,MT
         data(m,kev)= partRE(m,k)*SINPK(k)+partIM(m,k)*COSPK(k)
      END DO
      end do
      DO m=-MT,MT
         data(m,0)= partRE(m,ND2)        ! SIN_N (=last) compo.
         data(m,1)= partRE(m, 0 )        ! Factor ()/2 deleted because it is
!        data(m,1)= partRE(m, 0 )/2.D-00 ! already done after [CALL GPFA_8_VEC].
      END DO
      do k=1,ND2-1                     ! recurrence
         kod= k*2+1                    ! SIN_k <- COS_2k and SIN_2k (REALFT)
      DO m=-MT,MT
         data(m,kod)= (partRE(m,k)*COSPK(k)-partIM(m,k)*SINPK(k))       &
                   +  data(m,kod-2)
      END DO
      end do
!C-----
      do m=-MT,MT
         temp(m)   = data(m, 0 )
      END DO
      do j=0,N-2
      do m=-MT,MT
         data(m,j )= data(m,j+1)
      END DO
      end do
      do m=-MT,MT
         data(m,N1)= temp(m)
      END DO
!C------
!C=============================
      ELSEIF(isign.EQ.-1) THEN         ! WAVES->GRIDS
!C=============================
!C-----
      DO m=-MT,MT
         temp(m)  = data(m,N1 )        ! To make 1st=SIN_N, 2nd=SIN_1 ...
      END DO 
      do j=N1,1,-1                     ! For here, this is convenient.
      DO m=-MT,MT
         data(m,j)= data(m,j-1)
      END DO 
      end do
      DO m=-MT,MT
         data(m,0)= temp(m)
      END DO 
!C-----
      DO m=-MT,MT
!          data(m, 0 )= data(m, 0 )*2. ! See the remarks box
!        partRE(m, 0 )= data(m, 1 )*2. 
           data(m, 0 )= data(m, 0 )    ! Factor (*2.) was deleted
         partRE(m, 0 )= data(m, 1 )    ! to use 'CALL GPFA_8_VEC'
         partIM(m, 0 )= 0.  
         partRE(m,ND2)= data(m, 0 )
      END DO 
      do k=1,ND2-1                     ! SIN_k -> COS_2k and SIN_2k  
         kev= k*2                      !          in REALFT
         kop= kev+1
         kom= kev-1
      DO m=-MT,MT
         partRE(m,k)= data(m,kev)*SINPK(k)                              &
                   +(data(m,kop)-data(m,kom))*COSPK(k)  
         partIM(m,k)= data(m,kev)*COSPK(k)                              &
                   -(data(m,kop)-data(m,kom))*SINPK(k)
      END DO 
      end do
      DO m=-MT,MT
         data(m, 0 )= partRE(m, 0 )
         data(m, 1 )= partRE(m,ND2)
      END DO 
      do k=1,ND2-1
         kev= k*2
         kod= kev+1
      DO m=-MT,MT
         data(m,kev)= partRE(m, k )     ! COS compo in REALFT
         data(m,kod)= partIM(m, k )     ! SIN compo in REALFT
      END DO 
      end do
!C-----
!C-beg------------------------------------------! 2pi periodic FFT ---
!     CALL REALFT( data,N, isign )     ! CALL non-NORMALIZING ROUTINE

      do k=0,N1
      dO m=0,MT
         BLAT(m,k)= 0.
         ALAT(m,k)= 0.
      end do
      end do

      do k=1,ND2-1
                   kev= k*2
                   kod= kev+1
         Nk= N-k
      Do m=1,MT
         BLAT(m, k)= ( data(-m,kod)+data( m,kev))/2.d0
         BLAT(m,Nk)= (-data(-m,kod)+data( m,kev))/2.d0
         ALAT(m, k)= ( data(-m,kev)-data( m,kod))/2.d0
         ALAT(m,Nk)= ( data(-m,kev)+data( m,kod))/2.d0
      END Do
         m=0
         BLAT(m, k)= ( data(-m,kod)             )/2.d0
         BLAT(m,Nk)= (-data(-m,kod)             )/2.d0
         ALAT(m, k)= ( data(-m,kev)             )/2.d0
         ALAT(m,Nk)= ( data(-m,kev)             )/2.d0
      end do
         k=0
      Do m=0,MT
         BLAT(m, k)=   data( m,k  )
         ALAT(m, k)=   data(-m,k  )
      END Do
         BLAT(0, k)=   0. ! to avoid the same input 
         k=ND2
      Do m=0,MT
         BLAT(m, k)=   data( m,1  )
         ALAT(m, k)=   data(-m,1  )
      END Do
         BLAT(0, k)=   0. ! to avoid the same input 

         CALL GPFA_8_VEC( ALAT,BLAT,TRIGS, 1, N, N, 1, isign,MT,MT )

         do I=0,N1
         Do J=0,MT
            data( J,I)= BLAT( J,I)
            data(-J,I)= ALAT( J,I)
         end do
         END Do

!C-end------------------------------------------! 2pi periodic FFT ---
      do j=0,ND2-1
         nj=N1-j                       ! GRIDS in REALFT -> GRIDS in COS_FT
      DO m=-MT,MT
         ty= data(m,j )-data(m,nj)
         tx=(data(m,nj)+data(m,j ))/(SINHF(j)*2.)
         data(m, j)= (tx+ty)/2.
         data(m,nj)= (tx-ty)/2.
      END DO 
      end do
!C-----
!C=============================         ! isign = +-1
       ENDIF
!C=============================         ! isign = +-1

!C------------------------ NORMALIZATION
      if(isign.eq.+1) then
            sca1N= 1.D-00/N
            sca2N= 2.D-00/N
         do i=0,N-2
         DO m=-MT,MT
!c           data(m,i )= data(m,i )*sca2N  ! NMZ is Done in 'GPFA_8_VEC'
         END DO
         end do
         DO m=-MT,MT
!c           data(m,N1)= data(m,N1)*sca1N  ! NMZ is Done in 'GPFA_8_VEC'
         END DO
      endif
!C------------------------ NORMALIZATION
!C
!c--------------------------------------------------------------------c
      END SUBROUTINE SIN_FTN
!**********************************************************************
!C
!C
!**********************************************************************
!*                                                                    *
!*     19 MAY 2011 : bug corrected                                    *
!*                                                                    *
!**********************************************************************
      SUBROUTINE COS_FTN                                                &
      ( data, partRE, partIM, temp, SINHF,COSPK,SINPK,                 &
        ALAT, BLAT, TRIGS, N, N1, ND2, MT, isign )          ! ND2=N/2
!*********************************************************************
      implicit none
!--------------------------------------------------------------------C
      integer :: N, N1, ND2, MT, isign
      real(kind=8) :: data(-MT:MT,0:N1),TRIGS(N*2)
!---------------------------------------------------------------------
      real(kind=8) :: partRE(-MT:MT,0:ND2),partIM(-MT:MT,0:ND2)
      real(kind=8) :: temp(-MT:MT)
      real(kind=8) :: SINHF(0:ND2),COSPK(0:ND2),SINPK(0:ND2)
      real(kind=8) :: ALAT(0:MT,0:N1),BLAT(0:MT,0:N1)
!----
      real(kind=8) :: aa,bb,tx,ty,sca1N,sca2N
      integer :: j,nj,m,k,kev,kod,kop,kom,nk,i


!---------------------------------------------------------------------
!     Calculates the Cosine Fourier transform of a set of n-real valued
!     data points. OUTPUT is NORMALIZED.
!-----
!     f_j= F_0 COS(pi*(j+0.5)*0/N) + F_1 COS(pi*(j+0.5)*1/N) + ......
!     F_k= [ sum_j=0^j=N-1 f_j COS(pi*(j+0.5)*k/N) ] * (2/N)
!     F_0= [ sum_j=0^j=N-1 f_j COS(pi*(j+0.5)*0/N) ] * (1/N)
!-----
!     FOUR1,REALFT : ARRAY is bounded as 1:N
!     COS_FT       : ARRAY is bounded as 0:N-1
!     SIN_FT       : ARRAY is bounded as 0:N-1
!     REALFT = REALFTN except the NORMALIZATION in REALFTN
!-----
!---------------------------------------------------------------------
!     ISIGN=+1     : INPUT=GRIDS OUTPUT=WAVES
!                                1st in data : COS_0
!                                2nd in data : COS_1 ......
!     ISIGN=-1     : INPUT=WAVES OUTPUT=GRIDS
!---------------------------------------------------------------------
!     PI = DATAN(1.D-00)*4.D-00
!     PIN= PI/dble(N)
!C---------------------------------------------------------------------
!        qCALL= qCALL+1.0D-00
!     IF(qCALL.eq.1.D-00) THEN         ! For a Variable transform
!        do j=0,ND2                    ! Calculates once only
!           aa= PIN*(j+0.5D-00)
!           SINHF(j)= DSIN(aa)
!        end do
!        do k=0,ND2
!           bb= PIN*dble(k)
!           COSPK(k)= DCOS(bb)
!           SINPK(k)= DSIN(bb)
!        end do
!     ENDIF
!C---------------------------------------------------------------------

!C=============================
          IF(isign.EQ.+1) THEN         ! GRIDS->WAVES
!C=============================
!C-----                                 ! variable transform


      do j=0,ND2-1
         nj= N1-j
      DO m=-MT,MT
         aa= (data(m,j )+data(m,nj))/2-(data(m,j )-data(m,nj))*SINHF(j)
         bb= (data(m,nj)+data(m,j ))/2-(data(m,nj)-data(m,j ))*SINHF(j)
        data(m, j)= aa
        data(m,nj)= bb
      END DO
      end do
!C-----
!C-beg------------------------------------------! 2pi periodic FFT ---
!     CALL REALFT( data,N, isign )     ! CALL non-NORMALIZING ROUTINE

         do I=0,N1
         Do J=0,MT
            BLAT( J,I)= data( J,I)
            ALAT( J,I)= data(-J,I)
         end do
!           BLAT( 0,I)= 0.d0      ! to avoid the same point 
                                  ! It was found that 'BLAT( 0,I)= 0.d0'
                   ! 19 MAY 2011  !    should not be done
         END Do

         CALL GPFA_8_VEC( ALAT,BLAT,TRIGS, 1, N, N, 1, isign,MT,MT )


!!!           Output with isign=+1 : BLAT(Nyquist)= SIN or COS (Nyquist)

         do k=1,ND2-1
                      kev= k*2
                      kod= kev+1
            Nk= N-k
         Do m=0,MT
            partRE( m, k )= ( BLAT(m, k )+BLAT(m,Nk))/N
            partRE(-m, k )= ( ALAT(m, k )+ALAT(m,Nk))/N
            partIM( m, k )= (-ALAT(m, k )+ALAT(m,Nk))/N
            partIM(-m, k )= ( BLAT(m, k )-BLAT(m,Nk))/N
         END Do
         end do
         Do m=0,MT
            partRE( m, 0 )=   BLAT(m, 0 )/N
            partRE(-m, 0 )=   ALAT(m, 0 )/N
            partIM( m, 0 )=   0.d0
            partIM(-m, 0 )=   0.d0
            partRE( m,ND2)=   BLAT(m,ND2)/N
            partRE(-m,ND2)=   ALAT(m,ND2)/N
            partIM( m,ND2)=   0.d0
            partIM(-m,ND2)=   0.d0
         END Do

!C-end------------------------------------------! 2pi periodic FFT ---

!C----- The followings (1-9) are for 'data' is output of SUB REALFT
!1
!     DO m=-MT,MT
!        partRE(m, 0 )= data(m, 0 )    ! COS_0   compo = data(0) 
!        partRE(m,ND2)= data(m, 1 )    ! COS_N/2 compo = data(1)
!        partIM(m, 0 )= 0.             ! SIN_0   compo
!     END DO
!     do k=1,ND2-1
!        kev= k*2
!        kod= kev+1
!     DO m=-MT,MT
!        partRE(m,k)= data(m,kev)      ! COS compo.
!        partIM(m,k)= data(m,kod)      ! SIN compo.
!     END DO
!9    end do
!C-----
      do k=0,ND2-1
         kev= k*2
      DO m=-MT,MT
         data(m,kev)= partRE(m,k)*COSPK(k)-partIM(m,k)*SINPK(k)
      END DO
      end do
      DO m=-MT,MT
         data(m,N1)=-partRE(m,ND2)        ! Factor (*2.) was deleted because it is
!        data(m,N1)=-partRE(m,ND2)/2.D-00 ! already done after [CALL GPFA_8_VEC].
      END DO
      do k=ND2-1,1,-1                  ! recurrence
      DO m=-MT,MT
         kod= k*2-1                    ! COS_k <- COS_2k and SIN_2k (REALFT)
      data(m,kod)=-(partRE(m,k)*SINPK(k)+partIM(m,k)*COSPK(k))          &
                  + data(m,kod+2)
      END DO
      end do
!C-----
!C=============================
      ELSEIF(isign.EQ.-1) THEN         ! WAVES->GRIDS
!C=============================
!C-----
      DO m=-MT,MT
           data(m, 0 )= data(m, 0)
         partRE(m, 0 )= data(m, 0)*COSPK(0) 
         partIM(m, 0 )= 0. 
         partRE(m,ND2)=-data(m,N1)
!!         data(m, 0 )= data(m, 0)*2.  ! Factor (*2.) was deleted to use 'CALL 'GPFA_8_VEC'
!!       partRE(m, 0 )= data(m, 0)*COSPK(0) 
!!       partIM(m, 0 )= 0. 
!!       partRE(m,ND2)=-data(m,N1)*2.  ! Factor (*2.) was deleted to use 'CALL 'GPFA_8_VEC'
      END DO
      do k=1,ND2-1                     ! COS_k -> COS_2k and SIN_2k  
         kev= k*2                      !          in REALFT
         kop= kev+1
         kom= kev-1
      DO m=-MT,MT
         partRE(m,k)= data(m,kev)*COSPK(k)                              &
                   +(data(m,kop)-data(m,kom))*SINPK(k)  
         partIM(m,k)=-data(m,kev)*SINPK(k)                              &
                   +(data(m,kop)-data(m,kom))*COSPK(k)
      END DO
      end do
      DO m=-MT,MT
         data(m, 0 )= partRE(m, 0 )
         data(m, 1 )= partRE(m,ND2)
      END DO
      do k=1,ND2-1
         kev= k*2
         kod= kev+1
      DO m=-MT,MT
         data(m,kev)= partRE(m,k)      ! COS compo in REALFT
         data(m,kod)= partIM(m,k)      ! SIN compo in REALFT
      END DO
      end do
!C-----
!C-beg------------------------------------------! 2pi periodic FFT ---
!     CALL REALFT( data,N, isign )     ! CALL non-NORMALIZING ROUTINE

      do k=0,N1
      dO m=0,MT
         BLAT(m,k)= 0.
         ALAT(m,k)= 0.
      end do
      end do

      do k=1,ND2-1
                   kev= k*2
                   kod= kev+1
         Nk= N-k
      Do m=1,MT
         BLAT(m, k)= ( data(-m,kod)+data( m,kev))/2.d0
         BLAT(m,Nk)= (-data(-m,kod)+data( m,kev))/2.d0
         ALAT(m, k)= ( data(-m,kev)-data( m,kod))/2.d0
         ALAT(m,Nk)= ( data(-m,kev)+data( m,kod))/2.d0
      END Do
         m=0
         BLAT(m, k)= ( data(-m,kod)             )/2.d0
         BLAT(m,Nk)= (-data(-m,kod)             )/2.d0
         ALAT(m, k)= ( data(-m,kev)             )/2.d0
         ALAT(m,Nk)= ( data(-m,kev)             )/2.d0
      end do
         k=0
      Do m=0,MT
         BLAT(m, k)=   data( m,k  )
         ALAT(m, k)=   data(-m,k  )
      END Do
         BLAT(0, k)=   0. ! to avoid the same input 
         k=ND2
      Do m=0,MT
         BLAT(m, k)=   data( m,1  )
         ALAT(m, k)=   data(-m,1  )
      END Do
         BLAT(0, k)=   0. ! to avoid the same input 

         CALL GPFA_8_VEC( ALAT,BLAT,TRIGS, 1, N, N, 1, isign,MT,MT )

         do I=0,N1
         Do J=0,MT
            data( J,I)= BLAT( J,I)
            data(-J,I)= ALAT( J,I)
         end do
         END Do

!C-end------------------------------------------! 2pi periodic FFT ---
!C-----
      do j=0,ND2-1
         nj=N1-j                       ! GRIDS in REALFT -> GRIDS in COS_FT
      DO m=-MT,MT
         tx= data(m,j )+data(m,nj)
         ty=(data(m,nj)-data(m,j ))/(SINHF(j)*2.)
         data(m, j)= (tx+ty)/2.
         data(m,nj)= (tx-ty)/2.
      END DO
      end do
!C-----
!C=============================         ! isign = +-1
       ENDIF
!C=============================         ! isign = +-1

!C------------------------ NORMALIZATION
      if(isign.eq.+1) then
            sca1N= 1.D-00/N
            sca2N= 2.D-00/N
         do i=1,N-1
         DO m=-MT,MT
!           data(m,i)= data(m,i)*sca2N  ! NMZ is Done in 'GPFA_8_VEC'
         END DO
         end do
         DO m=-MT,MT
!           data(m,0)= data(m,0)*sca1N  ! NMZ is Done in 'GPFA_8_VEC'
         END DO
      endif
!C------------------------ NORMALIZATION
!C
!c--------------------------------------------------------------------c
      END SUBROUTINE COS_FTN
!**********************************************************************

!**********************************************************************
!*                                                                    *
!*     12 MAY 2011                                                    *
!*                 : Cosine transform of (-MT:MT,0:Ngrid) data        *
!*                 : Numerical recipe (1992), 512 page                *
!*                                                                    * 
!*-----                                                               *
!*     f_j= F_0 COS(pi*(j)*0/N) + F_1 COS(pi*(j)*1/N) + ......        *
!*     F_k= [ sum_j=1^j=N-1 f_j COS(pi*j*k/N) + 0.5(f_0 +(-1)^k f_N) ]/ (N/2)
!*     F_0= [ sum_j=1^j=N-1 f_j COS(pi*j*k/N) + 0.5(f_0 +(-1)^k f_N) ]/  N
!*     F_N= [ sum_j=1^j=N-1 f_j COS(pi*j*k/N) + 0.5(f_0 +(-1)^k f_N) ]/  N
!*-----                                                               *
!**********************************************************************
      SUBROUTINE COS_FTN_FullGrid                                       &
      ( data, partRE, partIM, temp, SINHF,COSHF,COSPK,SINPK,            &
       ALAT, BLAT, TRIGS, N, N1, ND2, MT, isign )          ! ND2=N/2
!**********************************************************************
      implicit none
!C--------------------------------------------------------------------C
      integer :: N, N1, ND2, MT, isign
      real(kind=8) :: data(-MT:MT,0:N ),TRIGS(N*2)  ! full-grid, 00-grid
!C---------------------------------------------------------------------
      real(kind=8) :: partRE(-MT:MT,0:ND2),partIM(-MT:MT,0:ND2)
      real(kind=8) :: temp(-MT:MT)
      real(kind=8) :: SINHF(0:ND2),COSHF(0:ND2)
      real(kind=8) :: COSPK(0:ND2),SINPK(0:ND2)
      real(kind=8) :: ALAT(0:MT,0:N1),BLAT(0:MT,0:N1)
!c----
      real(kind=8) :: cos1(-MT:MT),cosN(-MT:MT)
      real(kind=8) :: tx,ty,sca1N,sca2N
      integer :: j,nj,m,k,kev,kod,kop,kom,nk,i
!C---------------------------------------------------------------------

!C=============================
          IF(isign.EQ.+1) THEN         ! GRIDS->WAVES
!C=============================

      DO m=-MT,MT
           ty= 0.d0 ! first antisym-COS component to be used below
        do j=1,ND2-1
           ty= ty + ( data(m,j) - data(m,N-j) ) * COSHF(j)
        end do
           cos1(m)= ( 2.d0*ty + data(m,0) - data(m,N) )/dfloat(N)
      END Do
!C-----                                 ! variable transform
      do j=0,ND2-1
!        nj= N1-j  ! for half-grid, 05-grid
         nj= N -j  ! for Full-grid, 00-grid system
      DO m=-MT,MT
         tx= (data(m,j )+data(m,nj))/2-(data(m,j )-data(m,nj))*SINHF(j)
         ty= (data(m,nj)+data(m,j ))/2-(data(m,nj)-data(m,j ))*SINHF(j)
         data(m, j)= tx
         data(m,nj)= ty
!        data(m,ND2) remains unchanged
      END DO
      end do
!C-----
!C-beg------------------------------------------! 2pi periodic FFT ---
!     CALL REALFT( data,N, isign )     ! CALL non-NORMALIZING ROUTINE

         do I=0,N1  ! only N points of N+1 are used 
         Do m=0,MT
            BLAT( m,I)= data( m,I)
            ALAT( m,I)= data(-m,I)
         end do
            BLAT( 0,I)= 0.d0      ! to avoid the same point 
         END Do

         CALL GPFA_8_VEC( ALAT,BLAT,TRIGS, 1, N, N, 1, isign,MT,MT )

!!!           Output with isign=+1 : BLAT(Nyquist)= SIN or COS (Nyquist)

            sca1N= dfloat(N) 
         do k=1,ND2-1
            Nk= N-k
         Do m=0,MT
            partRE( m, k )= ( BLAT(m, k )+BLAT(m,Nk))/sca1N  ! meridional COS(j*k*PI/N), j=0,1,2,...grid
            partRE(-m, k )= ( ALAT(m, k )+ALAT(m,Nk))/sca1N  ! meridional COS
            partIM( m, k )= (-ALAT(m, k )+ALAT(m,Nk))/sca1N  ! meridional SIN(j*k*PI/N), j=0,1,2,...grid
            partIM(-m, k )= ( BLAT(m, k )-BLAT(m,Nk))/sca1N  ! meridional SIN
         END Do
         end do
         Do m=0,MT
            partRE( m, 0 )= BLAT(m, 0 )/sca1N
            partRE(-m, 0 )= ALAT(m, 0 )/sca1N
            partIM( m, 0 )=   0.d0                       ! SIN(j*0*PI/N)
            partIM(-m, 0 )=   0.d0
            partRE( m,ND2)= BLAT(m,ND2)/sca1N
            partRE(-m,ND2)= ALAT(m,ND2)/sca1N
            partIM( m,ND2)=   0.d0                       ! SIN(j*N*PI/N)
            partIM(-m,ND2)=   0.d0
         END Do

!C-end------------------------------------------! 2pi periodic FFT ---

      do k=0,ND2
         kev= k*2
      DO m=-MT,MT
         data(m,kev)= partRE(m,k)
      END DO
      end do

      DO m=-MT,MT
         data(m, 1 )= cos1(m)
      END DO
      do k=1,ND2-1
         kod= k*2-1                    ! COS_k <- COS_2k and SIN_2k (REALFT)
         kop= k*2+1
      DO m=-MT,MT
         data(m,kop)= data(m,kod) + partIM(m,k)
      END DO
      end do
!C-----
!C=============================
      ELSEIF(isign.EQ.-1) THEN         ! WAVES->GRIDS
!C=============================

      do m=-MT,MT
         tx= 0.d0 ; ty= 0.d0           ! 1st & N-th grid point value; N=even
      do k=0,N ,2 ; tx= tx + data(m,k) ; end do           
      do k=1,N1,2 ; ty= ty + data(m,k) ; end do
         cos1(m)= tx + ty
         cosN(m)= tx - ty
      end do ! m=
!C-----                                 ! variable transform
      do k=1,ND2-1
         kod= k*2-1                    ! COS_k <- COS_2k and SIN_2k (REALFT)
         kop= k*2+1
      DO m=-MT,MT
         partIM(m,k)= data(m,kop) - data(m,kod)
      END DO
      end do

      do k=0,ND2
         kev= k*2
      DO m=-MT,MT
         partRE(m,k)= data(m,kev)
      END DO
      end do

      Do m=-MT,MT
         partIM( m, 0 )=   0.d0                       ! SIN(j*0*PI/N)
         partIM( m,ND2)=   0.d0                       ! SIN(j*N*PI/N)
      END Do

!C-beg------------------------------------------! 2pi periodic FFT ---

         do k=1,ND2-1
            Nk= N-k
         Do m=1,MT
            BLAT(m, k)= ( partRE( m, k) + partIM(-m, k) )/2.d0
            BLAT(m,Nk)= ( partRE( m, k) - partIM(-m, k) )/2.d0
            ALAT(m, k)= ( partRE(-m, k) - partIM( m, k) )/2.d0
            ALAT(m,Nk)= ( partRE(-m, k) + partIM( m, k) )/2.d0
         END Do
            m=0
            BLAT(m, k)= ( partIM(-m, k)                 )/2.d0
            BLAT(m,Nk)= (-partIM(-m, k)                 )/2.d0
            ALAT(m, k)= ( partRE(-m, k)                 )/2.d0
            ALAT(m,Nk)= ( partRE(-m, k)                 )/2.d0
         end do ! k=
            k=0
         Do m=0,MT
            BLAT(m, 0 )= partRE( m, 0 )
            ALAT(m, 0 )= partRE(-m, 0 )
            BLAT(m,ND2)= partRE( m,ND2)
            ALAT(m,ND2)= partRE(-m,ND2)
         END Do
            BLAT(0, 0 )= 0.d0  ! to avoid the same input
            BLAT(0,ND2)= 0.d0  ! to avoid the same input

         CALL GPFA_8_VEC( ALAT,BLAT,TRIGS, 1, N, N, 1, isign,MT,MT )

         do k=0,N1
         Do m=0,MT
            data( m,k)= BLAT( m,k)  ! always BLAT comes first  
            data(-m,k)= ALAT( m,k)
         end do
         END Do
!C-----                                 ! variable transform
      do j=1,ND2-1
         nj= N -j  ! for Full-grid, 00-grid system
         sca1N= 1.d0/( 2.d0 * SINHF(j) )
      DO m=-MT,MT
         tx= (data(m, j)+data(m,nj))         ! tx = (f_j + f_(N-j)) : hemispheric sym.
         ty=-(data(m, j)-data(m,nj))* sca1N  ! ty                   : (h.asym) * SINHF
         data(m, j)= ( tx + ty ) /2.d0
         data(m,nj)= ( tx - ty ) /2.d0
!        data(m,ND2) remains unchanged
      END DO
      end do
         data(:,0)= cos1(:)  ! first gridpoint
         data(:,N)= cosN(:)  ! last gridpoint

!C-end------------------------------------------! 2pi periodic FFT ---

       ENDIF

!c--------------------------------------------------------------------c
      END SUBROUTINE COS_FTN_FullGrid
!**********************************************************************
!C
!**********************************************************************
!*                                                                    *
!*     12 MAY 2011                                                    *
!*                 : Sine   transform of (-MT:MT,0:Ngrid) data        *
!*                 : Numerical recipe (1992), 512 page                *
!*                                                                    * 
!*-----                                                               *
!*     f_j= F_1 SIN(pi*(j)*1/N) + F_2 SIN(pi*(j)*2/N) + ......        *
!*     F_k= [ sum_j=1^j=N-1 f_j SIN(pi*j*k/N) ]/ (N/2)                *
!*-----                                                               *
!*********************************************************************
      SUBROUTINE SIN_FTN_FullGrid                                       &
      ( data, partRE, partIM, temp, SINHF,COSHF,COSPK,SINPK,            &
        ALAT, BLAT, TRIGS, N, N1, ND2, MT, isign )          ! ND2=N/2
!*********************************************************************
      implicit none
!--------------------------------------------------------------------C
      integer :: N, N1, ND2, MT, isign
      real(kind=8) :: data(-MT:MT,0:N ),TRIGS(N*2)  ! full-grid, 00-grid
!---------------------------------------------------------------------
      real(kind=8) :: partRE(-MT:MT,0:ND2),partIM(-MT:MT,0:ND2)
      real(kind=8) :: temp(-MT:MT)
      real(kind=8) :: SINHF(0:ND2),COSHF(0:ND2)
      real(kind=8) :: COSPK(0:ND2),SINPK(0:ND2)
      real(kind=8) :: ALAT(0:MT,0:N1),BLAT(0:MT,0:N1)
!----
      real(kind=8) :: sin1(-MT:MT,0:N)
      real(kind=8) :: tx,ty,sca1N,sca2N
      integer :: j,nj,m,k,kev,kod,kop,kom,nk,i
!---------------------------------------------------------------------

!=============================
          IF(isign.EQ.+1) THEN         ! GRIDS->WAVES
!=============================
!-----                                 ! variable transform
      do j=1,ND2-1
!        nj= N1-j  ! for half-grid, 05-grid
         nj= N -j  ! for Full-grid, 00-grid system
      DO m=-MT,MT
         tx= (data(m,j )-data(m,nj))/2+(data(m,j )+data(m,nj))*SINHF(j)
         ty= (data(m,nj)-data(m,j ))/2+(data(m,nj)+data(m,j ))*SINHF(j)
         data(m, j)= tx
         data(m,nj)= ty
      END DO
      end do
         data(:, 0 )= 0.d0
         data(:, N )= 0.d0
         data(:,ND2)= data(:,ND2)*2.d0
!-----
!-beg------------------------------------------! 2pi periodic FFT ---
!     CALL REALFT( data,N, isign )     ! CALL non-NORMALIZING ROUTINE

         do I=0,N1  ! only N points of N+1 are used 
         Do m=0,MT
            BLAT( m,I)= data( m,I)
            ALAT( m,I)= data(-m,I)
         end do
            BLAT( 0,I)= 0.d0      ! to avoid the same point 
         END Do

         CALL GPFA_8_VEC( ALAT,BLAT,TRIGS, 1, N, N, 1, isign,MT,MT )

!!!           Output with isign=+1 : BLAT(Nyquist)= SIN or COS (Nyquist)

            sca1N= dfloat(N) 
         do k=1,ND2-1
            Nk= N-k
         Do m=0,MT
            partRE( m, k )= ( BLAT(m, k )+BLAT(m,Nk))/sca1N  ! meridional COS(j*k*PI/N), j=0,1,2,...grid
            partRE(-m, k )= ( ALAT(m, k )+ALAT(m,Nk))/sca1N  ! meridional COS
            partIM( m, k )= (-ALAT(m, k )+ALAT(m,Nk))/sca1N  ! meridional SIN(j*k*PI/N), j=0,1,2,...grid
            partIM(-m, k )= ( BLAT(m, k )-BLAT(m,Nk))/sca1N  ! meridional SIN
         END Do
         end do
         Do m=0,MT
            partRE( m, 0 )= BLAT(m, 0 )/sca1N
            partRE(-m, 0 )= ALAT(m, 0 )/sca1N
            partIM( m, 0 )=   0.d0                       ! SIN(j*0*PI/N)
            partIM(-m, 0 )=   0.d0
            partRE( m,ND2)= BLAT(m,ND2)/sca1N
            partRE(-m,ND2)= ALAT(m,ND2)/sca1N
            partIM( m,ND2)=   0.d0                       ! SIN(j*N*PI/N)
            partIM(-m,ND2)=   0.d0
         END Do

!-end------------------------------------------! 2pi periodic FFT ---

      do k=0,ND2
         kev= k*2
      DO m=-MT,MT
         data(m,kev)= partIM(m,k)
      END DO
      end do

      DO m=-MT,MT
!        data(m, 1 )= partRE(m,0) / 2.d0
         data(m, 1 )= partRE(m,0)        ! because I use sum_f_k CosKtheta, k>=0
      END DO                             !         -> and normaliz. by N
      do k=1,ND2-1
         kod= k*2-1                    ! COS_k <- COS_2k and SIN_2k (REALFT)
         kop= k*2+1
      DO m=-MT,MT
         data(m,kop)= data(m,kod) + partRE(m,k)
      END DO
      end do
!-----
!=============================
      ELSEIF(isign.EQ.-1) THEN         ! WAVES->GRIDS
!=============================
!
!--- sin(m,1) compo. : directly calculated for numerical reasons
!                    : l-number 980 ALAT(:ND2)=0 should hold for a single wave mj=1
!                    ! but not succeed. So the next loop was introduced.
      do m=-MT,MT
         tx= 0.d0
      do j=0,ND2
         sin1(m,  j)= data(m,1)*SINHF(j)
         sin1(m,N-j)= sin1(m,j)
      end do
      end do ! m= 
!
         data(:,1)= 0.d0
!
!-----                                 ! variable transform
      do k=1,ND2-1
         kod= k*2-1                    ! COS_k <- COS_2k and SIN_2k (REALFT)
         kop= k*2+1
      DO m=-MT,MT
         partRE(m,k)= data(m,kop) - data(m,kod)
      END DO
      end do
         partRE(:,ND2)= data(:,1) - data(:,N1)
      DO m=-MT,MT
!        partRE(m,0)= data(m, 1 ) * 2.d0
         partRE(m,0)= data(m, 1 )        ! This is right-formula
      END Do                             ! because I use sum_f_k CosKtheta, k>=0 -> and normaliz. by N

      do k=0,ND2
         kev= k*2
      DO m=-MT,MT
         partIM(m,k)= data(m,kev)
      END DO
      end do

      Do m=-MT,MT
         partIM( m, 0 )=   0.d0                       ! SIN(j*0*PI/N)
         partIM( m,ND2)=   0.d0                       ! SIN(j*N*PI/N)
      END Do

!-beg------------------------------------------! 2pi periodic FFT ---

         do k=1,ND2-1
            Nk= N-k
         Do m=1,MT
            BLAT(m, k)= ( partRE( m, k) + partIM(-m, k) )/2.d0
            BLAT(m,Nk)= ( partRE( m, k) - partIM(-m, k) )/2.d0
            ALAT(m, k)= ( partRE(-m, k) - partIM( m, k) )/2.d0
            ALAT(m,Nk)= ( partRE(-m, k) + partIM( m, k) )/2.d0
         END Do
            m=0
            BLAT(m, k)= ( partIM(-m, k)                 )/2.d0
            BLAT(m,Nk)= (-partIM(-m, k)                 )/2.d0
            ALAT(m, k)= ( partRE(-m, k)                 )/2.d0
            ALAT(m,Nk)= ( partRE(-m, k)                 )/2.d0
         end do ! k=
            k=0
         Do m=0,MT
            BLAT(m, 0 )= partRE( m, 0 )
            ALAT(m, 0 )= partRE(-m, 0 )
            BLAT(m,ND2)= partRE( m,ND2)
            ALAT(m,ND2)= partRE(-m,ND2)  ! l-number 980
         END Do
            BLAT(0, 0 )= 0.d0  ! to avoid the same input
            BLAT(0,ND2)= 0.d0  ! to avoid the same input

         CALL GPFA_8_VEC( ALAT,BLAT,TRIGS, 1, N, N, 1, isign,MT,MT )

         do k=0,N1
         Do m=0,MT
            data( m,k)= BLAT( m,k)  ! always BLAT comes first  
            data(-m,k)= ALAT( m,k)
         end do
         END Do
!-----                                 ! variable transform
      do j=1,ND2-1
         nj= N -j  ! for Full-grid, 00-grid system
         sca1N= 1.d0/( 2.d0 * SINHF(j) )
      DO m=-MT,MT
         tx= (data(m, j)+data(m,nj))* sca1N  ! tx = (f_j + f_(N-j)) : hemispheric sym.
         ty= (data(m, j)-data(m,nj))         ! ty                   : (h.asym) * SINHF
         data(m, j)= ( tx + ty ) /2.d0
         data(m,nj)= ( tx - ty ) /2.d0
      END DO
      end do
         data(:,ND2)= data(:,ND2) / 2.d0
!        data(:, 0 )= 0.d0
!        data(:, N )= 0.d0

         data(:, : )= data(:, : ) + sin1(:, :)

!-end------------------------------------------! 2pi periodic FFT ---

       ENDIF

!--------------------------------------------------------------------c
      END SUBROUTINE SIN_FTN_FullGrid
!**********************************************************************


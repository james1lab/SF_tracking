!23456789012345678901234567890123456789012345678901234567890123456789012
!
!     FFT routines : COS_FTN in x for both Half & Full grids
!
!**********************************************************************
!*                                                                    *
!*     This part is only used for stand-alone TEST of FFT-ROUTINE     *
!*                                                                    *
!**********************************************************************
!--beg                                                               !
!                                                                    !
!     CALL TEST_FFT                                                  !
!                                                                    !
!     stop                                                           !
!     end                                                            !
!                                                                    !
!--end                                                               !
!**********************************************************************
!*                                                                    *
!*     TEST OF FFT-ROUTINE : WAVE1->GRID->WAVE2 : (WAVE1-WAVE2)=ERROR *
!*                         : only in x-dir                            *
!*                                                                    *
!*     Total grid number = IB * JBW = x-dir * y-dir                   *
!*                                                                    *
!*     Half grid SINE and COSINE functions                            *
!*                                                                    *
!**********************************************************************
      SUBROUTINE TEST_FFT_window_x_trans
!C--------------------------------------------------------------------C
        use parameter_xdir_window
        use parameter_ydir_window
!C--------------------------------------------------------------------C
        implicit none
!C-----local-variables------------------------------------------------C
      real(kind=8), dimension(0:IB1,JBW) :: WORK1, WORK2
      real(kind=8), dimension(0:MT,JBW)  :: V1,V2
!-----
      integer      :: mx,mj,icase
      real(kind=8) :: sum, error
!C--------------------------------------------------------------------C

      write(*,*)
      write(*,*) '**b* TEST : FFT_COS_FTN_in_x_HalfGrid ***********'
      write(*,*)

      write(*,*) '  MT  IB = ', MT, IB
      write(*,*) '  MT  IB = ', MT, IB
      write(*,*)

         V1(: ,: )= 0.d0
         V2(: ,: )= 0.d0
      do mj=1,JBW
      do mx=0,MT1
         V1(mx,mj)= 1.d0
      end do
      end do

         CALL FFT_DFS_235_SC_LOCAL_window_x_trans                       &
             ( -1, WORK1, V1 )   ! is=1:->Wa

         CALL FFT_DFS_235_SC_LOCAL_window_x_trans                       &
             ( +1, WORK1, V2 )   ! is=1:->Wa

         sum= 0.d0
      do mj=1,JBW
      do mx=0,MT1
         sum= sum + (V1(mx,mj)-V2(mx,mj))**2
      end do
      end do

         error= ( sum/ ( JBW* dfloat(MT) ) )**0.5d0
         write(*,*)' Error of FFT_DFS_235_SC_LOCAL=  ',                 &
                     error ,'   CASE=','CC'

      if(error.GT.1.D-09) STOP                                          &
       'Something wrong in FFT_DFS_235_SC_LOCAL_window '

      write(*,*)
      write(*,*) '**e* TEST : FFT_COS_FTN_in_x_HalfGrid ***********'
      write(*,*)

!C--------------------------------------------------------------------C
      END SUBROUTINE TEST_FFT_window_x_trans
!**********************************************************************
!c
!c
!C--------------------------------------------------------------------C
!c                                                                    c
!c     24 JUL 2009 : JLSN renamed as JLSE                             c
!c                 : IB=IGSE.......... added                          c
!c                 : use parameter-modules                            c
!c     23 JUL 2009 : in y direction -90~90 domain                     c
!c                 : FWAVEJ excluded from arguments                   c
!c     19 APR 2009 : half SIN & COSINE in x and y                     c
!c     13 APR 2009 : half SIN & COSINE in x and y by ONLY SINE trans. c
!c                                                                    c
!c     28 JUL 2008 : m0=COS, m1=SIN, m>=2 : SINnPhi*S^l               c
!c     05 MAR 2008 : m0=COS, m1=SIN, m2=COS                           c
!C                                                                    C
!C     Double Fourier Transform on the Sphere : vectorized            C
!C                                                                    C
!C--------------------------------------------------------------------C
!**********************************************************************
!C
!C--------------------------------------------------------------------C
!c                                                                    c
!c     21 MAY 2013 : x-trans only for FFEM                            c
!c                 : JBW= even or odd                                 c
!c                 : JBWp= even                                       c
!C                                                                    C
!C--------------------------------------------------------------------C
      SUBROUTINE FFT_DFS_235_SC_LOCAL_window_x_trans                    &
      ( isign, PSI, ANM ) ! is=1:->Wa
!    &( isign, PSI, ANM, JT, TRANTYPE, FWAVEJ ) ! is=1:->Wa
!C--------------------------------------------------------------------C
        use parameter_pi
        use parameter_xdir_window
        use parameter_ydir_window
!C--------------------------------------------------------------------C
        implicit none
!C--------------------------------------------------------------------C
      integer      :: isign, JT
      real(kind=8) :: PSI(IB,JBW),ANM(0:MT,JBW)
      character(len=2) :: TRANTYPE            ! 'CC' 'CS' 'SC' 'SS'
!C-----local-variables------------------------------------------------C
      real(kind=8) :: mxx2(0:(JBW+IB),2)                          ! 2009.04.13
      real(kind=8) :: TRIGSIB(IB*2)
!C-----
      real(kind=8) :: data_ANYx(0:JBWp,IB)
      real(kind=8) :: data_SINx(0:JBWp,IB),data_COSx(0:JBWp,0:IB1)
      real(kind=8) :: partRE_SINx(0:JBWp,0:IBH)
      real(kind=8) :: partIM_SINx(0:JBWp,0:IBH)
      real(kind=8) :: SINHFx(0:IBH)
      real(kind=8) :: COSPKx(0:IBH),SINPKx(0:IBH)
      real(kind=8) :: PARITYx(IB)
      real(kind=8) :: temp_SINx(0:JBWp)
      real(kind=8) :: ALON(0:JB,IB),BLON(0:JB,IB)

      real(kind=8) :: data_ANYy(0:MT,JBW)
!C-----
      CHARACTER(len=4) :: FFTOPT
      LOGICAL :: JUSDOIT=.TRUE.
!C-----
      integer      :: mx,mj,mw,i,j,k,j2n,mtlast,jllast
      real(kind=8) :: pin, aa, bb
!C--------------------------------------------------------------------C
!     PI    = DATAN(1.D0)*4.D0
!     PI2   = PI*2.d00
!     PI180 = PI/180.d00
!C--------------------------------------------------------------------C

!     if(mod(JBW,2)==1) stop ' == JBW should be an even integer == '

!C--------------------------------------------------------------------C

      IF(JUSDOIT) THEN
         JUSDOIT=.FALSE.

         do mx=0,JBW+IB ! 2009.04.13
            mxx2(mx,1)= mx*2
            mxx2(mx,2)= mx*2+1
         end do

!C---
              FFTOPT='P235'
              J2N= 1
        do k=1,20
              J2N= J2N*2
           if(IB.eq.J2N) then
!             FFTOPT='P222'
              EXIT
           endif
        end do        ! 2004.04.02      
           write(*,*) '  IB, FFTSOPT=',  IB, FFTOPT   
           write(*,*) ' JBW, FFTSOPT=', JBW, FFTOPT   

         CALL GPFASET_8_VEC(TRIGSIB ,IB )

            PIN= PI/IB
         do j=0,IBH                        ! For SINE and COSINE transform 
            aa= PIN*(j+0.5D-00)
            SINHFx(j)= DSIN(aa)
         end do
         do k=0,IBH
            bb= PIN*dble(k)
            COSPKx(k)= DCOS(bb)
            SINPKx(k)= DSIN(bb)
         end do
         do j=1,IB                         ! For SINE*PARITY = COSINE
            aa= PIN*(j-0.5D-00)
            PARITYx(j)= DSIN(aa)
         end do

      ENDIF

!C----------------------------------------------------------------------C

                     MTlast= MT
      IF( MT.eq.IB ) MTlast= MT-1  ! Half-grid COS_FTN

!C=============================
          IF(isign.EQ.+1) THEN
!C=============================

!C-----(I,J)->(mx,J)

            data_ANYx( :,:)= 0.d0
            data_ANYy( :,:)= 0.d0
                 ANM(: ,: )= 0.d0
         Do J=1,JBW
         do I=1,IB
            data_ANYx(J,I)= PSI(I,J)
         end do
         END Do

      CALL COS_FTN                                                      &
      ( data_ANYx, partRE_SINx, partIM_SINx,                            &
        temp_SINx, SINHFx, COSPKx, SINPKx,                              &
        ALON, BLON, TRIGSIB , IB , IB1  ,IBH, JB, isign )

         Do mw=0,MTlast    ! To set array for y-transform
         do J=1,JBW        ! data_ANYx(*,mw):  mw=1 -> COS 0 or SIN 1
            data_ANYy(mw,J)= data_ANYx(J,mw+1)
         end do
         END Do

               ANM(:,:)    = data_ANYy(: ,:)

!C=============================
      ELSEIF(isign.EQ.-1) THEN
!C=============================
!C
            data_ANYx( :,:)= 0.d0
            data_ANYy( :,:)= ANM(:,:)
                 PSI(: ,: )= 0.d0

!C-----(mx,J)->(I,J)

         Do mw=0,MTlast
         do J=1,JBW          ! data_ANYx(*,mw):  mw=1 -> COS 0 or SIN 1
            data_ANYx(J,mw+1)= data_ANYy(mw,J)
         end do
         END Do

      CALL COS_FTN                                                      &
      ( data_ANYx, partRE_SINx, partIM_SINx,                            &
        temp_SINx, SINHFx, COSPKx, SINPKx,                              &
        ALON, BLON, TRIGSIB , IB , IB1  ,IBH, JB, isign )

         Do J=1,JBW
         do I=1,IB
            PSI(I,J)= data_ANYx(J,I)
         end do
         END Do

!C=============================
       ENDIF                  
!C=============================
!C
!C--------------------------------------------------------------------C
      END SUBROUTINE FFT_DFS_235_SC_LOCAL_window_x_trans
!**********************************************************************
!C

!23456789012345678901234567890123456789012345678901234567890123456789012
!
!**********************************************************************
!*                                                                    *
!*     This part is only used for stand-alone TEST of FFT-ROUTINE     *
!*                                                                    *
!**********************************************************************
!--beg                                                               !
!                                                                    !
!     CALL TEST_FFT                                                  !
!                                                                    !
!     stop                                                           !
!     end                                                            !
!                                                                    !
!--end                                                               !
!**********************************************************************
!*                                                                    *
!*     TEST OF FFT-ROUTINE : WAVE1->GRID->WAVE2 : (WAVE1-WAVE2)=ERROR *
!*                         : only in x-dir                            *
!*                                                                    *
!*     Total grid number = IB * JBW = x-dir * y-dir                   *
!*                                                                    *
!*     Half grid SINE and COSINE functions                            *
!*                                                                    *
!**********************************************************************
      SUBROUTINE TEST_FFT_window_x_trans_FullGrid
!C--------------------------------------------------------------------C
        use parameter_pi
        use parameter_xdir_window
        use parameter_ydir_window
!C--------------------------------------------------------------------C
        implicit none
!C-----local-variables------------------------------------------------C
      real(kind=8), dimension(0:IB ,JBW) :: WORK1, WORK2
      real(kind=8), dimension(0:MT,JBW)  :: V1,V2
!-----
      integer      :: mx,mj,icase, i
      real(kind=8) :: sum, error
!C--------------------------------------------------------------------C

      write(*,*)
      write(*,*)
      write(*,*) '**b* TEST : FFT_COS_FTN_in_x_FullGrid ***********'
      write(*,*)

      write(*,*) '  MT  IB = ', MT, IB
      write(*,*) '  MT  IB = ', MT, IB
      write(*,*)

         V1(: ,: )= 0.d0
         V2(: ,: )= 0.d0

      do mj=1,JBW
      do mx=0,MT
         V1(mx,mj)= 1.d0
      end do
      end do

         CALL FFT_DFS_235_SC_LOCAL_window_x_trans_FullGrid              &
            ( -1, WORK1, V1 )   ! is=1:->Wa

         CALL FFT_DFS_235_SC_LOCAL_window_x_trans_FullGrid              &
             ( +1, WORK1, V2 )   ! is=1:->Wa

         sum= 0.d0
      do mj=1,JBW
      do mx=0,MT
         sum= sum + (V1(mx,mj)-V2(mx,mj))**2.d0
      end do
      end do
!
!---- one point griddata
!
         V1(: ,: )= 0.d0
         V2(: ,: )= 0.d0

         WORK2(:,:)= 0.d0 
         WORK1(:,:)= 0.d0 
         WORK1(9,9)= 1.d0 

         CALL FFT_DFS_235_SC_LOCAL_window_x_trans_FullGrid              &
            ( +1, WORK1, V1 )   ! is=1:->Wa

         CALL FFT_DFS_235_SC_LOCAL_window_x_trans_FullGrid              &
            ( -1, WORK2, V1 )   ! is=1:->Wa

      do mj=1,JBW
      do mx=0,IB 
         sum= sum + (WORK1(mx,mj)-WORK2(mx,mj))**2.d0
      end do
      end do

         write(*,*)' WORK1(9,9)=', WORK1(9,9)
         write(*,*)' WORK2(9,9)=', WORK2(9,9)

         error= ( sum/ ( 2*JBW* dfloat(MT) ) )**0.5d0
         write(*,*)' Error of FFT_DFS_235_SC_LOCAL=  ',                 &
                    error ,'   CASE=','CC'

      if(error.GT.1.D-09) STOP                                          &
      'Something wrong in FFT_DFS_235_SC_LOCAL_window '

      write(*,*)
      write(*,*) '**e* TEST : FFT_COS_FTN_in_x_FullGrid ***********'
      write(*,*)
!c
!C--------------------------------------------------------------------C
      END SUBROUTINE TEST_FFT_window_x_trans_FullGrid
!**********************************************************************
!c
!c
!C--------------------------------------------------------------------C
!C                                                                    c
!C     Fast Fourier transform in x for JBW-grids in y                 c
!C                                                                    C
!C--------------------------------------------------------------------C
!**********************************************************************
!C
!C--------------------------------------------------------------------C
!c                                                                    c
!c     21 MAY 2013 : x-trans only for FFEM                            c
!c                 : JBW= even or odd                                 c
!c                 : JBWp= even                                       c
!c     22 MAY 2013 : Full grid = 00 grid                              c
!C                                                                    C
!C--------------------------------------------------------------------C
      SUBROUTINE FFT_DFS_235_SC_LOCAL_window_x_trans_FullGrid           &
      ( isign, PSI, ANM ) ! is=1:->Wa
!    &( isign, PSI, ANM, JT, TRANTYPE, FWAVEJ ) ! is=1:->Wa
!C--------------------------------------------------------------------C
        use parameter_pi
        use parameter_xdir_window
        use parameter_ydir_window
!C--------------------------------------------------------------------C
        implicit none
!C--------------------------------------------------------------------C
      integer      :: isign, JT
      real(kind=8) :: PSI(0:IB,JBW),ANM(0:MT,JBW)
      character(len=2) :: TRANTYPE            ! 'CC' 'CS' 'SC' 'SS'
!C-----local-variables------------------------------------------------C
      real(kind=8) :: mxx2(0:(JBW+IB),2)                          ! 2009.04.13
      real(kind=8) :: TRIGSIB(IB*2)
!C-----
      real(kind=8) :: data_ANYx(0:JBWp,0:IB)  !  -IBH:IBH
      real(kind=8) :: data_SINx(0:JBWp,0:IB),data_COSx(0:JBWp,0:IB )
      real(kind=8) :: partRE_SINx(0:JBWp,0:IBH)
      real(kind=8) :: partIM_SINx(0:JBWp,0:IBH)
      real(kind=8) :: SINHFx(0:IBH)
      real(kind=8) :: COSHFx(0:IBH)
      real(kind=8) :: COSPKx(0:IBH),SINPKx(0:IBH)
      real(kind=8) :: temp_SINx(0:JBWp)
      real(kind=8) :: ALON(0:JB,IB),BLON(0:JB,IB)

      real(kind=8) :: data_ANYy(0:MT,JBW)
!C-----
      CHARACTER(len=4) :: FFTOPT
      LOGICAL :: JUSDOIT=.TRUE.
!C-----
      integer      :: mx,mj,mw,i,j,k,j2n,mtlast,jllast
      real(kind=8) :: pin, aa, bb
!C--------------------------------------------------------------------C
!     PI    = DATAN(1.D0)*4.D0
!     PI2   = PI*2.d00
!     PI180 = PI/180.d00
!C--------------------------------------------------------------------C

!     if(mod(JBW,2)==1) stop ' == JBW should be an even integer == '

!C--------------------------------------------------------------------C

      IF(JUSDOIT) THEN
         JUSDOIT=.FALSE.

         do mx=0,JBW+IB ! 2009.04.13
            mxx2(mx,1)= mx*2
            mxx2(mx,2)= mx*2+1
         end do

!C---
              FFTOPT='P235'
              J2N= 1
        do k=1,20
              J2N= J2N*2
           if(IB.eq.J2N) then
!             FFTOPT='P222'
              EXIT
           endif
        end do        ! 2004.04.02      
           write(*,*) '  IB, FFTSOPT=',  IB, FFTOPT   
           write(*,*) ' JBW, FFTSOPT=', JBW, FFTOPT   

         CALL GPFASET_8_VEC(TRIGSIB ,IB )

            PIN= PI/IB
         do j=0,IBH                        ! For SINE and COSINE transform 
            aa= PIN*(j + 0.d0 )
            SINHFx(j)= DSIN(aa)
            COSHFx(j)= DCOS(aa)
         end do
         do k=0,IBH
            bb= PIN*dble(k)
            COSPKx(k)= DCOS(bb)
            SINPKx(k)= DSIN(bb)
         end do

      ENDIF

!C----------------------------------------------------------------------C

                                               MTlast= MT    ! Full-grid COS_FTN
!     IF(TRANTYPE(1:1).eq.'C' .and. MT.eq.IB ) MTlast= MT-1

!C=============================
          IF(isign.EQ.+1) THEN
!C=============================

!C-----(I,J)->(mx,J)

            data_ANYx( :,:)= 0.d0
            data_ANYy( :,:)= 0.d0
                 ANM(: ,: )= 0.d0
         Do J=1,JBW
         do I=0,IB
            data_ANYx(J,I)= PSI(I,J)
         end do
         END Do

      CALL COS_FTN_FullGrid                                             &
      ( data_ANYx, partRE_SINx, partIM_SINx,                            &
        temp_SINx, SINHFx, COSHFx, COSPKx, SINPKx,                      &
        ALON, BLON, TRIGSIB , IB , IB1  ,IBH, JB, isign )

         Do mw=0,MTlast    ! To set array for y-transform
         do J=1,JBW        ! data_ANYx(*,mw):  mw=1 -> COS 0 or SIN 1
!           data_ANYy(mw,J)= data_ANYx(J,mw+1)
            data_ANYy(mw,J)= data_ANYx(J,mw  )
         end do
         END Do

               ANM(:,:)    = data_ANYy(: ,:)

!C=============================
      ELSEIF(isign.EQ.-1) THEN
!C=============================
!C
            data_ANYx( :,:)= 0.d0
            data_ANYy( :,:)= ANM(:,:)
                 PSI(: ,: )= 0.d0

!C-----(mx,J)->(I,J)

         Do mw=0,MTlast
         do J=1,JBW          ! data_ANYx(*,mw):  mw=1 -> COS 0 or SIN 1
!           data_ANYx(J,mw+1)= data_ANYy(mw,J)
            data_ANYx(J,mw  )= data_ANYy(mw,J)
         end do
         END Do

      CALL COS_FTN_FullGrid                                             &
      ( data_ANYx, partRE_SINx, partIM_SINx,                            &
        temp_SINx, SINHFx, COSHFx, COSPKx, SINPKx,                      &
        ALON, BLON, TRIGSIB , IB , IB1  ,IBH, JB, isign )

         Do J=1,JBW
         do I=0,IB
            PSI(I,J)= data_ANYx(J,I)
         end do
         END Do

!C=============================
       ENDIF                  
!C=============================
!C
!C--------------------------------------------------------------------C
      END SUBROUTINE FFT_DFS_235_SC_LOCAL_window_x_trans_FullGrid
!**********************************************************************


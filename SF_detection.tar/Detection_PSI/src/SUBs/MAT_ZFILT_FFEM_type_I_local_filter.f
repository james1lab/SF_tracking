!23456789012345678901234567890123456789012345678901234567890123456789012
!**********************************************************************
!*                                                                    *
!*     MAT_LAP_ZVISFILT_JS2_Re_FEM_type_I.f                           *
!*                                                                    *
!*     x=sin(lat) coordinate, m=0,1,2,3,...                           *
!*                                                                    *
!*---  Tridiagonal solver of Laplacian operator is standard type I.   *   
!*       Standard type I gives poor accuracy for m=1 disturbance      *
!*                       , but appears robust in time integration.    *
!*        - Recommended to be used inversion only, not forward.       *
!*                                                                    *
!**********************************************************************
!*                                                                    *
!*     Spectral(x)-Galerkin(y) method : FFEM                          *
!*                                                                    *
!*     03 SEP 2012 : sinLat coordinate                                *
!*     15 OCT 2013 : for local high-order filter                      *
!*                                                                    *
!**********************************************************************
!*                                                                    *
!*     Matrices for Laplacian of PSI                                  *
!*                                                                    *
!**********************************************************************
      SUBROUTINE MAT200E_JS2_FEM_local
!C--------------------------------------------------------------------C
      use parameter_pi
      use parameter_xdir_window
      use parameter_ydir_window
      use common_highorder_filter_window
      use common_grid_boundary
        implicit none
!C-----local variable-------------------------------------------------C
      real(kind=8) :: YMATD(0:MT,3,JBW)
      real(kind=8) :: rat
      integer      :: js,jsmo,jcol,jcoljsm,mx,j,k,i,mc,mc1
      real(kind=8) :: mx2, thkp1,thk,thkm1
!C--------------------------------------------------------------------C
!     real(kind=8) :: rthetam(0:(JBW+1)), DELtheta(0:(JBW+1))  ! moved to Common
      real(kind=8) :: del
      real(kind=8) :: xa, xb, c1,c2,c3,c4, d1,d2,d3,d4, h1, h3
      real(kind=8) :: sum1, sum2
!C--------------------------------------------------------------------C
!C-----
      do mx=0,MT
         MSQUAR(mx)=  dfloat(mx)**2.d0 * ( window_alph**2.d0 )
      end do
!C-----
       del= ( rtheta2 - rtheta1 ) /(JBW-1.d0)

      if( rtheta1<(-PI/2.d0+del*2)) stop 'BN too close to Southpole '
      if( rtheta2>( PI/2.d0-del*2)) stop 'BN too close to Northpole '

!---- grid interval

      do j=0,JBW+1  ! full-grid including ghost points

         rthetam(j)=  rtheta1 + (j-1) * del
         rthetam(j)=  DSIN( rthetam(j) )
      enddo

      do j=1,JBW+1  ! full
         DELtheta(j)= rthetam(j)-rthetam(j-1)
!       write(*,*) rthetam(j-1), DELtheta(j), j
      enddo

!---- grid interval

!**************************************************
!*BEG  MATRIECS for LAPLACIAN OPERATOR            *
!**************************************************
!
         DMATm(: ,:,:)= 0.d0
         AMATm(: ,:,:)= 0.d0

      DO mx=0,MT

!*************
      do j=1,JBW
!*************
                   thkp1= rthetam(j+1)
                   thk  = rthetam(j  )
                   thkm1= rthetam(j-1)

          c1=  thkm1 + thkm1 - thkm1*thkm1
          c2=  thkp1 + thkp1 - thkp1*thkp1
          c3=  thkm1 + thk   - thkm1*thk  
          c4=  thkp1 + thk   - thkp1*thk
          d1=  thkm1 + thkm1 + thkm1*thkm1
          d2=  thkp1 + thkp1 + thkp1*thkp1
          d3=  thkm1 + thk   + thkm1*thk  
          d4=  thkp1 + thk   + thkp1*thk

          h1= ( thk  **3.d0 /3 - thkm1**3.d0 /3 - DELtheta(j  ) )       &
             / DELtheta(j  )**2.d0
          h3= ( thkp1**3.d0 /3 - thk  **3.d0 /3 - DELtheta(j+1) )       &
             / DELtheta(j+1)**2.d0

!      if(j==1) then
!
!         sum1=    +    (2-DELtheta(j  ))
!    &                         * dlog( ( 2- DELtheta(j  ) )/ 2  )
!         sum2=    +     2.d0  * dlog( ( 2- DELtheta(j  ) )/ 2  )
!
!      elseif(j>1) then

          sum1=    + (  (1-c3) * dlog( (thk  -1)/(thkm1-1) )            &
                       -(1+d3) * dlog( (thk  +1)/(thkm1+1) )  ) / 2
          sum2=    + (  (1-c1) * dlog( (thk  -1)/(thkm1-1) )            &
                       -(1+d1) * dlog( (thk  +1)/(thkm1+1) )  ) / 2

!      endif

         DMATm(mx,1,j)=                                                 &
         - MSQUAR(mx) * ((                                              &  ! A_k-1
               ( DELtheta(j  )                                          &
                   +     sum1                                           &
               ) / DELtheta(j  )**2.d0                                  &
                          ))                                            &
           - h1                                                     ! B_k-1

         DMATm(mx,2,j)=                                                 &
             MSQUAR(mx) * ((                                            &  ! A_k
              +( DELtheta(j  )                                          &
                   +     sum2                                           &
               ) / DELtheta(j  )**2.d0                                  &
              +( DELtheta(j+1)                                          &
                   + (  (1-c2) * dlog( (thkp1-1)/(thk  -1) )            &
                       -(1+d2) * dlog( (thkp1+1)/(thk  +1) )  ) / 2     &
               ) / DELtheta(j+1)**2.d0                                  &
                          ))                                            &
           + h1 + h3                                                ! B_k

         DMATm(mx,3,j)=                                                 & 
           - MSQUAR(mx) * ((                                            &! A_k+1
              +( DELtheta(j+1)                                          &
                   + (  (1-c4) * dlog( (thkp1-1)/(thk  -1) )            &
                       -(1+d4) * dlog( (thkp1+1)/(thk  +1) )  ) / 2     &
               ) / DELtheta(j+1)**2.d0                                  &
                          ))                                            &
           - h3                                                     ! B_k+1
 
         AMATm(mx,1,j)=   DELtheta(j  ) * 1 / 6.d0
         AMATm(mx,2,j)=   DELtheta(j  ) * 2 / 6.d0                      &
                        + DELtheta(j+1) * 2 / 6.d0
         AMATm(mx,3,j)=   DELtheta(j+1) * 1 / 6.d0
!
      end do ! j=1,JBW

!*************
         j= 1  ! BC modification =  Neumann condition
!*************

         AMATm(mx,3,j)=   AMATm(mx,3,j) + AMATm(mx,1,j)
         AMATm(mx,1,j)=   AMATm(mx,2,j)
         AMATm(mx,2,j)=   AMATm(mx,3,j)
         AMATm(mx,3,j)=   0.d0

         DMATm(mx,3,j)=   DMATm(mx,3,j) + DMATm(mx,1,j)
         DMATm(mx,1,j)=   DMATm(mx,2,j)
         DMATm(mx,2,j)=   DMATm(mx,3,j)
         DMATm(mx,3,j)=   0.d0

!*************
         j= JBW
!*************

         AMATm(mx,1,j)=   AMATm(mx,1,j) + AMATm(mx,3,j)
         AMATm(mx,3,j)=   0.d0

         DMATm(mx,1,j)=   DMATm(mx,1,j) + DMATm(mx,3,j)
         DMATm(mx,3,j)=   0.d0

      END DO ! mx=0,MT

!**************************************************
!*END  MATRIECS for LAPLACIAN OPERATOR            *
!**************************************************
!C
!**************************************************
!*BEG  Time saving, prehandling of the MATRIX     *
!**************************************************

!c---- AMAT * Vorticity = DMAT * streamfunction
!c
!Cbeg-------------------------------------------------- DMAT -> DMAT_
!c
!c                12......                12......     
!c                123.....                .12.....
!c        DMATx   .123....       DMATx_   ..12....
!c                ........                ...12...
!c                .....123                ........
!c                ......12                ......12
!c
!C-----------------------------------------------------

            YMATD( : ,:,: )= DMATm( :,:,: )

      do mc=1,JBW-1                    
         mc1= mc+1
       Do mx=0,MT

         rat= YMATD( mx,1,mc1) / YMATD( mx,1,mc)

!cnext-sub   YMAT(mc )= YMAT(mc )*rat   
            YMATD( mx,2,mc1)= YMATD( mx,2,mc1)-YMATD( mx,2,mc )*rat    
!cnext-sub   YMAT(mc1)= YMAT(mc1)-YMAT(mc )
            YMATD( mx,1,mc1)= YMATD( mx,2,mc1)
            YMATD( mx,2,mc1)= YMATD( mx,3,mc1)

            DMATm_( mx,1,mc )= 1.d0/YMATD( mx,1,mc ) !! (1/*)

            DMATm_( mx,2,mc )=      YMATD( mx,2,mc )
            DMATm_( mx,3,mc )= rat
       END Do ! par
      end do ! mc=1,JBW-1

       Do mx=0,MT
            DMATm_( mx,1,JBW)= 1.d0/YMATD( mx,1,JBW) !! (1/*)
       END Do ! par
!c
!Cend-------------------------------------------------- DMAT -> DMAT_


!Cbeg-------------------------------------------------- AMAT -> AMAT_

            YMATD( : ,:,: )= AMATm( :,:,: )

      do mc=1,JBW-1                    
         mc1= mc+1
       Do mx=0,MT

         rat= YMATD( mx,1,mc1) / YMATD( mx,1,mc)

!cnext-sub   YMAT(mc )= YMAT(mc )*rat   
            YMATD( mx,2,mc1)= YMATD( mx,2,mc1)-YMATD( mx,2,mc )*rat    
!cnext-sub   YMAT(mc1)= YMAT(mc1)-YMAT(mc )
            YMATD( mx,1,mc1)= YMATD( mx,2,mc1)
            YMATD( mx,2,mc1)= YMATD( mx,3,mc1)

            AMATm_( mx,1,mc )= 1.d0/YMATD( mx,1,mc ) !! (1/*)

            AMATm_( mx,2,mc )=      YMATD( mx,2,mc )
            AMATm_( mx,3,mc )= rat
       END Do ! par
      end do ! mc

       Do mx=0,MT
            AMATm_( mx,1,JBW)= 1.d0/YMATD( mx,1,JBW) !! (1/*)
       END Do ! par

!Cend-------------------------------------------------- AMAT -> AMAT_

!**************************************************
!*END  Time saving, prehandling of the MATRIX     *
!**************************************************
!
!C--------------------------------------------------------------------C
      END SUBROUTINE MAT200E_JS2_FEM_local
!**********************************************************************
!C
!23456789012345678901234567890123456789012345678901234567890123456789012
!**********************************************************************
!*                                                                    *
!*     Spectral(x)-Galerkin(y) method                                 *
!*                                                                    *
!*     03 SEP 2012 : sinLat coordinate                                *
!*     18 NOV 2012 : DMATmi_ moved to common_module                   *
!*                                                                    *
!**********************************************************************
      SUBROUTINE MAT200S_JS2_FEM_local( alpha, DMATmi_ )
!C--------------------------------------------------------------------C
      use parameter_pi
      use parameter_xdir_window
      use parameter_ydir_window
      use common_highorder_filter_window
      use common_grid_boundary
        implicit none
!C--------------------------------------------------------------------C
      real(kind=8), intent(in ) :: alpha
      real(kind=8), intent(out) :: DMATmi_(0:MT,3,JBW)
!C-----local variable-------------------------------------------------C
      real(kind=8) :: YMATD(0:MT,3,JBW)
      real(kind=8) :: rat
      integer      :: js,jsmo,jcol,jcoljsm,mx,j,k,i,mc,mc1
      integer      :: jbeg
      real(kind=8) :: mx2, thkp1,thk,thkm1
!C--------------------------------------------------------------------C
!C
      if(alpha.eq.0.d0) stop 'The alpha is zero: SUB MAT200S_JS2_FEM'
!C
!----
!**************************************************
!*BEG  MATRIECS for LAPLACIAN OPERATOR            *
!**************************************************
!
      do j=1,JBW      
         DMATmi_(:,:,j)= AMATm(:,:,j) + alpha * DMATm(:,:,j)
      end do
!c
!**************************************************
!*END  MATRIECS for LAPLACIAN OPERATOR            *
!**************************************************
!C
!**************************************************
!*BEG  Time saving, prehandling of the MATRIX     *
!**************************************************

!Cbeg-------------------------------------------------- DMATmi_

         do mc=1,JBW
          Do mx=0,MT
            YMATD( mx,1,mc)= DMATmi_(mx,1,mc)
            YMATD( mx,2,mc)= DMATmi_(mx,2,mc) 
            YMATD( mx,3,mc)= DMATmi_(mx,3,mc)
          END Do
         end do

      do mc=1,JBW-1                    
         mc1= mc+1
       Do mx=0,MT

         rat= YMATD( mx,1,mc1) / YMATD( mx,1,mc)

!cnext-sub   YMAT(mc )= YMAT(mc )*rat   
            YMATD( mx,2,mc1)= YMATD( mx,2,mc1)-YMATD( mx,2,mc )*rat    
!cnext-sub   YMAT(mc1)= YMAT(mc1)-YMAT(mc )
            YMATD( mx,1,mc1)= YMATD( mx,2,mc1)
            YMATD( mx,2,mc1)= YMATD( mx,3,mc1)

            DMATmi_( mx,1,mc )= 1.d0/YMATD( mx,1,mc ) !! (1/*)

            DMATmi_( mx,2,mc )=      YMATD( mx,2,mc )
            DMATmi_( mx,3,mc )= rat
       END Do ! par
      end do ! mc=1,JBW-1

       Do mx=0,MT
            DMATmi_( mx,1,JBW)= 1.d0/YMATD( mx,1,JBW) !! (1/*)
       END Do ! par
!c
!Cend-------------------------------------------------- DMATmi_
!
!**************************************************
!*BEG  Time saving, prehandling of the MATRIX     *
!**************************************************

!C--------------------------------------------------------------------C
      END SUBROUTINE MAT200S_JS2_FEM_local
!**********************************************************************
!C
!C
!**********************************************************************
!*                                                                    *
!*     Spectral(x)-Galerkin(y) method                                 *
!*                                                                    *
!*     Laplacian of X = Y , Inverse Laplacian of Y = X                *
!*     on the Spherical Domain including the Poles                    *
!*                                                                    *
!*    [CALL MAT200E] -> [CALL LAP200E]                                *
!*                                                                    *
!*     03 SEP 2012 : sinLat coordinate                                *
!*     26 OCT 2012 : Lap of (*) is more stable and accurate           *
!*                   than psi->u,v->Vor in SWE simulation.            *
!*                                                                    *
!**********************************************************************
!C                                     MSEL=0 : Laplacian TC1 -> AJX   
!C                                          1 : Inverse                
!C--------------------------------------------------------------------C
      SUBROUTINE LAP200E_JS2_FEM_local( TC1, AJX , MSEL )
!C--------------------------------------------------------------------C
      use parameter_pi
      use parameter_xdir_window
      use parameter_ydir_window
      use common_highorder_filter_window
      use common_grid_boundary
        implicit none
!C--------------------------------------------------------------------C
      real(kind=8) :: TC1(0:MT,JBW), AJX(0:MT,JBW)
      integer, intent(in) :: MSEL
!C-----local variable-------------------------------------------------C
      real(kind=8) :: a4,a5,a6,ace,aaa,XMAT0
      integer      :: js,jcol,jja,jjb,jjc,mx,mc,mc1,mco,mcop1,jjj
!C--------------------------------------------------------------------C
!     JL=JBW, JLH=JB

!C--------------------------------------------------------------------C
          IF(MSEL.eq.0) THEN           ! Laplacian of TC1 = AJX
!C--------------------------------------------------------------------C
!
         AJX(:,:)= 0.d0 

!c---- 1  To get YMAT, YMAT= DMAT*TC1

         do jcol=2,JBW-1
            jja= jcol-1
            jjb= jcol
            jjc= jcol+1
          Do mx=0,MT
             a4= DMATm(mx,1,jcol)
             a5= DMATm(mx,2,jcol)
             a6= DMATm(mx,3,jcol)
             ace=( a5 )*TC1(mx,jjb)
            YMAT(mx,jcol)= a4*TC1(mx,jja) + ace + a6*TC1(mx,jjc)
          END Do ! par
         end do

            jcol=1
            jjb= jcol
            jjc= jcol+1
          Do mx=0,MT
             a4= DMATm(mx,1,jcol)
             a5= DMATm(mx,2,jcol)
            YMAT(mx,jcol)=( a4 )*TC1(mx,jjb)+a5*TC1(mx,jjc)
          END Do ! par

            jcol=JBW 
            jja= jcol-1
            jjb= jcol
          Do mx=0,MT
             a4= DMATm(mx,1,jcol)
             a5= DMATm(mx,2,jcol)
            YMAT(mx,jcol)= a4*TC1(mx,jja)+( a5 )*TC1(mx,jjb)
          END Do ! par

!c---- 2  To get ZETA, AMAT*ZETA= YMAT

         do mc=1,JBW-1
            mc1= mc+1
          Do mx=0,MT
            YMAT(mx,mc1)= YMAT(mx,mc1)-YMAT(mx,mc )*AMATm_(mx,3,mc)
          END Do ! par
         end do

          Do mx=0,MT
            YMAT(mx,JBW)=  YMAT(mx,JBW) * AMATm_(mx,1,JBW) !! (1/*)
          END Do ! par

         do mco=JBW-1,1,-1
            mcop1=mco+1
          Do mx=0,MT
                 aaa =  YMAT(mx,mcop1)*AMATm_(mx,2,mco)
            YMAT(mx,mco)= (YMAT(mx,mco)-aaa) * AMATm_(mx,1,mco)
          END Do ! par
         end do

         do jcol=1,JBW
            jjj= jcol
          Do mx=0,MT
            AJX(mx,jjj)= YMAT(mx,jcol)
          END Do ! par
         end do

!C--------------------------------------------------------------------C
      ELSEIF(MSEL.eq.1) THEN           ! Inverse Laplacian of AJX= TC1
!C--------------------------------------------------------------------C

         TC1(:,:)= 0.d0 

!c---- 1  To get YMAT, YMAT= AMAT*ZETA

         do jcol=2,JBW-1
            jja=  jcol-1
            jjb=  jcol
            jjc=  jcol+1
          Do mx=0,MT
             a4= AMATm(mx,1,jcol)
             a5= AMATm(mx,2,jcol)
             a6= AMATm(mx,3,jcol)
             aaa = a5*AJX(mx,jjb)
            YMAT(mx,jcol)= a4*AJX(mx,jja)+ aaa +a6*AJX(mx,jjc)
          END Do ! par
         end do

            jcol=1
            jjb= jcol
            jjc= jcol+1
          Do mx=0,MT
             a4= AMATm(mx,1,jcol)
             a5= AMATm(mx,2,jcol)
            YMAT(mx,jcol)= a4*AJX(mx,jjb)+a5*AJX(mx,jjc)
          END Do ! par

            jcol=JBW
            jja= jcol-1
            jjb= jcol
          Do mx=0,MT
             a4= AMATm(mx,1,jcol)
             a5= AMATm(mx,2,jcol)
            YMAT(mx,jcol)= a4*AJX(mx,jja)+a5*AJX(mx,jjb)
          END Do ! par

!c---- 2  To get PSI, DMAT*PSI= YMAT

         do mc=1,JBW-1
            mc1= mc+1
          Do mx=0,MT
            YMAT(mx,mc1)= YMAT(mx,mc1)-YMAT(mx,mc )*DMATm_(mx,3,mc)
          END Do ! par
         end do

          Do mx=0,MT
            YMAT(mx,JBW)=  YMAT(mx,JBW) * DMATm_(mx,1,JBW) !! (1/*)
          END Do ! par

         do mco=JBW-1,1,-1
            mcop1=mco+1
          Do mx=0,MT
                 aaa =  YMAT(mx,mcop1)*DMATm_(mx,2,mco)
            YMAT(mx,mco)= (YMAT(mx,mco)-aaa) * DMATm_(mx,1,mco)
          END Do ! par
         end do

         do jcol=1,JBW
            jjj= jcol
          Do mx=2,MT
            TC1(mx,jjj)= YMAT(mx,jcol)
          END Do ! par
         end do

!C--------------------------------------------------------------------C
       ENDIF
!C--------------------------------------------------------------------C
!
!C--------------------------------------------------------------------C
      END SUBROUTINE LAP200E_JS2_FEM_local
!**********************************************************************

!**********************************************************************
!*                                                                    *
!*     Spectral(x)-Galerkin(y) method                                 *
!*                                                                    *
!*     Laplacian of X = Y , Inverse Laplacian of Y = X                *
!*     on the Spherical Domain including the Poles                    *
!*                                                                    *
!*    [CALL MAT200S] -> [CALL LAP200S]                                *
!*                                                                    *
!*     03 SEP 2012 : sinLat coordinate                                *
!*     18 NOV 2012 : DMATmi_ moved to common_module                   *
!*                                                                    *
!**********************************************************************
!*                                                                    *
!*     AJXzeta: in & distroyed & out                                  *
!*     AJX    : work array                                            *
!*                                                                    *
!**********************************************************************
!C                                     MSEL=0 : Laplacian TC1 -> AJX   
!C                                          1 : Inverse                
!C--------------------------------------------------------------------C
      SUBROUTINE LAP200S_JS2_FEM_local ( alpha, DMATmi_, AJX )
!C--------------------------------------------------------------------C
      use parameter_pi
      use parameter_xdir_window
      use parameter_ydir_window
      use common_highorder_filter_window
      use common_grid_boundary
        implicit none
!C--------------------------------------------------------------------C
      real(kind=8), intent(in   ) :: alpha, DMATmi_(0:MT,3,JBW)
      real(kind=8), intent(inout) :: AJX(0:MT,JBW)
!C-----local variable-------------------------------------------------C
      real(kind=8) :: a4,a5,a6,ace,aaa,XMAT0
      integer      :: js,jcol,jja,jjb,jjc,mx,mc,mc1,mco,mcop1,jjj
!C--------------------------------------------------------------------C

!c---- 1  To get YMAT, YMAT= AMAT*ZETA

         do jcol=2,JBW-1
            jja=  jcol-1
            jjb=  jcol
            jjc=  jcol+1
          Do mx=0,MT
             a4= AMATm(mx,1,jcol)
             a5= AMATm(mx,2,jcol)
             a6= AMATm(mx,3,jcol)
             aaa = a5*AJX(mx,jjb)
            YMAT(mx,jcol)= a4*AJX(mx,jja)+ aaa +a6*AJX(mx,jjc)
          END Do ! par
         end do

            jcol=1
            jjb= jcol
            jjc= jcol+1
          Do mx=0,MT
             a4= AMATm(mx,1,jcol)
             a5= AMATm(mx,2,jcol)
            YMAT(mx,jcol)= a4*AJX(mx,jjb)+a5*AJX(mx,jjc)
          END Do ! par

            jcol=JBW
            jja= jcol-1
            jjb= jcol
          Do mx=0,MT
             a4= AMATm(mx,1,jcol)
             a5= AMATm(mx,2,jcol)
            YMAT(mx,jcol)= a4*AJX(mx,jja)+a5*AJX(mx,jjb)
          END Do ! par

!c---- 2  To get PSI, DMAT*PSI= YMAT

         do mc=1,JBW-1
            mc1= mc+1
          Do mx=0,MT
            YMAT(mx,mc1)= YMAT(mx,mc1) -YMAT(mx,mc )*DMATmi_(mx,3,mc)
          END Do ! par
         end do

          Do mx=0,MT
            YMAT(mx,JBW)=  YMAT(mx,JBW) * DMATmi_(mx,1,JBW) !! (1/*)
          END Do ! par

         do mco=JBW-1,1,-1
            mcop1=mco+1
          Do mx=0,MT
                 aaa =  YMAT(mx,mcop1)*DMATmi_(mx,2,mco)
            YMAT(mx,mco)= (YMAT(mx,mco)-aaa) * DMATmi_(mx,1,mco)
          END Do ! par
         end do

         do jcol=1,JBW
            jjj= jcol
          Do mx=0,MT
            AJX(mx,jjj)= YMAT(mx,jcol)
          END Do ! par
         end do
!
!**********************************************************************
      END SUBROUTINE LAP200S_JS2_FEM_local
!**********************************************************************

!23456789012345678901234567890123456789012345678901234567890123456789012
!**********************************************************************
!*                                                                    *
!*     Spectral(x)-Galerkin(y) method                                 *
!*                                                                    *
!*     VISCOSITY-FILTERING(SMOOTHING) BY INVERSION OF ELLIPTIC EQS.   *
!*     with COMPLEX TRIDIAGONAL SYSTEM                                *
!*                                                                    *
!*    [1-LAP], [1+LAP^2], [1-LAP^3], [1+LAP^4]                        *
!*                                                                    *
!*     remarks : Optimization must be done by inputting two variables *
!*                                                                    *
!*     03 SEP 2012 : sinLat coordinate                                *
!*                                                                    *
!**********************************************************************
!     SUBROUTINE ZVISFILT8_JS2_Re( V3, D3, gamma0, LAP_DIM ) !
      SUBROUTINE ZVISFILT8_JS2_Re_FEM_local( V3, gamma0, LAP_DIM ) ! 02 JUN 2008
!C--------------------------------------------------------------------C
      use parameter_pi
      use parameter_xdir_window
      use parameter_ydir_window
      use common_highorder_filter_window
      use common_grid_boundary
        implicit none
!C--------------------------------------------------------------------C
      real(kind=8) :: V3(0:MT,JBW)
      real(kind=8), intent(in) :: gamma0
      integer     , intent(in) :: LAP_DIM
!C-----local-variable-------------------------------------------------C
      real(kind=8) :: AJX_RE(0:MT,JBW),ZDMATmi_a_RE(0:MT,3,JBW,8)
      real(kind=8) :: AJX_IM(0:MT,JBW),ZDMATmi_a_IM(0:MT,3,JBW,8)
      complex(kind=8) :: zalpha(8)
      real(kind=8) :: gam_old=-0.d0, gam_new, ashif,xx,ccc,sss
      integer      :: k,i,mj,mx
!C--------------------------------------------------------------------C

      IF(LAP_DIM.gt.8) STOP ' != LAP_DIM must not be larger than 6 !!!'

         gam_new= gamma0
      IF(gam_old.NE.gam_new) THEN
         gam_old= gam_new        

             ashif= 1-mod(LAP_DIM,2)
          DO k=1,LAP_DIM
             xx=(PI*ashif+(k-1)*PI2)/dfloat(LAP_DIM)
            ccc= DCOS(xx)
            sss= DSIN(xx)
          zalpha(k)= -dcmplx(ccc,sss)
          END DO

          zalpha(:)=  zalpha(:)*gamma0

          DO i=1,LAP_DIM 
      CALL ZMAT200S_JS2_Re_FEM_local( zalpha(i), ZDMATmi_a_RE( 0 ,1,1,i)      &
                               , ZDMATmi_a_IM( 0 ,1,1,i) ) ! 28 JUL 2008
          END DO ! i=1,LAP_DIM
  
      ENDIF ! JUSTDOIT

!--- filtering ===================================================

           do mj=1,JBW   ! =0,JL 28 JUL 2008
           do mx=0,MT
              AJX_RE(mx,mj)= V3( mx,mj)
              AJX_IM(mx,mj)= 0.d0        ! unpaired, unfortunately
           end do
           end do ! mj=

       DO i=1,LAP_DIM
      CALL ZLAP200S_JS2_FEM_local( AJX_RE, AJX_IM, ZDMATmi_a_RE( 0 ,1,1,i)    &
                         , ZDMATmi_a_IM( 0 ,1,1,i) )    ! 28 JUL 2008
       END DO ! i=1,LAP_DIM

           do mj=1,JBW
           do mx=0,MT
              V3( mx,mj)= AJX_RE(mx,mj)
           end do
           end do
!
!C--------------------------------------------------------------------C
      END SUBROUTINE ZVISFILT8_JS2_Re_FEM_local
!**********************************************************************
!C
!C
!**********************************************************************
!*                                                                    *
!*     Spectral(x)-Galerkin(y) method                                 *
!*                                                                    *
!*     VISCOSITY-FILTERING(SMOOTHING) BY INVERSION OF ELLIPTIC EQS.   *
!*     To solve for psi; COMPLEX VARIABLES                            *
!*     psi + alpha* ( LAPLACian of psi ) = X_i,j ,                    *
!*     which arises from the high-order spectral filter               *
!*                                                                    *
!*    [CALL ZMAT200S] -> [CALL ZLAP200S] : COMPLEX-variable version   *
!*                                                                    *
!*     03 SEP 2012 : sinLat coordinate                                *
!*                                                                    *
!**********************************************************************
!     SUBROUTINE ZMAT200S_JS2 ( zalpha, ZDMATmi_ )
      SUBROUTINE ZMAT200S_JS2_Re_FEM_local ( zalpha, ZDMATmi_RE, ZDMATmi_IM )
!C--------------------------------------------------------------------C
      use parameter_pi
      use parameter_xdir_window
      use parameter_ydir_window
      use common_highorder_filter_window
      use common_grid_boundary
        implicit none
!C--------------------------------------------------------------------C
      complex(kind=8) :: zalpha
      real(kind=8) :: ZDMATmi_RE(0:MT,3,JBW)
      real(kind=8) :: ZDMATmi_IM(0:MT,3,JBW)
!C-----local variable-------------------------------------------------C
      real(kind=8) :: ZYMATD_RE(0:MT,3,JBW)
      real(kind=8) :: ZYMATD_IM(0:MT,3,JBW) 
      real(kind=8) :: zalpha_RE, zalpha_IM
      real(kind=8) :: zdv, zrat_RE, zrat_IM
      integer      :: js,k,i,mx,mc,mc1
      real(kind=8) :: mx2
!C--------------------------------------------------------------------C
!C
      if(zalpha.eq.0.d0) stop 'The zalpha is zero: SUB ZMAT200S_...'
!C
         zalpha_RE= REal(zalpha)   ! 17 MAY 2008
         zalpha_IM= IMag(zalpha)   

!**************************************************
!*BEG  MATRIECS for LAPLACIAN OPERATOR            * SEMI-IMPLICIT
!**************************************************

!Cbeg-- Matrices for Y= ( D^2/Dlambda^2 + COS(LAT) D/Dphi COS(LAT) D/Dphi ) X

      do k=1,JBW
!        ZDMATmi_(mx,i,Ks)= AMATm   i,K) + zalpha*DMATm(mx,i,K)
         ZDMATmi_RE(:,:,k)= AMATm(:,:,k) + DMATm(:,:,k) * zalpha_RE  ! 17 MAY 2008, 28 JUL 2008 
         ZDMATmi_IM(:,:,k)= 0.d0         + DMATm(:,:,k) * zalpha_IM
      end do

!**************************************************
!*END  MATRIECS for LAPLACIAN OPERATOR            * SEMI-IMPLICIT
!**************************************************
!C

!C
!**************************************************
!*BEG  Time saving, prehandling of the MATRIX     * SEMI-IMPLICIT
!**************************************************

!23456789012345678901234567890123456789012345678901234567890123456789012

!Cbeg-------------------------------------------------- DMAT -> ZDMAT_
!C-----m0,m1,m2,(n1) and m0,m1,m2,(n2)

         do mc=1,JBW      ! mc=1,JBW : 16 OCT 2013
          DO mx=0,MT
            ZYMATD_RE( mx,1,mc)= ZDMATmi_RE(mx,1,mc)
            ZYMATD_RE( mx,2,mc)= ZDMATmi_RE(mx,2,mc)
            ZYMATD_RE( mx,3,mc)= ZDMATmi_RE(mx,3,mc)
            ZYMATD_IM( mx,1,mc)= ZDMATmi_IM(mx,1,mc)
            ZYMATD_IM( mx,2,mc)= ZDMATmi_IM(mx,2,mc)
            ZYMATD_IM( mx,3,mc)= ZDMATmi_IM(mx,3,mc)
          END Do
         end do
!c-------------------
      do mc=1,JBW-1  
         mc1= mc+1   
       Do mx=0,MT

             zdv= ZYMATD_RE( mx,1,mc)**2.d0 + ZYMATD_IM( mx,1,mc)**2.d0
            zrat_RE=( ZYMATD_RE( mx,1,mc1)*ZYMATD_RE( mx,1,mc)          &
                    + ZYMATD_IM( mx,1,mc1)*ZYMATD_IM( mx,1,mc) ) / zdv
            zrat_IM=(-ZYMATD_RE( mx,1,mc1)*ZYMATD_IM( mx,1,mc)          &
                    + ZYMATD_IM( mx,1,mc1)*ZYMATD_RE( mx,1,mc) ) / zdv

!cnext-sub   ZYMAT(mc )= ZYMAT(mc )*zrat
            ZYMATD_RE( mx,2,mc1)= ZYMATD_RE( mx,2,mc1)                  &
                               -( ZYMATD_RE( mx,2,mc )*zrat_RE          &
                                 -ZYMATD_IM( mx,2,mc )*zrat_IM )
            ZYMATD_IM( mx,2,mc1)= ZYMATD_IM( mx,2,mc1)                  &
                               -( ZYMATD_RE( mx,2,mc )*zrat_IM          &
                                 +ZYMATD_IM( mx,2,mc )*zrat_RE )
!cnext-sub   ZYMAT(mc1)= ZYMAT(mc1)-ZYMAT(mc )

            ZYMATD_RE( mx,1,mc1)= ZYMATD_RE( mx,2,mc1)
            ZYMATD_RE( mx,2,mc1)= ZYMATD_RE( mx,3,mc1)
            ZYMATD_IM( mx,1,mc1)= ZYMATD_IM( mx,2,mc1)
            ZYMATD_IM( mx,2,mc1)= ZYMATD_IM( mx,3,mc1)

!           ZDMATmi_( mx,1,mc )= 1.d0/ZYMATD( mx,1,mc ) !! (1/*)

             zdv= ZYMATD_RE( mx,1,mc)**2.d0 + ZYMATD_IM( mx,1,mc)**2.d0
            ZDMATmi_RE( mx,1,mc )=  ZYMATD_RE( mx,1,mc)/zdv
            ZDMATmi_IM( mx,1,mc )= -ZYMATD_IM( mx,1,mc)/zdv
!
!           ZDMATmi_( mx,2,mc )=      ZYMATD( mx,2,mc )       
!           ZDMATmi_( mx,3,mc )= zrat
!
            ZDMATmi_RE( mx,2,mc )=  ZYMATD_RE( mx,2,mc )       
            ZDMATmi_IM( mx,2,mc )=  ZYMATD_IM( mx,2,mc )       
            ZDMATmi_RE( mx,3,mc )=  zrat_RE
            ZDMATmi_IM( mx,3,mc )=  zrat_IM
       END Do ! par
      end do ! mc=1,JBW-1

       Do mx=0,MT
!           ZDMATmi_( mx,1,JBW)= 1.d0/ZYMATD( mx,1,JBW) !! (1/*)

             zdv= ZYMATD_RE( mx,1,JBW)**2.d0+ZYMATD_IM( mx,1,JBW)**2.d0
            ZDMATmi_RE( mx,1,JBW)=  ZYMATD_RE( mx,1,JBW)/zdv
            ZDMATmi_IM( mx,1,JBW)= -ZYMATD_IM( mx,1,JBW)/zdv
       END Do ! par

!Cend-------------------------------------------------- DMAT -> DMAT_

!**************************************************
!*END  Time saving, prehandling of the MATRIX     * SEMI-IMPLICIT
!**************************************************

!C--------------------------------------------------------------------C
      END SUBROUTINE ZMAT200S_JS2_Re_FEM_local
!**********************************************************************
!C
!C
!**********************************************************************
!*                                                                    *
!*     Spectral(x)-Galerkin(y) method                                 *
!*                                                                    *
!*     VISCOSITY-FILTERING(SMOOTHING) BY INVERSION OF ELLIPTIC EQS.   *
!*                                                                    *
!*     To get psi or Div from : COMPLEX VARIABLES                     *
!*                                                                    *
!*     psi + zalpha * ( Laplacian of psi ) = Y  : Global Ave[Y] !=0   *
!*     Div + zalpha * ( Laplacian of Div ) = Z  : Global Ave[Z]  =0   *
!*                                               because [Div]  =0    *
!*    [CALL ZMAT200S] -> [CALL ZLAP200S] : COMPLEX-variable version   *
!*                                                                    *
!*     03 SEP 2012 : sinLat coordinate                                *
!*                                                                    *
!**********************************************************************
!     SUBROUTINE ZMAT200S_JS2 ( zalpha, ZDMATmi_ )
!**********************************************************************
      SUBROUTINE ZLAP200S_JS2_FEM_local                                 &
      ( AJX_RE, AJX_IM, ZDMATmi_RE, ZDMATmi_IM )
!C--------------------------------------------------------------------C
      use parameter_pi
      use parameter_xdir_window
      use parameter_ydir_window
      use common_highorder_filter_window
      use common_grid_boundary
        implicit none
!C--------------------------------------------------------------------C
      real(kind=8) :: AJX_RE(0:MT,JBW), ZDMATmi_RE(0:MT,3,JBW)
      real(kind=8) :: AJX_IM(0:MT,JBW), ZDMATmi_IM(0:MT,3,JBW)
!C-----local-variable-------------------------------------------------C
      real(kind=8) :: ZYMAT_RE( 0 :MT,JBW), ZYMAT_IM( 0 :MT,JBW)
      real(kind=8) :: ajx0r,ajx0i,dd,a4,a5,a6,zaaar,zaaai,parRE,parIM
      real(kind=8) :: tc10r,tc10i
      integer      :: mj,js,jcol,jja,jjb,jjc
      integer      :: mx,mc,mc1,mco,mcop1,jjj
!C--------------------------------------------------------------------C

!c---- 1  To get YMAT, YMAT= AMAT*ZETA

         do jcol=2,JBW-1
            jja= jcol-1
            jjb= jcol
            jjc= jcol+1
          Do mx=0,MT
             a4= AMATm( mx,1,jcol)
             a5= AMATm( mx,2,jcol)
             a6= AMATm( mx,3,jcol)
          ZYMAT_RE(mx,jcol)= a4*AJX_RE(mx,jja)+a5*AJX_RE(mx,jjb)        &
                           +a6*AJX_RE(mx,jjc)
          ZYMAT_IM(mx,jcol)= a4*AJX_IM(mx,jja)+a5*AJX_IM(mx,jjb)        &
                           +a6*AJX_IM(mx,jjc)
          END Do ! par
         end do
            jcol=1
            jjb= jcol
            jjc= jcol+1
          Do mx=0,MT
             a4= AMATm( mx,1,jcol)
             a5= AMATm( mx,2,jcol)
          ZYMAT_RE(mx,jcol)= a4*AJX_RE(mx,jjb)+a5*AJX_RE(mx,jjc)
          ZYMAT_IM(mx,jcol)= a4*AJX_IM(mx,jjb)+a5*AJX_IM(mx,jjc)
          END Do ! par
            jcol=JBW
            jja= jcol-1
            jjb= jcol
          Do mx=0,MT
             a4= AMATm( mx,1,jcol)
             a5= AMATm( mx,2,jcol)
          ZYMAT_RE(mx,jcol)= a4*AJX_RE(mx,jja)+a5*AJX_RE(mx,jjb)
          ZYMAT_IM(mx,jcol)= a4*AJX_IM(mx,jja)+a5*AJX_IM(mx,jjb)
          END Do ! par

!c---- 2  To get PSI, DMAT*PSI= YMAT

         do mc=1,JBW-1 
            mc1= mc+1
          Do mx=0,MT
           ZYMAT_RE(mx,mc1)=  ZYMAT_RE(mx,mc1)                          &
                             -ZYMAT_RE(mx,mc )*ZDMATmi_RE(mx,3,mc)      &
                             +ZYMAT_IM(mx,mc )*ZDMATmi_IM(mx,3,mc)    
           ZYMAT_IM(mx,mc1)=  ZYMAT_IM(mx,mc1)                          &
                             -ZYMAT_RE(mx,mc )*ZDMATmi_IM(mx,3,mc)      &
                             -ZYMAT_IM(mx,mc )*ZDMATmi_RE(mx,3,mc)
          END Do ! par
         end do

          Do mx=0,MT
                     zaaar =  ZYMAT_RE(mx,JBW)*ZDMATmi_RE(mx,1,JBW)     & !! (1/*)
                             -ZYMAT_IM(mx,JBW)*ZDMATmi_IM(mx,1,JBW)      !! (1/*)
                     zaaai =  ZYMAT_RE(mx,JBW)*ZDMATmi_IM(mx,1,JBW)     & !! (1/*)
                             +ZYMAT_IM(mx,JBW)*ZDMATmi_RE(mx,1,JBW)      !! (1/*)
           ZYMAT_RE(mx,JBW)=  zaaar
           ZYMAT_IM(mx,JBW)=  zaaai
          END Do ! par

         do mco=JBW-1,1,-1
            mcop1=mco+1
          Do mx=0,MT
                zaaar=  ZYMAT_RE(mx,mcop1)*ZDMATmi_RE(mx,2,mco)         &
                       -ZYMAT_IM(mx,mcop1)*ZDMATmi_IM(mx,2,mco)
                zaaai=  ZYMAT_RE(mx,mcop1)*ZDMATmi_IM(mx,2,mco)         &
                       +ZYMAT_IM(mx,mcop1)*ZDMATmi_RE(mx,2,mco)
                parRE=  ZYMAT_RE(mx,mco)-zaaar
                parIM=  ZYMAT_IM(mx,mco)-zaaai
           ZYMAT_RE(mx,mco)= parRE*ZDMATmi_RE(mx,1,mco)                 &
                            -parIM*ZDMATmi_IM(mx,1,mco)
           ZYMAT_IM(mx,mco)= parRE*ZDMATmi_IM(mx,1,mco)                 &
                            +parIM*ZDMATmi_RE(mx,1,mco)
          END Do ! par
         end do

         do jcol=1,JBW
            jjj= jcol
          Do mx=0,MT
            AJX_RE(mx,jjj)= ZYMAT_RE(mx,jcol)
            AJX_IM(mx,jjj)= ZYMAT_IM(mx,jcol)
          END Do ! par
         end do

!C--------------------------------------------------------------------C
      END SUBROUTINE ZLAP200S_JS2_FEM_local
!**********************************************************************
!C

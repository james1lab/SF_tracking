!23456789012345678901234567890123456789012345678901234567890123456789012
!*********************************************************************
!                                                                    *
!     MAT_LAP_ZVISFILT_JS2_Re_FEM_type_II_a.f                        *
!                                                                    *
!       LAPLACIAN operator in x(=sinLat) coordinate                  *
!                                                                    *
!     m=0          : Vor     =   (d/dx)(1-x^2)(d/dx) Psi             *
!                              +(( -m^2)/(1-x^2)) Psi                *
!     m=1,3,5,7... : Vor/Cos =   (d/dx)(1-x^2)(d/dx)(Psi/Cos)        *
!                               -(d/dx)(2x(Psi/Cos))                 *
!                              +((1-m^2)/(1-x^2))(Psi/Cos)           *
!     m=2,4,6,8... : Vor/Cos^2=  (d/dx)(1-x^2)(d/dx)(Psi/Cos)        *
!                               -(d/dx)(4x(Psi/Cos)) -2 Psi          *
!                              +((4-m^2)/(1-x^2))(Psi/Cos)           *
!                                                                    *
!                             III_m= ( 0 or 2 or 4 ) /2              *
!                                                                    *
!*********************************************************************
!                                                                    *
!     Spectral(x)-Galerkin(y) method                                 *
!                                                                    *
!     27 OCT 2012 : Coded and tested                                 *
!                                                                    *
!                 1) SWE simulation : 10^(-10) mass error            *
!                 2) Gaussian bell : wave-one noise                  *
!                                                                    *
!                   Seems like that '1/COSlat' does harms !          *
!                                                                    *
!     05 JUL 2014 : extended to m=2,4,6,...                          *
!                                                                    *
!*********************************************************************
!                                                                    *
!     Matrices for Laplacian of PSI                                  *
!                                                                    *
!*********************************************************************

      SUBROUTINE MAT200E_JS2_FEM
!--------------------------------------------------------------------C
      use parameter_pi
      USE parameter_dsize
      USE parameter_fsize
      use parameter_sin_power_o_e
      use common_highorder_filter_sphere
      use common_legendre_m0
      use common_Z_GW_SZ2
      use common_reduced_grid
        implicit none
!-----local variable-------------------------------------------------C
      real(kind=8),dimension(0:MT,3,0:JLH) :: YMATD
      real(kind=8) :: rat
      integer      :: js,jsmo,jcol,jcoljsm,mx,j,k,i,mc,mc1
      integer      :: jbeg, N9=Ngrid
      real(kind=8) :: mx2, thkp1,thk,thkm1
!--------------------------------------------------------------------C
!     real(kind=8) :: rthetam(0:JBW), DELtheta(0:JBW)  ! moved to Common
      real(kind=8) :: del
      real(kind=8) :: alat, crit
      real(kind=8) :: xa, xb, c1,c2,c3,c4, d1,d2,d3,d4, h1, h3
      real(kind=8) :: sum1, sum2
      real(kind=8) :: III_m, III_ms
      real(kind=8) :: I_2nd_1_x2_GQ
!--------------------------------------------------------------------C
!-----
      do mx=-MT,MT
         MSQUAR(mx)=  dfloat(mx)**2.d0
      end do
!-----
!
!---- grid interval

      do j=0,JBW  ! full-grid
         rthetam(j) = -PI/2.d0 + (j)*PI/dfloat(JBW)
         rthetam(j) =  DSIN( rthetam(j) )
      enddo

      do j=1,JBW  ! full
         DELtheta(j)= rthetam(j)-rthetam(j-1)
!       write(*,*) rthetam(j-1), DELtheta(j), j
      enddo

!---- grid interval

!----
      CALL gausleg( -1.d0, 1.d0, Z, GW, N9 )
      CALL LEGENDRE_Qpnm_Spnm_m0
!----

!---- reduced grid for m>2

                jlat(: )=  0 ! beginning point of non-zero matrix
      DO mx=2,MT
            crit= 10.d0 ** ( -20.d0/mx )

         do j=JBW/2-4,1,-1  ! at least 3X3 mat
            alat= (JBW/2-j)*( PI/JBW )        
            if( DCOS(alat) < crit ) then
!               jlat(-mx)= j  ! beginning point of zero-matrix to N(S) pole
!               jlat(+mx)= j  ! beginning point of zero-matrix to N(S) pole
                goto 110 
            endif
         end do ! j=

  110 continue

!     print *, 'jlat= 0 : N S pole '
!     print *, 'jlat(mx) =', jlat(mx), mx

      END do ! mx=
!----
!*************************************************
!BEG  MATRIECS for LAPLACIAN OPERATOR            *
!*************************************************
!
         DMATm(: ,:,:,:)= 0.d0
         AMATm(: ,:,:,:)= 0.d0

         DMATm(: ,:,:,1)= 0.d0
         DMATm(: ,2,:,1)= 1.d0  ! diag
         DMATm(: ,2,0,1)= 0.d0
         DMATm(: ,1,0,1)= 1.d0  ! diag

         AMATm(: ,:,:,1)= 0.d0
         AMATm(: ,2,:,1)= 1.d0  ! diag
         AMATm(: ,2,0,1)= 0.d0
         AMATm(: ,1,0,1)= 1.d0  ! diag

      DO mx=0,MT

         if( mod(mx,2)==0 ) then

              if(mx==0) III_m = 0.d0
              if(mx/=0) III_m = 2.d0
         else
                        III_m = 1.d0
         endif
                        III_ms= III_m ** 2.d0
!---
           jbeg= jlat(mx)+1  ! (jbeg>0) is necessary
!************
      do j=1,JLH
!************
                   thkp1= rthetam(j+1)
                   thk  = rthetam(j  )
                   thkm1= rthetam(j-1)

       h1= (  thk  **3.d0 /3 - thkm1**3.d0 /3 - DELtheta(j  ) )         &
            /  DELtheta(j  )**2.d0
       h3= (  thkp1**3.d0 /3 - thk  **3.d0 /3 - DELtheta(j+1) )         &
            /  DELtheta(j+1)**2.d0

       c1= (  thk  **3.d0 /3 - thkm1**3.d0 /3                           &
          -( thk  **2.d0 /2 - thkm1**2.d0 /2 ) * thkm1 ) * 2 * III_m    &
            /  DELtheta(j  )**2.d0
       c2= (  thk  **3.d0 /3 - thkm1**3.d0 /3                           &
          -( thk  **2.d0 /2 - thkm1**2.d0 /2 ) * thk   ) * 2 * III_m    &
            /  DELtheta(j  )**2.d0
       c3= (  thkp1**3.d0 /3 - thk  **3.d0 /3                           &
          -( thkp1**2.d0 /2 - thk  **2.d0 /2 ) * thkp1 ) * 2 * III_m    &
            /  DELtheta(j+1)**2.d0
       c4= (  thkp1**3.d0 /3 - thk  **3.d0 /3                           &
          -( thkp1**2.d0 /2 - thk  **2.d0 /2 ) * thk   ) * 2 * III_m    &
            /  DELtheta(j+1)**2.d0

         DMATm(mx,1,j,1)=                                               &
!    &    - ( 1 - MSQUAR(mx) ) *                                        
          - ( III_ms - MSQUAR(mx) ) *                                   &
             I_2nd_1_x2_GQ( N9, Z, GW, thkm1, thk  , thkm1, thk   )     &
                           / DELtheta(j  )**2.d0                        &
          - h1 - c2

         DMATm(mx,2,j,1)=                                               &
!    &    + ( 1 - MSQUAR(mx) ) * (
         + ( III_ms - MSQUAR(mx) ) * (                                  &
           + I_2nd_1_x2_GQ( N9, Z, GW, thkm1, thk  , thkm1, thkm1 )     &
                           / DELtheta(j  )**2.d0                        &
           + I_2nd_1_x2_GQ( N9, Z, GW, thk  , thkp1, thkp1, thkp1 )     &
                           / DELtheta(j+1)**2.d0 )                      &
          + h1 + h3 + c1 + c3

         DMATm(mx,3,j,1)=                                               &
!    &    - ( 1 - MSQUAR(mx) ) *                           
          - ( III_ms - MSQUAR(mx) ) *                                   &
              I_2nd_1_x2_GQ( N9, Z, GW, thk  , thkp1, thkp1, thk   )    &
                            / DELtheta(j+1)**2.d0                       &
          - h3 - c4

         AMATm(mx,1,j,1)=   DELtheta(j  ) * 1 / 6.d0
         AMATm(mx,2,j,1)=   DELtheta(j  ) * 2 / 6.d0                    &
                          + DELtheta(j+1) * 2 / 6.d0
         AMATm(mx,3,j,1)=   DELtheta(j+1) * 1 / 6.d0
!
      end do ! j=jbeg,JLH

!*************
         j= 0000  ! BC modification
!*************

       if(mx>2) then

         j= 1

         AMATm(mx,1,j,1)=   0.d0
         DMATm(mx,1,j,1)=   0.d0

       elseif(mx<=2) then

         j= 0
                   thkp1= rthetam(j+1)
                   thk  = rthetam(j  )

          h3= ( thkp1**3.d0 /3 - thk  **3.d0 /3 - DELtheta(j+1) )       &
             / DELtheta(j+1)**2.d0

          c3= (  thkp1**3.d0 /3 - thk  **3.d0 /3                        &
             -( thkp1**2.d0 /2 - thk  **2.d0 /2 ) * thkp1 ) * 2 * III_m &
             /  DELtheta(j+1)**2.d0
          c4= (  thkp1**3.d0 /3 - thk  **3.d0 /3                        &
             -( thkp1**2.d0 /2 - thk  **2.d0 /2 ) * thk   ) * 2 * III_m &
             /  DELtheta(j+1)**2.d0

         DMATm(mx,1,j,1)=  h3 + c3

         DMATm(mx,1,j,1)=   DMATm(mx,1,j,1) - 2.d0 * III_m

         DMATm(mx,2,j,1)= -h3 - c4

         AMATm(mx,1,j,1)=   DELtheta(j+1) * 2 / 6.d0
         AMATm(mx,2,j,1)=   DELtheta(j+1) * 1 / 6.d0

       endif
!
      END DO ! mx=0,MT
!---                       MATm_type_III
      do mx=2,MT,2
         DMATm(mx,:,:,1)= DMATm(mx,:,:,1) - 2 * AMATm(mx,:,:,1)
      end do
!---                       MATm_type_III
!
!----   js= 2 for NS Symmetric 

         DMATm(: ,:,:,2)= DMATm(: ,:,:,1)
         AMATm(: ,:,:,2)= AMATm(: ,:,:,1)

         j= JLH
         DMATm(: ,1,j,2)= DMATm(: ,1,j,2) + DMATm(: ,3,j,2)  ! by symmetry across EQ.
         DMATm(: ,3,j,2)= 0.d0

         AMATm(: ,1,j,2)= AMATm(: ,1,j,2) + AMATm(: ,3,j,2) 
         AMATm(: ,3,j,2)= 0.d0

!----   js= 1 for NS AntiSymmetric 

         j= JLH
         DMATm(: ,:,j,1)= 0.d0
         DMATm(: ,2,j,1)= 1.d0 ! for matrix inversion
         DMATm(: ,3,j,1)= 0.d0

         AMATm(: ,:,j,1)= 0.d0
         AMATm(: ,2,j,1)= 1.d0 ! for matrix inversion
         AMATm(: ,3,j,1)= 0.d0

         j= JLH-1
         DMATm(: ,3,j,1)= 0.d0
         AMATm(: ,3,j,1)= 0.d0
!
!*************************************************
!END  MATRIECS for LAPLACIAN OPERATOR            *
!*************************************************
!
!*************************************************
!BEG  Time saving, prehandling of the MATRIX     *
!*************************************************

!---- AMAT * Vorticity = DMAT * streamfunction
!
!beg-------------------------------------------------- DMAT -> DMAT_
!
!                12......                12......     
!                123.....                .12.....
!        DMATx   .123....       DMATx_   ..12....
!                ........                ...12...
!                .....123                ........
!                ......12                ......12
!
!-----------------------------------------------------
      DO js=1,2

            YMATD( 0:MT,:,0:JLH )= DMATm( 0:MT,:,0:JLH ,js)

      do mc=0,JLH-1                    
         mc1= mc+1
       Do mx=0,MT

         rat= YMATD( mx,1,mc1) / YMATD( mx,1,mc)

!next-sub   YMAT(mc )= YMAT(mc )*rat   
            YMATD( mx,2,mc1)= YMATD( mx,2,mc1)-YMATD( mx,2,mc )*rat    
!next-sub   YMAT(mc1)= YMAT(mc1)-YMAT(mc )
            YMATD( mx,1,mc1)= YMATD( mx,2,mc1)
            YMATD( mx,2,mc1)= YMATD( mx,3,mc1)

            DMATm_( mx,1,mc ,js)= 1.d0/YMATD( mx,1,mc ) !! (1/*)

            DMATm_( mx,2,mc ,js)=      YMATD( mx,2,mc )
            DMATm_( mx,3,mc ,js)= rat
       END Do ! par
      end do ! mc=0,JLH-1

       Do mx=0,MT
            DMATm_( mx,1,JLH,js)= 1.d0/YMATD( mx,1,JLH) !! (1/*)
       END Do ! par

      END DO ! js=1,2
!
!end-------------------------------------------------- DMAT -> DMAT_


!beg-------------------------------------------------- AMAT -> AMAT_

      DO js=1,2

            YMATD( 0:MT,:,0:JLH )= AMATm( 0:MT,:,0:JLH ,js)

      do mc=0,JLH-1                    
         mc1= mc+1
       Do mx=0,MT

         rat= YMATD( mx,1,mc1) / YMATD( mx,1,mc)

!next-sub   YMAT(mc )= YMAT(mc )*rat   
            YMATD( mx,2,mc1)= YMATD( mx,2,mc1)-YMATD( mx,2,mc )*rat    
!next-sub   YMAT(mc1)= YMAT(mc1)-YMAT(mc )
            YMATD( mx,1,mc1)= YMATD( mx,2,mc1)
            YMATD( mx,2,mc1)= YMATD( mx,3,mc1)

            AMATm_( mx,1,mc ,js)= 1.d0/YMATD( mx,1,mc ) !! (1/*)

            AMATm_( mx,2,mc ,js)=      YMATD( mx,2,mc )
            AMATm_( mx,3,mc ,js)= rat
       END Do ! par
      end do ! mc

       Do mx=0,MT
            AMATm_( mx,1,JLH,js)= 1.d0/YMATD( mx,1,JLH) !! (1/*)
       END Do ! par

      END DO ! js=1,2
!
!end-------------------------------------------------- AMAT -> AMAT_

!*************************************************
!END  Time saving, prehandling of the MATRIX     *
!*************************************************
!
!--------------------------------------------------------------------C
      END SUBROUTINE MAT200E_JS2_FEM
!*********************************************************************
!
!23456789012345678901234567890123456789012345678901234567890123456789012
!*********************************************************************
!                                                                    *
!     Spectral(x)-Galerkin(y) method                                 *
!                                                                    *
!     MATs for Helmholtz equation                                    *
!                                                                    *
!       LAPLACIAN operator in x(=sinLat) coordinate                  *
!                                                                    *
!     See Comments for SUBROUTINE MAT200S_JS2_FEM                    *
!                                                                    *
!     18 NOV 2012 : DMATmi_ moved to common_module                   *
!                                                                    *
!*********************************************************************
!     SUBROUTINE MAT200S_JS2_FEM( alpha, DMATmi_ )
      SUBROUTINE MAT200S_JS2_FEM( alpha )
!--------------------------------------------------------------------C
      use parameter_pi
      USE parameter_dsize
      USE parameter_fsize
      use common_highorder_filter_sphere
        implicit none
!--------------------------------------------------------------------C
      real(kind=8), intent(in ) :: alpha
!     real(kind=8), intent(out) :: DMATmi_(0:MT,3,0:JLH,2)
!-----local variable-------------------------------------------------C
      real(kind=8) :: YMATD(0:MT,3,0:JLH)
      real(kind=8) :: rat
      integer      :: js,jsmo,jcol,jcoljsm,mx,j,k,i,mc,mc1
      integer      :: jbeg
      real(kind=8) :: mx2, thkp1,thk,thkm1
!--------------------------------------------------------------------C
!
      if(alpha.eq.0.d0) stop 'The alpha is zero: SUB MAT200S_JS2_FEM'
!
!----
!*************************************************
!BEG  MATRIECS for LAPLACIAN OPERATOR            *
!*************************************************
!
      do j=0,JLH      
         DMATmi_(:,:,j,:)= AMATm(:,:,j,:) + alpha * DMATm(:,:,j,:)
      end do
!
!*************************************************
!END  MATRIECS for LAPLACIAN OPERATOR            *
!*************************************************
!
!*************************************************
!BEG  Time saving, prehandling of the MATRIX     *
!*************************************************

!beg-------------------------------------------------- DMATmi_

      DO js=1,2

         do mc=1,JLH-1
          Do mx=0,MT
            YMATD( mx,1,mc)= DMATmi_(mx,1,mc,js)
            YMATD( mx,2,mc)= DMATmi_(mx,2,mc,js) 
            YMATD( mx,3,mc)= DMATmi_(mx,3,mc,js)
          END Do
         end do
            mc=0
          Do mx=0,MT
            YMATD( mx,1,mc)= DMATmi_(mx,1,mc,js)
            YMATD( mx,2,mc)= DMATmi_(mx,2,mc,js)
          END Do
            mc=JLH 
          Do mx=0,MT
            YMATD( mx,1,mc)= DMATmi_(mx,1,mc,js)
            YMATD( mx,2,mc)= DMATmi_(mx,2,mc,js)
          END Do

      do mc=0,JLH-1                    
         mc1= mc+1
       Do mx=0,MT

         rat= YMATD( mx,1,mc1) / YMATD( mx,1,mc)

!next-sub   YMAT(mc )= YMAT(mc )*rat   
            YMATD( mx,2,mc1)= YMATD( mx,2,mc1)-YMATD( mx,2,mc )*rat    
!next-sub   YMAT(mc1)= YMAT(mc1)-YMAT(mc )
            YMATD( mx,1,mc1)= YMATD( mx,2,mc1)
            YMATD( mx,2,mc1)= YMATD( mx,3,mc1)

            DMATmi_( mx,1,mc ,js)= 1.d0/YMATD( mx,1,mc ) !! (1/*)

            DMATmi_( mx,2,mc ,js)=      YMATD( mx,2,mc )
            DMATmi_( mx,3,mc ,js)= rat
       END Do ! par
      end do ! mc=0,JLH-1

       Do mx=0,MT
            DMATmi_( mx,1,JLH,js)= 1.d0/YMATD( mx,1,JLH) !! (1/*)
       END Do ! par

      END DO ! js=1,2
!
!end-------------------------------------------------- DMATmi_
!
!*************************************************
!BEG  Time saving, prehandling of the MATRIX     *
!*************************************************

!--------------------------------------------------------------------C
      END SUBROUTINE MAT200S_JS2_FEM
!*********************************************************************
!
!*********************************************************************
!                                                                    *
!     Spectral(x)-Galerkin(y) method                                 *
!                                                                    *
!     Laplacian of X = Y , Inverse Laplacian of Y = X                *
!     on the Spherical Domain including the Poles                    *
!                                                                    *
!       LAPLACIAN operator in x(=sinLat) coordinate                  *
!                                                                    *
!                             +((1-m^2)/(1-x^2))(Psi/Cos)            *
!     m=0          : Vor     =   (d/dx)(1-x^2)(d/dx) Psi             *
!                              +(( -m^2)/(1-x^2)) Psi                *
!     m=1,3,5,7... : Vor/Cos =   (d/dx)(1-x^2)(d/dx)(Psi/Cos)        *
!                               -(d/dx)(2x(Psi/Cos))                 *
!                              +((1-m^2)/(1-x^2))(Psi/Cos)           *
!     m=2,4,6,8... : Vor/Cos^2=  (d/dx)(1-x^2)(d/dx)(Psi/Cos)        *
!                               -(d/dx)(4x(Psi/Cos)) -2 Psi          *
!                              +((4-m^2)/(1-x^2))(Psi/Cos)           *
!                                                                    *
!                             III_m= ( 0 or 2 or 4 ) /2              *
!                                                                    *
!*********************************************************************
!                                     MSEL=0 : Laplacian TC1 -> AJX   
!                                          1 : Inverse                
!--------------------------------------------------------------------C
      SUBROUTINE LAP200E_JS2_FEM ( TC1psi, AJXzeta , MSEL )
!--------------------------------------------------------------------C
      use parameter_pi
      USE parameter_dsize
      USE parameter_fsize
      use common_highorder_filter_sphere
      use common_legendre_m0
      use common_Z_GW_SZ2
      use common_reduced_grid
      use common_enm1_CosSinLat
        implicit none
!--------------------------------------------------------------------C
      real(kind=8) :: TC1psi(-MT:MT,0:JBW), AJXzeta(-MT:MT,0:JBW)
      integer, intent(in) :: MSEL
!-----local variable-------------------------------------------------C
      real(kind=8) :: a4,a5,a6,ace,aaa,XMAT0
      integer      :: js,jcol,jja,jjb,jjc,mx,imx,mc,mc1,mco,mcop1,jjj
!--------------------------------------------------------------------C
      real(kind=8) :: TC1(-MT:MT,0:JLH,2), AJX(-MT:MT,0:JLH,2)
      real(kind=8), dimension(0:JBW) :: WORK_m0, coef_cos_m0, coef_Pn0
      real(kind=8), dimension(0:JBW) ::          coef_cos_m1
      real(kind=8), dimension(0:JBW) ::          coef_cos_m2
!--------------------------------------------------------------------C
      real(kind=8) :: sum1
      real(kind=8) :: sum2, dif_pole(-2:2,0:1)
      integer      :: j, mj, k, n
!--------------------------------------------------------------------C
      real(kind=8) :: unm(-MT:MT,0:JBW), vnm(-MT:MT,0:JBW)
!--------------------------------------------------------------------C
!     JL=JBW, JLH=JB

!--------------------------------------------------------------------C
          IF(MSEL.eq.0) THEN           ! Laplacian of TC1 = AJX
!--------------------------------------------------------------------C
!
!     CALL PSI_to_uv_FEM ( TC1psi, unm, vnm )
!     CALL uv_to_vor_FEM ( unm, vnm, AJXzeta )
!
!     CALL GLOBAL0_FEM_1D( AJXzeta(0,:), JBW, XMAT0, +1 )
!
!     return
!
!-b--- (Psi/Cos) at pole m=1, (Psi/Cos^2) m=2 : MATm_type_III

      DO mx=-1,1,2

!-a1- grid -> sin wave

      DO mj=0,JBW
         sum1=0.d0
      do j=1,JBW-1
         sum1= sum1 + TC1psi(mx,j)* DSIN( PI*j*mj/dfloat(JBW) )  ! mx=1 : SIN(k phi)
      enddo ! j
         coef_cos_m0(mj)= sum1/dfloat(JB )
      ENDDO ! mj=

!-a2- cos wave -> dif

         sum1= 0.d0 ; sum2= 0.d0
      DO mj=0,JBW
         sum1= sum1 + coef_cos_m0(mj) * ( mj)                   ! 90S
         sum2= sum2 - coef_cos_m0(mj) * ( mj) * (1-2*mod(mj,2)) ! 90N 
      ENDDO ! mj=
         dif_pole(mx,0)= sum1
         dif_pole(mx,1)= sum2

      ENDDO ! mx=
!-----
      DO mx=-2,2,4

      DO mj=0,JBW

         sum1=0.d0
      do j=1,JBW-1
         sum1= sum1 + TC1psi(mx,j)* DCOS( PI*j*mj/dfloat(JBW) )  ! mx=1 : SIN(k phi)
      enddo ! j
         sum1= sum1 + ( TC1psi(mx,0) + (1-2*mod(mj,2)) * TC1psi(mx,JBW) &
                       ) / 2.d0
       if(mj==0 .or. mj==JBW) sum1= sum1 / 2.d0
         coef_cos_m2(mj)= sum1/dfloat(JB )

      ENDDO ! mj=
!---
         sum1= 0.d0 ; sum2= 0.d0
      DO mj=0,JBW
         sum1= sum1 + coef_cos_m2(mj) * (-mj**2)                   ! 90S
         sum2= sum2 + coef_cos_m2(mj) * (-mj**2) * (1-2*mod(mj,2)) ! 90N 
      ENDDO ! mj=
         dif_pole(mx,0)= sum1 / 2
         dif_pole(mx,1)= sum2 / 2

      ENDDO ! mx=

!-e--- (Psi/Cos) at pole m=1, (Psi/Cos^2) m=2 : MATm_type_III

!-b- Symmetric and AntiSymmetric component : MATm_type_III

         TC1(:,:,:)=   0.d0

      do j=1,JLH
      do mx=-MT,MT

        if( mod(mx,2)==0 .and. mx==0 ) then

         TC1(mx,j,1)= ( TC1psi(mx,j) - TC1psi(mx,JBW-j) )/2.d0  ! asym
         TC1(mx,j,2)= ( TC1psi(mx,j) + TC1psi(mx,JBW-j) )/2.d0  ! sym

        elseif( mod(mx,2)==0 .and. mx/=0 ) then

         TC1(mx,j,1)= ( TC1psi(mx,j) - TC1psi(mx,JBW-j) )/2.d0          & ! asym
                     / COSLAT0(j-JB,2)
         TC1(mx,j,2)= ( TC1psi(mx,j) + TC1psi(mx,JBW-j) )/2.d0          & ! sym
                     / COSLAT0(j-JB,2)
        else

         TC1(mx,j,1)= ( TC1psi(mx,j) - TC1psi(mx,JBW-j) )/2.d0          & ! asym  
                     / COSLAT0(j-JB,1)
         TC1(mx,j,2)= ( TC1psi(mx,j) + TC1psi(mx,JBW-j) )/2.d0          &  ! sym
                     / COSLAT0(j-JB,1)
        endif

      end do
      end do

         j=0
      do mx=-2,2
        if(mx==0) then
         TC1(mx,j,1)= ( TC1psi(mx,j) - TC1psi(mx,JBW-j) )/2.d0  ! asym
         TC1(mx,j,2)= ( TC1psi(mx,j) + TC1psi(mx,JBW-j) )/2.d0  ! sym
        else
         TC1(mx,j,1)= ( dif_pole(mx,0) - dif_pole(mx,1) )/2.d0  ! asym
         TC1(mx,j,2)= ( dif_pole(mx,0) + dif_pole(mx,1) )/2.d0  !  sym
        endif
      end do

!-e- Symmetric and AntiSymmetric component : MATm_type_III

         AJX(:,:,:)= 0.d0 

      DO js=1,2

!---- 1  To get YMAT, YMAT= DMAT*TC1

         do jcol=1,JLH-1
            jja= jcol-1
            jjb= jcol
            jjc= jcol+1
          Do mx=-MT,MT
            imx=iabs(mx)
             a4= DMATm(imx,1,jcol,js)
             a5= DMATm(imx,2,jcol,js)
             a6= DMATm(imx,3,jcol,js)
             ace=( a5 )*TC1(mx,jjb,js)
            YMAT(mx,jcol)= a4*TC1(mx,jja,js) + ace + a6*TC1(mx,jjc,js)
          END Do ! par
         end do

            jcol=0
            jjb= jcol
            jjc= jcol+1
          Do mx=-MT,MT
            imx=iabs(mx) 
             a4= DMATm(imx,1,jcol,js)
             a5= DMATm(imx,2,jcol,js)
            YMAT(mx,jcol)=( a4 )*TC1(mx,jjb,js)+a5*TC1(mx,jjc,js)
          END Do ! par

            jcol=JLH 
            jja= jcol-1
            jjb= jcol
          Do mx=-MT,MT
            imx=iabs(mx)
             a4= DMATm(imx,1,jcol,js)
             a5= DMATm(imx,2,jcol,js)
            YMAT(mx,jcol)= a4*TC1(mx,jja,js)+( a5 )*TC1(mx,jjb,js)
          END Do ! par

!---- 2  To get ZETA, AMAT*ZETA= YMAT

         do mc=0,JLH-1
            mc1= mc+1
          Do mx=-MT,MT
            imx=iabs(mx)
            YMAT(mx,mc1)= YMAT(mx,mc1)-YMAT(mx,mc )*AMATm_(imx,3,mc,js)
          END Do ! par
         end do

          Do mx=-MT,MT
            imx=iabs(mx) 
            YMAT(mx,JLH)=  YMAT(mx,JLH) * AMATm_(imx,1,JLH,js) !! (1/*)
          END Do ! par

         do mco=JLH-1,0,-1
            mcop1=mco+1
          Do mx=-MT,MT
            imx=iabs(mx)
                 aaa =  YMAT(mx,mcop1)*AMATm_(imx,2,mco,js)
            YMAT(mx,mco)= (YMAT(mx,mco)-aaa) * AMATm_(imx,1,mco,js)
          END Do ! par
         end do

         do jcol=0,JLH
            jjj= jcol
          Do mx=-MT,MT
            AJX(mx,jjj,js)= YMAT(mx,jcol)
          END Do ! par
         end do

      END DO ! js=1,2

!-----
      do mx=3,MT
         AJX(-mx,0,:)= 0.d0  ! Sym and Asym at poles = 0 : mx > 2 : type_III
         AJX(+mx,0,:)= 0.d0
      end do

!-b- Symmetric and AntiSymmetric component : MAT_type_III

      do j=0,JLH
      do mx=-MT,MT           ! code structure to be modified

      if(mod(mx,2)==0) then  ! MAT_type_III

          if(mx==0) then
         AJXzeta(mx,JBW-j)= ( AJX(mx,j,2) - AJX(mx,j,1) )
         AJXzeta(mx,    j)= ( AJX(mx,j,2) + AJX(mx,j,1) )
          else
         AJXzeta(mx,JBW-j)= ( AJX(mx,j,2) - AJX(mx,j,1) )               &
                           * COSLAT0(j-JB,2)
         AJXzeta(mx,    j)= ( AJX(mx,j,2) + AJX(mx,j,1) )               &
                           * COSLAT0(j-JB,2)
          endif

      else
         AJXzeta(mx,JBW-j)= ( AJX(mx,j,2) - AJX(mx,j,1) )               &
                           * COSLAT0(j-JB,1)
         AJXzeta(mx,    j)= ( AJX(mx,j,2) + AJX(mx,j,1) )               &
                           * COSLAT0(j-JB,1)
      endif

      end do
      end do ! mj=

!-e- Symmetric and AntiSymmetric component : MAT_type_III

      CALL GLOBAL0_FEM_1D( AJXzeta(0,:), JBW, XMAT0, +1 )  ! Glomean of AJX(vor) = 0

!--------------------------------------------------------------------C
      ELSEIF(MSEL.eq.1) THEN           ! Inverse Laplacian of AJX= TC1
!--------------------------------------------------------------------C

      CALL GLOBAL0_FEM_1D( AJXzeta(0,:), JBW, XMAT0, +1 )

!-b--- (Vor/Cos) at pole m=1, (Vor/Cos^2) m=2 : MATm_type_III

      DO mx=-1,1,2

!-a1- grid -> sin wave

      DO mj=0,JBW
         sum1=0.d0
      do j=1,JBW-1
         sum1= sum1 + AJXzeta(mx,j)* DSIN( PI*j*mj/dfloat(JBW) )  ! mx=1 : SIN(k phi)
      enddo ! j
         coef_cos_m0(mj)= sum1/dfloat(JB )
      ENDDO ! mj=

!-a2- cos wave -> dif

         sum1= 0.d0 ; sum2= 0.d0
      DO mj=0,JBW
         sum1= sum1 + coef_cos_m0(mj) * ( mj)                   ! 90S
         sum2= sum2 - coef_cos_m0(mj) * ( mj) * (1-2*mod(mj,2)) ! 90N 
      ENDDO ! mj=
         dif_pole(mx,0)= sum1
         dif_pole(mx,1)= sum2

      ENDDO ! mx=
!-----
      DO mx=-2,2,4

      DO mj=0,JBW

         sum1=0.d0
      do j=1,JBW-1
         sum1= sum1 + AJXzeta(mx,j)* DCOS( PI*j*mj/dfloat(JBW) )  ! mx=1 : SIN(k phi)
      enddo ! j
         sum1= sum1 + ( AJXzeta(mx,0) + (1-2*mod(mj,2))* AJXzeta(mx,JBW)&
                       ) / 2.d0
       if(mj==0 .or. mj==JBW) sum1= sum1 / 2.d0
         coef_cos_m2(mj)= sum1/dfloat(JB )

      ENDDO ! mj=
!---
         sum1= 0.d0 ; sum2= 0.d0
      DO mj=0,JBW
         sum1= sum1 + coef_cos_m2(mj) * (-mj**2)                   ! 90S
         sum2= sum2 + coef_cos_m2(mj) * (-mj**2) * (1-2*mod(mj,2)) ! 90N 
      ENDDO ! mj=
         dif_pole(mx,0)= sum1 / 2
         dif_pole(mx,1)= sum2 / 2

      ENDDO ! mx=

!-e--- (Vor/Cos) at pole m=1, (Vor/Cos^2) m=2 : MATm_type_III

!-b- Symmetric and AntiSymmetric component : MATm_type_III

         AJX(:,:,:)=   0.d0

      do j=1,JLH
      do mx=-MT,MT

        if( mod(mx,2)==0 .and. mx==0 ) then

         AJX(mx,j,1)= ( AJXzeta(mx,j) - AJXzeta(mx,JBW-j) )/2.d0  ! asym
         AJX(mx,j,2)= ( AJXzeta(mx,j) + AJXzeta(mx,JBW-j) )/2.d0  ! sym

        elseif( mod(mx,2)==0 .and. mx/=0 ) then

         AJX(mx,j,1)= ( AJXzeta(mx,j) - AJXzeta(mx,JBW-j) )/2.d0        & ! asym
                    / COSLAT0(j-JB,2)
         AJX(mx,j,2)= ( AJXzeta(mx,j) + AJXzeta(mx,JBW-j) )/2.d0        & ! sym
                    / COSLAT0(j-JB,2)
        else

         AJX(mx,j,1)= ( AJXzeta(mx,j) - AJXzeta(mx,JBW-j) )/2.d0        & ! asym
                     / COSLAT0(j-JB,1)
         AJX(mx,j,2)= ( AJXzeta(mx,j) + AJXzeta(mx,JBW-j) )/2.d0        & ! sym
                     / COSLAT0(j-JB,1)
        endif

      end do
      end do

         j=0
      do mx=-2,2
        if(mx==0) then
         AJX(mx,j,1)= ( AJXzeta(mx,j) - AJXzeta(mx,JBW-j) )/2.d0  ! asym
         AJX(mx,j,2)= ( AJXzeta(mx,j) + AJXzeta(mx,JBW-j) )/2.d0  ! sym
        else
         AJX(mx,j,1)= ( dif_pole(mx,0) - dif_pole(mx,1) )/2.d0  ! asym
         AJX(mx,j,2)= ( dif_pole(mx,0) + dif_pole(mx,1) )/2.d0  !  sym
        endif
      end do

!-e- Symmetric and AntiSymmetric component : MATm_type_III

         TC1(:,:,:)= 0.d0 

      DO js=1,2

!---- 1  To get YMAT, YMAT= AMAT*ZETA

         do jcol=1,JLH-1
            jja=  jcol-1
            jjb=  jcol
            jjc=  jcol+1
          Do mx=-MT,MT
            imx=iabs(mx)
             a4= AMATm(imx,1,jcol,js)
             a5= AMATm(imx,2,jcol,js)
             a6= AMATm(imx,3,jcol,js)
             aaa = a5*AJX(mx,jjb,js)
            YMAT(mx,jcol)= a4*AJX(mx,jja,js)+ aaa +a6*AJX(mx,jjc,js)
          END Do ! par
         end do

            jcol=0
            jjb= jcol
            jjc= jcol+1
          Do mx=-MT,MT
            imx=iabs(mx)
             a4= AMATm(imx,1,jcol,js)
             a5= AMATm(imx,2,jcol,js)
            YMAT(mx,jcol)= a4*AJX(mx,jjb,js)+a5*AJX(mx,jjc,js)
          END Do ! par

            jcol=JLH
            jja= jcol-1
            jjb= jcol
          Do mx=-MT,MT
            imx=iabs(mx)
             a4= AMATm(imx,1,jcol,js)
             a5= AMATm(imx,2,jcol,js)
            YMAT(mx,jcol)= a4*AJX(mx,jja,js)+a5*AJX(mx,jjb,js)
          END Do ! par

!---- 2  To get PSI, DMAT*PSI= YMAT

         do mc=0,JLH-1
            mc1= mc+1
          Do mx=-MT,MT
            imx=iabs(mx)
            YMAT(mx,mc1)= YMAT(mx,mc1)-YMAT(mx,mc )*DMATm_(imx,3,mc,js)
          END Do ! par
         end do

          Do mx=-MT,MT
            imx=iabs(mx)
            YMAT(mx,JLH)=  YMAT(mx,JLH) * DMATm_(imx,1,JLH,js) !! (1/*)
          END Do ! par

         do mco=JLH-1,0,-1
            mcop1=mco+1
          Do mx=-MT,MT
            imx=iabs(mx)
                 aaa =  YMAT(mx,mcop1)*DMATm_(imx,2,mco,js)
            YMAT(mx,mco)= (YMAT(mx,mco)-aaa) * DMATm_(imx,1,mco,js)
          END Do ! par
         end do

         do jcol=0,JLH
            jjj= jcol
          Do mx=-MT,MT
            TC1(mx,jjj,js)= YMAT(mx,jcol)
          END Do ! par
         end do

      END DO ! js=1,2

!-----
      do mx=3,MT
         TC1(-mx,0,:)= 0.d0  ! Sym and Asym at poles = 0 : v-vel, m>0
         TC1(+mx,0,:)= 0.d0  ! 22 OCT 2012               : u/Cos, m=0
      end do
!
!-b- Symmetric and AntiSymmetric component : MAT_type_III

      do j=0,JLH
      do mx=-MT,MT           ! code structure to be modified

      if(mod(mx,2)==0) then  ! MAT_type_III

          if(mx==0) then
         TC1psi(mx,JBW-j)= ( TC1(mx,j,2) - TC1(mx,j,1) )
         TC1psi(mx,    j)= ( TC1(mx,j,2) + TC1(mx,j,1) )
          else
         TC1psi(mx,JBW-j)= ( TC1(mx,j,2) - TC1(mx,j,1) )                &
                           * COSLAT0(j-JB,2)
         TC1psi(mx,    j)= ( TC1(mx,j,2) + TC1(mx,j,1) )                &
                           * COSLAT0(j-JB,2)
          endif

      else
         TC1psi(mx,JBW-j)= ( TC1(mx,j,2) - TC1(mx,j,1) )                &
                           * COSLAT0(j-JB,1)
         TC1psi(mx,    j)= ( TC1(mx,j,2) + TC1(mx,j,1) )                &
                           * COSLAT0(j-JB,1)
      endif

      end do
      end do ! mj=
!
!-e- Symmetric and AntiSymmetric component : MAT_type_III

      CALL GLOBAL0_FEM_1D( TC1psi(0,:), JBW, a5, +1 )  ! to make Glomean(R) zero, because
!                                            ! R is O(10^15) after inversion
!--------------------------------------------------------------------C
       ENDIF
!--------------------------------------------------------------------C
!
!--------------------------------------------------------------------C
      END SUBROUTINE LAP200E_JS2_FEM
!*********************************************************************

!*********************************************************************
!                                                                    *
!     Spectral(x)-Galerkin(y) method                                 *
!                                                                    *
!     Inverse : Y + alpha * Laplacian of Y = X                       *
!     on the Spherical Domain including the Poles                    *
!                                                                    *
!       LAPLACIAN operator in x(=sinLat) coordinate                  *
!                                                                    *
!     See comments for LAP200E_JS2_FEM                               *
!                                                                    *
!*********************************************************************
!                                                                    *
!     AJXzeta: in & distroyed & out                                  *
!     AJX    : work array                                            *
!                                                                    *
!*********************************************************************
!                                     MSEL=0 : Laplacian TC1 -> AJX   
!                                          1 : Inverse                
!--------------------------------------------------------------------C
!     SUBROUTINE LAP200S_JS2_FEM ( alpha, DMATmi_, AJXzeta )
      SUBROUTINE LAP200S_JS2_FEM ( alpha, AJXzeta )
!--------------------------------------------------------------------C
      use parameter_pi
      USE parameter_dsize
      USE parameter_fsize
      use common_highorder_filter_sphere
      use common_legendre_m0
      use common_Z_GW_SZ2
      use common_reduced_grid
      use common_enm1_CosSinLat
        implicit none
!--------------------------------------------------------------------C
!     real(kind=8), intent(in   ) :: alpha, DMATmi_(0:MT,3,0:JLH,2)
      real(kind=8), intent(in   ) :: alpha
      real(kind=8), intent(inout) :: AJXzeta(-MT:MT,0:JBW)
!-----local variable-------------------------------------------------C
      real(kind=8) :: a4,a5,a6,ace,aaa,XMAT0
      integer      :: js,jcol,jja,jjb,jjc,mx,imx,mc,mc1,mco,mcop1,jjj
!--------------------------------------------------------------------C
      real(kind=8) :: AJX(-MT:MT,0:JLH,2)
      real(kind=8), dimension(0:JBW) :: WORK_m0, coef_cos_m0, coef_Pn0
      real(kind=8), dimension(0:JBW) ::          coef_cos_m1
      real(kind=8), dimension(0:JBW) ::          coef_cos_m2
!--------------------------------------------------------------------C
      real(kind=8) :: sum1
      real(kind=8) :: sum2, dif_pole(-2:2,0:1)
      integer      :: j, mj, k, n
!--------------------------------------------------------------------C

      CALL GLOBAL0_FEM_1D( AJXzeta(0,:), JBW, XMAT0, +1 )  ! XMAT0 is recovered below

!-b--- (Vor/Cos) at pole m=1, (Vor/Cos^2) m=2 : MATm_type_III

      DO mx=-1,1,2

!-a1- grid -> sin wave

      DO mj=0,JBW
         sum1=0.d0
      do j=1,JBW-1
         sum1= sum1 + AJXzeta(mx,j)* DSIN( PI*j*mj/dfloat(JBW) )  ! mx=1 : SIN(k phi)
      enddo ! j
         coef_cos_m0(mj)= sum1/dfloat(JB )
      ENDDO ! mj=

!-a2- cos wave -> dif

         sum1= 0.d0 ; sum2= 0.d0
      DO mj=0,JBW
         sum1= sum1 + coef_cos_m0(mj) * ( mj)                   ! 90S
         sum2= sum2 - coef_cos_m0(mj) * ( mj) * (1-2*mod(mj,2)) ! 90N 
      ENDDO ! mj=
         dif_pole(mx,0)= sum1
         dif_pole(mx,1)= sum2

      ENDDO ! mx=
!-----
      DO mx=-2,2,4

      DO mj=0,JBW

         sum1=0.d0
      do j=1,JBW-1
         sum1= sum1 + AJXzeta(mx,j)* DCOS( PI*j*mj/dfloat(JBW) )  ! mx=1 : SIN(k phi)
      enddo ! j
         sum1= sum1 + ( AJXzeta(mx,0) + (1-2*mod(mj,2))* AJXzeta(mx,JBW)&
                      ) / 2.d0
       if(mj==0 .or. mj==JBW) sum1= sum1 / 2.d0
         coef_cos_m2(mj)= sum1/dfloat(JB )

      ENDDO ! mj=
!---
         sum1= 0.d0 ; sum2= 0.d0
      DO mj=0,JBW
         sum1= sum1 + coef_cos_m2(mj) * (-mj**2)                   ! 90S
         sum2= sum2 + coef_cos_m2(mj) * (-mj**2) * (1-2*mod(mj,2)) ! 90N 
      ENDDO ! mj=
         dif_pole(mx,0)= sum1 / 2
         dif_pole(mx,1)= sum2 / 2

      ENDDO ! mx=

!-e--- (Vor/Cos) at pole m=1, (Vor/Cos^2) m=2 : MATm_type_III

!-b- Symmetric and AntiSymmetric component : MATm_type_III

         AJX(:,:,:)=   0.d0

      do j=1,JLH
      do mx=-MT,MT

        if( mod(mx,2)==0 .and. mx==0 ) then

         AJX(mx,j,1)= ( AJXzeta(mx,j) - AJXzeta(mx,JBW-j) )/2.d0  ! asym
         AJX(mx,j,2)= ( AJXzeta(mx,j) + AJXzeta(mx,JBW-j) )/2.d0  ! sym

        elseif( mod(mx,2)==0 .and. mx/=0 ) then

         AJX(mx,j,1)= ( AJXzeta(mx,j) - AJXzeta(mx,JBW-j) )/2.d0        & ! asym
                     / COSLAT0(j-JB,2)
         AJX(mx,j,2)= ( AJXzeta(mx,j) + AJXzeta(mx,JBW-j) )/2.d0        & ! sym
                     / COSLAT0(j-JB,2)
        else

         AJX(mx,j,1)= ( AJXzeta(mx,j) - AJXzeta(mx,JBW-j) )/2.d0        & ! asym
                     / COSLAT0(j-JB,1)
         AJX(mx,j,2)= ( AJXzeta(mx,j) + AJXzeta(mx,JBW-j) )/2.d0        & ! sym
                     / COSLAT0(j-JB,1)
        endif

      end do
      end do

         j=0
      do mx=-2,2
        if(mx==0) then
         AJX(mx,j,1)= ( AJXzeta(mx,j) - AJXzeta(mx,JBW-j) )/2.d0  ! asym
         AJX(mx,j,2)= ( AJXzeta(mx,j) + AJXzeta(mx,JBW-j) )/2.d0  ! sym
        else
         AJX(mx,j,1)= ( dif_pole(mx,0) - dif_pole(mx,1) )/2.d0  ! asym
         AJX(mx,j,2)= ( dif_pole(mx,0) + dif_pole(mx,1) )/2.d0  !  sym
        endif
      end do

!-e- Symmetric and AntiSymmetric component : MATm_type_III

      DO js=1,2

!---- 1  To get YMAT, YMAT= AMAT*ZETA

         do jcol=1,JLH-1
            jja=  jcol-1
            jjb=  jcol
            jjc=  jcol+1
          Do mx=-MT,MT
            imx=iabs(mx)
             a4= AMATm(imx,1,jcol,js)
             a5= AMATm(imx,2,jcol,js)
             a6= AMATm(imx,3,jcol,js)
             aaa = a5*AJX(mx,jjb,js)
            YMAT(mx,jcol)= a4*AJX(mx,jja,js)+ aaa +a6*AJX(mx,jjc,js)
          END Do ! par
         end do

            jcol=0
            jjb= jcol
            jjc= jcol+1
          Do mx=-MT,MT
            imx=iabs(mx)
             a4= AMATm(imx,1,jcol,js)
             a5= AMATm(imx,2,jcol,js)
            YMAT(mx,jcol)= a4*AJX(mx,jjb,js)+a5*AJX(mx,jjc,js)
          END Do ! par

            jcol=JLH
            jja= jcol-1
            jjb= jcol
          Do mx=-MT,MT
            imx=iabs(mx)
             a4= AMATm(imx,1,jcol,js)
             a5= AMATm(imx,2,jcol,js)
            YMAT(mx,jcol)= a4*AJX(mx,jja,js)+a5*AJX(mx,jjb,js)
          END Do ! par

!---- 2  To get PSI, DMAT*PSI= YMAT

         do mc=0,JLH-1
            mc1= mc+1
          Do mx=-MT,MT
            imx=iabs(mx)
         YMAT(mx,mc1)= YMAT(mx,mc1) -YMAT(mx,mc )*DMATmi_(imx,3,mc,js)
          END Do ! par
         end do

          Do mx=-MT,MT
            imx=iabs(mx)
            YMAT(mx,JLH)=  YMAT(mx,JLH) * DMATmi_(imx,1,JLH,js) !! (1/*)
          END Do ! par

         do mco=JLH-1,0,-1
            mcop1=mco+1
          Do mx=-MT,MT
            imx=iabs(mx)
                 aaa =  YMAT(mx,mcop1)*DMATmi_(imx,2,mco,js)
            YMAT(mx,mco)= (YMAT(mx,mco)-aaa) * DMATmi_(imx,1,mco,js)
          END Do ! par
         end do

         do jcol=0,JLH
            jjj= jcol
          Do mx=-MT,MT
            AJX(mx,jjj,js)= YMAT(mx,jcol)
          END Do ! par
         end do

      END DO ! js=1,2

!-----
      do mx=3,MT
         AJX(-mx,0,:)= 0.d0  ! Sym and Asym at poles = 0 : v-vel, m>2 : type_III
         AJX(+mx,0,:)= 0.d0  ! 22 OCT 2012               : u/Cos, m=0
      end do

!-b- Symmetric and AntiSymmetric component : MAT_type_III

      do j=0,JLH
      do mx=-MT,MT           ! code structure to be modified

      if(mod(mx,2)==0) then

          if(mx==0) then
         AJXzeta(mx,JBW-j)= ( AJX(mx,j,2) - AJX(mx,j,1) )
         AJXzeta(mx,    j)= ( AJX(mx,j,2) + AJX(mx,j,1) )
          else
         AJXzeta(mx,JBW-j)= ( AJX(mx,j,2) - AJX(mx,j,1) )               &
                          * COSLAT0(j-JB,2)
         AJXzeta(mx,    j)= ( AJX(mx,j,2) + AJX(mx,j,1) )               &
                          * COSLAT0(j-JB,2)
          endif

      else
         AJXzeta(mx,JBW-j)= ( AJX(mx,j,2) - AJX(mx,j,1) )               &
                          * COSLAT0(j-JB,1)
         AJXzeta(mx,    j)= ( AJX(mx,j,2) + AJX(mx,j,1) )               &
                          * COSLAT0(j-JB,1)
      endif

      end do
      end do ! mj=
!
!-e- Symmetric and AntiSymmetric component : MAT_type_III

      CALL GLOBAL0_FEM_1D( AJXzeta(0,:), JBW, a5, +1 )  ! XMAT0 is recovered below

          AJXzeta(0,:)= AJXzeta(0,:) + XMAT0
!
!*********************************************************************
      END SUBROUTINE LAP200S_JS2_FEM
!*********************************************************************

!====================================================================C
      SUBROUTINE LEGENDRE_Qpnm_Spnm_m0
!--------------------------------------------------------------------c
      use parameter_pi
      use parameter_earth
      USE parameter_dsize
      USE parameter_fsize
      use common_legendre_m0
!--------------------------------------------------------------------c
       implicit none
       integer :: n,m,k
!--------------------------------------------------------------------c

!------ Double factorials

          dfact(0)= 1.d0
          dfact(1)= 1.d0
         do n=2,2*JBW,2
            dfact(n  )= dfact(n-2)* dfloat(n-1)/dfloat(n  )
            dfact(n+1)= dfact(n-1)* dfloat(n-0)/dfloat(n+1)
         enddo !n

!------ Q(n,0,k)

         DO n=0,JB
         do k=0,n
        Qpnm(n*2,k*2)= DSQRT( (2.d0*(2.d0*n) +1.d0) / 2.d0 ) * (        &
                  dfact( 2*(n-k) ) * dfact( 2*(n+k) ) ) * 2.d0

        Qpnm(n*2+1,k*2+1)= DSQRT( (2.d0*(2.d0*n) +3.d0) / 2.d0 ) * (    &
                          dfact( 2*(n-k) ) * dfact( 2*(n+k+1) ) )       &
                          * 2.d0

         enddo ! k=
        Qpnm(n*2,0  )= DSQRT( (2.d0*(2.d0*n) +1.d0) / 2.d0 ) * (        &
                                      dfact( 2*n ) * dfact( 2*n ) )
         ENDDO ! n=

!------ S(n,0,k)

         DO n=0,JBW,2
         do k=n+2,JBW,2
            Spnm(n,k)= - DSQRT( (2.d0*n+1)/2.d0 ) *(                    &
                        2.d0*k * dfact(k+n-1) * dfact(k-n-2) )          &
                        /(dfloat(k+n+1)*dfloat(k-n))
         enddo ! k=
            k=n
            IF(k==0) m= 2
            IF(k/=0) m= 1
            Spnm(n,k)= + DSQRT( (2.d0*n+1)/2.d0 ) *(                    &
                        dfact(k+n+1) * dfact(k-n) ) * dfloat(m)
         ENDDO ! n=

         DO n=1,JBW-1,2
         do k=n+2,JBW,2
            Spnm(n,k)= - DSQRT( (2.d0*n+1)/2.d0 ) *(                    &
                       2.d0*k * dfact(k+n-1) * dfact(k-n-2) )           &
                       /(dfloat(k+n+1)*dfloat(k-n))
         enddo ! k=
            k=n
            IF(k==0) m= 2
            IF(k/=0) m= 1
            Spnm(n,k)= + DSQRT( (2.d0*n+1)/2.d0 ) *(                    &
                       dfact(k+n+1) * dfact(k-n) ) * dfloat(m)
         ENDDO ! n=

!------ Colatitude -> Latitude

         DO n=1,JBW,2  ! as in Pn0
         do k=1,JBW,2  ! as in cosk
            Spnm(n,k)= Spnm(n,k)* (-1.d0)
            Qpnm(n,k)= Qpnm(n,k)* (-1.d0)
         enddo ! k=
         ENDDO ! n=

!--------------------------------------------------------------------c
      END SUBROUTINE LEGENDRE_Qpnm_Spnm_m0
!====================================================================C


!*********************************************************************
!                                                                    *
!     Integrals with Gaussian Quadrature for Global-FEM              *
!                                                                    *
!     10 MAY 2012 : Code clean up                                    *
!                                                                    *
!*********************************************************************
!     Gaussian latitues, weights of n-points between x1 and x2       *
!                                              -1 <= x1 <=+1         *
!                                              -1 <= x2 <=+1 ; x2>x1 *
!*********************************************************************
      subroutine gausleg(x1,x2,Z,GW,n)
!     subroutine gausleg(x1,x2)
!--------------------------------------------------------------------!
      implicit none
      real(kind=8), intent(in ) :: x1,x2
      integer,      intent(in ) :: n
      real(kind=8), intent(out) :: Z(n),GW(n)
!----
      integer      :: i,j,m
      real(kind=8) :: pi,EPS,xm,xd,temp,p1,p2,p3,pp,z1
!--------------------------------------------------------------------!
      pi= Datan(1.0d0)*4.0d0
      EPS= 1.D-15            ! tolerable error
!
      m=(n+1)/2
      xm=0.5d0*(x2+x1)
      xd=0.5d0*(x2-x1)
      do i=1,m
         temp= Dcos(pi*(i-0.25d0)/(n+0.5d0))
    1 continue
      p1= 1.d0
      p2= 0.d0
      do j=1,n
         p3=p2
         p2=p1
         p1=((2.d0*j-1.d0)*temp*p2-(j-1.d0)*p3)/j
      end do
         pp=n*(temp*p1-p2)/(temp*temp-1.d0)
         z1=temp
         temp= z1-p1/pp
         if(Dabs(temp-z1).gt.EPS) goto 1
         Z(i)= xm-xd*temp
         Z(n+1-i)= xm+xd*temp
         GW(i)= 2.d0*xd/((1.d0-temp*temp)*pp*pp)
         GW(n+1-i)= GW(i)
      end do
!        sum_j(1,JMAX) GW(j)= 2.0
!--
!--------------------------------------------------------------------!
      end subroutine gausleg
!*********************************************************************

!*********************************************************************
!                                                                    *
!     Integrals with Gaussian Quadrature                             *
!                                                                    *
!*********************************************************************

!*********************************************************************
      FUNCTION I_2nd_1_x2_GQ( N, Z, GW, th1, th2, x1, x2 )
!--------------------------------------------------------------------!
      implicit none
      integer     , intent(in ) :: N
      real(kind=8), intent(in ) :: Z(N), GW(N)
      real(kind=8), intent(in ) :: x1, x2, th1, th2
      real(kind=8) :: I_2nd_1_x2_GQ
      real(kind=8) :: xth, sum_integ
      integer :: i
!----
           sum_integ= 0.d0
        DO i=1,N
                 xth=  ( Z(i)*(th2-th1) + (th2+th1) ) / 2.d0

       sum_integ= sum_integ + GW(i) * ( xth-x1 )                        &
                                       * ( xth-x2 )                     &
                                       / ( 1-xth**2.d0 )
        ENDDO
           I_2nd_1_x2_GQ = sum_integ * (th2-th1)/2.d0
!----
!--------------------------------------------------------------------!
      END FUNCTION I_2nd_1_x2_GQ
!*********************************************************************

!23456789012345678901234567890123456789012345678901234567890123456789012
!*********************************************************************
!                                                                    *
!     Spectral(x)-Galerkin(y) method                                 *
!                                                                    *
!     VISCOSITY-FILTERING(SMOOTHING) BY INVERSION OF ELLIPTIC EQS.   *
!     with COMPLEX TRIDIAGONAL SYSTEM                                *
!                                                                    *
!    [1-LAP], [1+LAP^2], [1-LAP^3], [1+LAP^4]                        *
!                                                                    *
!     remarks : Optimization must be done by inputting two variables *
!                                                                    *
!       LAPLACIAN operator in x(=sinLat) coordinate                  *
!                                                                    *
!     m=0          : Vor     =   (d/dx)(1-x^2)(d/dx) Psi             *
!                              +(( -m^2)/(1-x^2)) Psi                *
!     m=1,3,5,7... : Vor/Cos =   (d/dx)(1-x^2)(d/dx)(Psi/Cos)        *
!                               -(d/dx)(2x(Psi/Cos))                 *
!                              +((1-m^2)/(1-x^2))(Psi/Cos)           *
!     m=2,4,6,8... : Vor/Cos^2=  (d/dx)(1-x^2)(d/dx)(Psi/Cos)        *
!                               -(d/dx)(4x(Psi/Cos)) -2 Psi          *
!                              +((4-m^2)/(1-x^2))(Psi/Cos)           *
!                                                                    *
!*********************************************************************
!     SUBROUTINE ZVISFILT8_JS2_Re( V3, D3, gamma0, LAP_DIM ) !
      SUBROUTINE ZVISFILT8_JS2_Re_FEM( V3, gamma0, LAP_DIM ) ! 02 JUN 2008
!--------------------------------------------------------------------C
        use parameter_pi
        use parameter_dsize
        use parameter_fsize
        use common_highorder_filter_sphere
        use common_legendre_m0
        use common_Z_GW_SZ2
        use common_reduced_grid
        use common_enm1_CosSinLat
        implicit none
!--------------------------------------------------------------------C
      real(kind=8) :: V3(-MT:MT, 0:JL)
      real(kind=8), intent(in) :: gamma0
      integer     , intent(in) :: LAP_DIM
!-----local-variable-------------------------------------------------C
      real(kind=8) :: AJX_RE(0:MT,0:JL),ZDMATmi_a_RE(0:MT,3,0:JB,2,8)
      real(kind=8) :: AJX_IM(0:MT,0:JL),ZDMATmi_a_IM(0:MT,3,0:JB,2,8)
      complex(kind=8) :: zalpha(8)
      real(kind=8) :: gam_old=-0.d0, gam_new, ashif,xx,ccc,sss
      integer      :: k,i,mj,mx
!--------------------------------------------------------------------C
      real(kind=8), dimension(0:JBW) :: WORK_m0, coef_cos_m0, coef_Pn0
      real(kind=8), dimension(0:JBW) ::          coef_cos_m1
      real(kind=8), dimension(0:JBW) ::          coef_cos_m2
      real(kind=8)                   :: AJX1D(-MT:MT)
!--------------------------------------------------------------------C
      real(kind=8) :: sum1, visco, gmean
      real(kind=8) :: sum2, dif_pole(-2:2,0:1)
      integer      :: j, n, mc
!--------------------------------------------------------------------C


      IF(LAP_DIM.gt.8) STOP ' != LAP_DIM must not be larger than 6 !!!'

         gam_new= gamma0
      IF(gam_old.NE.gam_new) THEN
         gam_old= gam_new        

             ashif= 1-mod(LAP_DIM,2)
          DO k=1,LAP_DIM
             xx=(PI*ashif+(k-1)*PI2)/dfloat(LAP_DIM)
            ccc= DCOS(xx)
            sss= DSIN(xx)
          zalpha(k)= -dcmplx(ccc,sss)
          END DO

          zalpha(:)=  zalpha(:)*gamma0

          DO i=1,LAP_DIM 
             CALL ZMAT200S_JS2_Re_FEM( zalpha(i)                        &
                               , ZDMATmi_a_RE( 0 ,1,0,1,i)              &
                               , ZDMATmi_a_IM( 0 ,1,0,1,i) ) ! 28 JUL 2008
          END DO ! i=1,LAP_DIM
  
      ENDIF ! JUSTDOIT

!-beg--filtering ===================================================

!-b- preprocessing of forcing function : m=1 and m=2 :  MATm_type_III

!-b--- (Vor/Cos) at pole m=1, (Vor/Cos^2) m=2 : MATm_type_III

      DO mx=-1,1,2

!-a1- grid -> sin wave

      DO mj=0,JBW
         sum1=0.d0
      do j=1,JBW-1
         sum1= sum1 + V3(mx,j)* DSIN( PI*j*mj/dfloat(JBW) )  ! mx=1 : SIN(k phi)
      enddo ! j
         coef_cos_m0(mj)= sum1/dfloat(JB )
      ENDDO ! mj=

!-a2- cos wave -> dif

         sum1= 0.d0 ; sum2= 0.d0
      DO mj=0,JBW
         sum1= sum1 + coef_cos_m0(mj) * ( mj)                   ! 90S
         sum2= sum2 - coef_cos_m0(mj) * ( mj) * (1-2*mod(mj,2)) ! 90N
      ENDDO ! mj=
         dif_pole(mx,0)= sum1
         dif_pole(mx,1)= sum2

      ENDDO ! mx=
!-----
      DO mx=-2,2,4

      DO mj=0,JBW

         sum1=0.d0
      do j=1,JBW-1
         sum1= sum1 + V3(mx,j)* DCOS( PI*j*mj/dfloat(JBW) )  ! mx=1 : SIN(k phi)
      enddo ! j
         sum1= sum1 + ( V3(mx,0) + (1-2*mod(mj,2))* V3(mx,JBW) ) / 2.d0
       if(mj==0 .or. mj==JBW) sum1= sum1 / 2.d0
         coef_cos_m2(mj)= sum1/dfloat(JB )

      ENDDO ! mj=
!---
         sum1= 0.d0 ; sum2= 0.d0
      DO mj=0,JBW
         sum1= sum1 + coef_cos_m2(mj) * (-mj**2)                   ! 90S
         sum2= sum2 + coef_cos_m2(mj) * (-mj**2) * (1-2*mod(mj,2)) ! 90N
      ENDDO ! mj=
         dif_pole(mx,0)= sum1 / 2
         dif_pole(mx,1)= sum2 / 2

      ENDDO ! mx=

!-e--- (Vor/Cos) at pole m=1, (Vor/Cos^2) m=2 : MATm_type_III

!--(1/Cos^ )


      do j=1,JBW-1   ! j=0 S-pole
      do mx=-MT,MT

        if( mod(mx,2)==0 .and. mx==0 ) then

        elseif( mod(mx,2)==0 .and. mx/=0 ) then

         V3(mx,j)= V3(mx,j) / COSLAT0(j-JB,2)

        else

         V3(mx,j)= V3(mx,j) / COSLAT0(j-JB,1)

        endif

      end do
      end do ! j

      do mx=-2,2
        if(mx/=0) then
         V3(mx, 0 )= dif_pole(mx,0)
         V3(mx,JBW)= dif_pole(mx,1)
        endif
      end do

!-e- preprocessing of forcing function : m=1 and m=2 :  MATm_type_III

           do mj=0,JL    ! =0,JL 28 JUL 2008
           do mx=1,MT                     ! -beg 02 JUN 2008 
              AJX_RE(mx,mj)= V3(-mx,mj)   !
              AJX_IM(mx,mj)= V3(+mx,mj)   !
           end do                         !
              AJX_RE( 0,mj)= V3( 0 ,mj)   !
              AJX_IM( 0,mj)= 0.d0         ! -end 02 JUN 2008 
           end do ! mj=

       DO i=1,LAP_DIM
          CALL ZLAP200S_JS2_FEM( AJX_RE, AJX_IM                         &
                         , ZDMATmi_a_RE( 0 ,1,0,1,i)                    &
                         , ZDMATmi_a_IM( 0 ,1,0,1,i) )    ! 28 JUL 2008
       END DO ! i=1,LAP_DIM

           do mj=0,JL    ! =0,JL 28 JUL 2008
           do mx=1,MT                     ! -beg 02 JUN 2008
              V3(-mx,mj)= AJX_RE(mx,mj)
              V3( mx,mj)= AJX_IM(mx,mj)
           end do
              V3( 0 ,mj)= AJX_RE( 0,mj)   ! -end 02 JUN 2008
           end do
!
!-b- postprocessing of inverted function : m=1,2,3,4,...

      do j=0,JBW
      do mx=-MT,MT

        if( mod(mx,2)==0 .and. mx==0 ) then

        elseif( mod(mx,2)==0 .and. mx/=0 ) then

         V3(mx,j)= V3(mx,j) * COSLAT0(j-JB,2)

        else

         V3(mx,j)= V3(mx,j) * COSLAT0(j-JB,1)

        endif
      end do
      end do ! mj=

!-e- postprocessing of inverted function : m=1,2,3,4,...

!-end--filtering ===================================================

!--------------------------------------------------------------------C
      END SUBROUTINE ZVISFILT8_JS2_Re_FEM
!*********************************************************************
!
!
!*********************************************************************
!                                                                    *
!     Spectral(x)-Galerkin(y) method                                 *
!                                                                    *
!     To solve for psi; COMPLEX VARIABLES                            *
!     psi + alpha* ( LAPLACian of psi ) = X_i,j ,                    *
!     which arises from the high-order spectral filter               *
!                                                                    *
!    [CALL ZMAT200S] -> [CALL ZLAP200S] : COMPLEX-variable version   *
!                                                                    *
!       LAPLACIAN operator in x(=sinLat) coordinate                  *
!                                                                    *
!     m=0          : Vor     =   (d/dx)(1-x^2)(d/dx) Psi             *
!                              +(( -m^2)/(1-x^2)) Psi                *
!     m=1,3,5,7... : Vor/Cos =   (d/dx)(1-x^2)(d/dx)(Psi/Cos)        *
!                               -(d/dx)(2x(Psi/Cos))                 *
!                              +((1-m^2)/(1-x^2))(Psi/Cos)           *
!     m=2,4,6,8... : Vor/Cos^2=  (d/dx)(1-x^2)(d/dx)(Psi/Cos)        *
!                               -(d/dx)(4x(Psi/Cos)) -2 Psi          *
!                              +((4-m^2)/(1-x^2))(Psi/Cos)           *
!                                                                    *
!*********************************************************************
!     SUBROUTINE ZMAT200S_JS2 ( zalpha, ZDMATmi_ )
      SUBROUTINE ZMAT200S_JS2_Re_FEM ( zalpha, ZDMATmi_RE, ZDMATmi_IM )
!--------------------------------------------------------------------C
      use parameter_dsize
      use parameter_fsize
        use common_highorder_filter_sphere
        implicit none
!--------------------------------------------------------------------C
      complex(kind=8) :: zalpha
      real(kind=8) :: ZDMATmi_RE(0:MT,3,0:JB ,2)
      real(kind=8) :: ZDMATmi_IM(0:MT,3,0:JB ,2)
!-----local variable-------------------------------------------------C
      real(kind=8) :: ZYMATD_RE(0:MT,3,0:JB )
      real(kind=8) :: ZYMATD_IM(0:MT,3,0:JB ) 
      real(kind=8) :: zalpha_RE, zalpha_IM
      real(kind=8) :: zdv, zrat_RE, zrat_IM
      integer      :: js,k,i,mx,mc,mc1
      real(kind=8) :: mx2
!--------------------------------------------------------------------C
!
      if(zalpha.eq.0.d0) stop 'The zalpha is zero: SUB ZMAT200S_...'
!
         zalpha_RE= REal(zalpha)   ! 17 MAY 2008
         zalpha_IM= IMag(zalpha)   

!*************************************************
!BEG  MATRIECS for LAPLACIAN OPERATOR            * SEMI-IMPLICIT
!*************************************************

!beg-- Matrices for Y= ( D^2/Dlambda^2 + COS(LAT) D/Dphi COS(LAT) D/Dphi ) X

      do k=0,JB
!        ZDMATmi_(mx,i,K,js)= AMATm(   i,K,js) + zalpha*DMATm(mx,i,K,js)
         ZDMATmi_RE(:,:,k,:)= AMATm(:,:,k,:)                            &
                            + DMATm(:,:,k,:) * zalpha_RE  ! 17 MAY 2008, 28 JUL 2008 
         ZDMATmi_IM(:,:,k,:)= 0.d0                                      &
                            + DMATm(:,:,k,:) * zalpha_IM
      end do

!*************************************************
!END  MATRIECS for LAPLACIAN OPERATOR            * SEMI-IMPLICIT
!*************************************************
!

!
!*************************************************
!BEG  Time saving, prehandling of the MATRIX     * SEMI-IMPLICIT
!*************************************************

!23456789012345678901234567890123456789012345678901234567890123456789012

!beg-------------------------------------------------- DMAT -> ZDMAT_
!-----m0,m1,m2,(n1) and m0,m1,m2,(n2)
      DO js=1,2

         do mc=1,JLH-1      ! mc=1,JLH-1 28 JUL 2008
          DO mx=0,MT
            ZYMATD_RE( mx,1,mc)= ZDMATmi_RE(mx,1,mc,js)
            ZYMATD_RE( mx,2,mc)= ZDMATmi_RE(mx,2,mc,js)
            ZYMATD_RE( mx,3,mc)= ZDMATmi_RE(mx,3,mc,js)
            ZYMATD_IM( mx,1,mc)= ZDMATmi_IM(mx,1,mc,js)
            ZYMATD_IM( mx,2,mc)= ZDMATmi_IM(mx,2,mc,js)
            ZYMATD_IM( mx,3,mc)= ZDMATmi_IM(mx,3,mc,js)
          END Do
         end do
            mc=0
          DO mx=0,MT
            ZYMATD_RE( mx,1,mc)= ZDMATmi_RE(mx,1,mc,js)
            ZYMATD_RE( mx,2,mc)= ZDMATmi_RE(mx,2,mc,js)
            ZYMATD_IM( mx,1,mc)= ZDMATmi_IM(mx,1,mc,js)
            ZYMATD_IM( mx,2,mc)= ZDMATmi_IM(mx,2,mc,js)
          END Do
            mc=JLH
          DO mx=0,MT
            ZYMATD_RE( mx,1,mc)= ZDMATmi_RE(mx,1,mc,js)
            ZYMATD_RE( mx,2,mc)= ZDMATmi_RE(mx,2,mc,js)
            ZYMATD_IM( mx,1,mc)= ZDMATmi_IM(mx,1,mc,js)
            ZYMATD_IM( mx,2,mc)= ZDMATmi_IM(mx,2,mc,js)
          END Do
!-------------------
      do mc=0,JLH-1  
         mc1= mc+1   
       Do mx=0,MT

             zdv= ZYMATD_RE( mx,1,mc)**2.d0 + ZYMATD_IM( mx,1,mc)**2.d0
            zrat_RE=( ZYMATD_RE( mx,1,mc1)*ZYMATD_RE( mx,1,mc)          &
                   + ZYMATD_IM( mx,1,mc1)*ZYMATD_IM( mx,1,mc) ) / zdv
            zrat_IM=(-ZYMATD_RE( mx,1,mc1)*ZYMATD_IM( mx,1,mc)          &
                   + ZYMATD_IM( mx,1,mc1)*ZYMATD_RE( mx,1,mc) ) / zdv

!next-sub   ZYMAT(mc )= ZYMAT(mc )*zrat
            ZYMATD_RE( mx,2,mc1)= ZYMATD_RE( mx,2,mc1)                  &
                              -( ZYMATD_RE( mx,2,mc )*zrat_RE           &
                                -ZYMATD_IM( mx,2,mc )*zrat_IM ) 
            ZYMATD_IM( mx,2,mc1)= ZYMATD_IM( mx,2,mc1)                  &
                              -( ZYMATD_RE( mx,2,mc )*zrat_IM           &
                                +ZYMATD_IM( mx,2,mc )*zrat_RE )
!next-sub   ZYMAT(mc1)= ZYMAT(mc1)-ZYMAT(mc )

            ZYMATD_RE( mx,1,mc1)= ZYMATD_RE( mx,2,mc1)
            ZYMATD_RE( mx,2,mc1)= ZYMATD_RE( mx,3,mc1)
            ZYMATD_IM( mx,1,mc1)= ZYMATD_IM( mx,2,mc1)
            ZYMATD_IM( mx,2,mc1)= ZYMATD_IM( mx,3,mc1)

!           ZDMATmi_( mx,1,mc ,js)= 1.d0/ZYMATD( mx,1,mc ) !! (1/*)

             zdv= ZYMATD_RE( mx,1,mc)**2.d0 + ZYMATD_IM( mx,1,mc)**2.d0
            ZDMATmi_RE( mx,1,mc ,js)=  ZYMATD_RE( mx,1,mc)/zdv
            ZDMATmi_IM( mx,1,mc ,js)= -ZYMATD_IM( mx,1,mc)/zdv
!
!           ZDMATmi_( mx,2,mc ,js)=      ZYMATD( mx,2,mc )       
!           ZDMATmi_( mx,3,mc ,js)= zrat
!
            ZDMATmi_RE( mx,2,mc ,js)=  ZYMATD_RE( mx,2,mc )       
            ZDMATmi_IM( mx,2,mc ,js)=  ZYMATD_IM( mx,2,mc )       
            ZDMATmi_RE( mx,3,mc ,js)=  zrat_RE
            ZDMATmi_IM( mx,3,mc ,js)=  zrat_IM
       END Do ! par
      end do ! mc=0,JLH-1

       Do mx=0,MT
!           ZDMATmi_( mx,1,JLH,js)= 1.d0/ZYMATD( mx,1,JLH) !! (1/*)

             zdv= ZYMATD_RE( mx,1,JLH)**2.d0+ZYMATD_IM( mx,1,JLH)**2.d0
            ZDMATmi_RE( mx,1,JLH,js)=  ZYMATD_RE( mx,1,JLH)/zdv
            ZDMATmi_IM( mx,1,JLH,js)= -ZYMATD_IM( mx,1,JLH)/zdv
       END Do ! par

      END DO ! js=1,2
!end-------------------------------------------------- DMAT -> DMAT_

!*************************************************
!END  Time saving, prehandling of the MATRIX     * SEMI-IMPLICIT
!*************************************************

!--------------------------------------------------------------------C
      END SUBROUTINE ZMAT200S_JS2_Re_FEM
!*********************************************************************
!
!
!*********************************************************************
!                                                                    *
!     Spectral(x)-Galerkin(y) method                                 *
!                                                                    *
!     To solve for psi; COMPLEX VARIABLES                            *
!     To get psi or Div from : COMPLEX VARIABLES                     *
!                                                                    *
!     psi + zalpha * ( Laplacian of psi ) = Y  : Global Ave[Y] !=0   *
!     Div + zalpha * ( Laplacian of Div ) = Z  : Global Ave[Z]  =0   *
!                                               because [Div]  =0    *
!    [CALL ZMAT200S] -> [CALL ZLAP200S] : COMPLEX-variable version   *
!                                                                    *
!       LAPLACIAN operator in x(=sinLat) coordinate                  *
!                                                                    *
!     m=0          : Vor     =   (d/dx)(1-x^2)(d/dx) Psi             *
!                              +(( -m^2)/(1-x^2)) Psi                *
!     m=1,3,5,7... : Vor/Cos =   (d/dx)(1-x^2)(d/dx)(Psi/Cos)        *
!                               -(d/dx)(2x(Psi/Cos))                 *
!                              +((1-m^2)/(1-x^2))(Psi/Cos)           *
!     m=2,4,6,8... : Vor/Cos^2=  (d/dx)(1-x^2)(d/dx)(Psi/Cos)        *
!                               -(d/dx)(4x(Psi/Cos)) -2 Psi          *
!                              +((4-m^2)/(1-x^2))(Psi/Cos)           *
!                                                                    *
!*********************************************************************
      SUBROUTINE ZLAP200S_JS2_FEM                                       &
      ( AJX_RE, AJX_IM, ZDMATmi_RE, ZDMATmi_IM )
!--------------------------------------------------------------------C
        use parameter_pi
      use parameter_dsize
      use parameter_fsize
        use common_highorder_filter_sphere
        use common_legendre_m0
        use common_Z_GW_SZ2
        use common_reduced_grid
        use common_enm1_CosSinLat
        implicit none
!--------------------------------------------------------------------C
      real(kind=8) :: AJX_RE(0:MT,0:JBW), ZDMATmi_RE(0:MT,3,0:JB ,2)
      real(kind=8) :: AJX_IM(0:MT,0:JBW), ZDMATmi_IM(0:MT,3,0:JB ,2)
      real(kind=8) :: AJX_REw(0:MT,0:JB,2)
      real(kind=8) :: AJX_IMw(0:MT,0:JB,2)
!-----local-variable-------------------------------------------------C
      real(kind=8) :: ZYMAT_RE( 0 :MT,0:JB ), ZYMAT_IM( 0 :MT,0:JB )
      real(kind=8) :: ajx0r,ajx0i,dd,a4,a5,a6,zaaar,zaaai,parRE,parIM
      real(kind=8) :: tc10r,tc10i
      integer      :: mj,js,jcol,jja,jjb,jjc
      integer      :: mx,mc,mc1,imx,mco,mcop1,jjj
!--------------------------------------------------------------------C
      integer      :: j
      real(kind=8) :: sum, sum1, sum2, rum1, rum2, rum3, rum4
!--------------------------------------------------------------------C

      CALL GLOBAL0_FEM_1D( AJX_RE(0,:), JBW, rum1, +1 )
      CALL GLOBAL0_FEM_1D( AJX_IM(0,:), JBW, rum2, +1 )

!-b- Symmetric and AntiSymmetric component

      do j=0,JLH   ! j=0 S-pole
         AJX_REw(:,j,1)= ( AJX_RE(:,j) - AJX_RE(:,JBW-j) )/2.d0  ! asym
         AJX_REw(:,j,2)= ( AJX_RE(:,j) + AJX_RE(:,JBW-j) )/2.d0  ! sym
         AJX_IMw(:,j,1)= ( AJX_IM(:,j) - AJX_IM(:,JBW-j) )/2.d0  ! asym
         AJX_IMw(:,j,2)= ( AJX_IM(:,j) + AJX_IM(:,JBW-j) )/2.d0  ! sym
      end do

!-e- Symmetric and AntiSymmetric component

!-------------- mx>0, mx<0 ------------c

      DO js=1,2

!---- 1  To get YMAT, YMAT= AMAT*ZETA

         do jcol=1,JLH-1
            jja= jcol-1
            jjb= jcol
            jjc= jcol+1
          Do mx=0,MT ! -MT,MT                         ! 02 JUN 2008
             a4= AMATm( mx,1,jcol,js)
             a5= AMATm( mx,2,jcol,js)
             a6= AMATm( mx,3,jcol,js)
      ZYMAT_RE(mx,jcol)= a4*AJX_REw(mx,jja,js)+a5*AJX_REw(mx,jjb,js)  &
                            +a6*AJX_REw(mx,jjc,js)
      ZYMAT_IM(mx,jcol)= a4*AJX_IMw(mx,jja,js)+a5*AJX_IMw(mx,jjb,js)  &
                            +a6*AJX_IMw(mx,jjc,js)
          END Do ! par
         end do
            jcol=0
            jjb= jcol
            jjc= jcol+1
          Do mx=0,MT ! -MT,MT                         ! 02 JUN 2008
             a4= AMATm( mx,1,jcol,js)
             a5= AMATm( mx,2,jcol,js)
          ZYMAT_RE(mx,jcol)= a4*AJX_REw(mx,jjb,js)+a5*AJX_REw(mx,jjc,js)
          ZYMAT_IM(mx,jcol)= a4*AJX_IMw(mx,jjb,js)+a5*AJX_IMw(mx,jjc,js)
          END Do ! par
            jcol=JLH
            jja= jcol-1
            jjb= jcol
          Do mx=0,MT ! -MT,MT                         ! 02 JUN 2008
             a4= AMATm( mx,1,jcol,js)
             a5= AMATm( mx,2,jcol,js)
          ZYMAT_RE(mx,jcol)= a4*AJX_REw(mx,jja,js)+a5*AJX_REw(mx,jjb,js)
          ZYMAT_IM(mx,jcol)= a4*AJX_IMw(mx,jja,js)+a5*AJX_IMw(mx,jjb,js)
          END Do ! par

!---- 2  To get PSI, DMAT*PSI= YMAT

         do mc=0,JLH-1 
            mc1= mc+1
          Do mx=0,MT ! -MT,MT                         ! 02 JUN 2008
            imx=iabs(mx)
           ZYMAT_RE(mx,mc1)=  ZYMAT_RE(mx,mc1)                          &
                             -ZYMAT_RE(mx,mc )*ZDMATmi_RE(imx,3,mc,js)  &
                             +ZYMAT_IM(mx,mc )*ZDMATmi_IM(imx,3,mc,js)
           ZYMAT_IM(mx,mc1)=  ZYMAT_IM(mx,mc1)                          &
                             -ZYMAT_RE(mx,mc )*ZDMATmi_IM(imx,3,mc,js)  &
                             -ZYMAT_IM(mx,mc )*ZDMATmi_RE(imx,3,mc,js)
          END Do ! par
         end do

          Do mx=0,MT ! -MT,MT                         ! 02 JUN 2008
            imx=iabs(mx)
             zaaar =  ZYMAT_RE(mx,JLH)*ZDMATmi_RE(imx,1,JLH,js) & !! (1/*)
                     -ZYMAT_IM(mx,JLH)*ZDMATmi_IM(imx,1,JLH,js)   !! (1/*)
             zaaai =  ZYMAT_RE(mx,JLH)*ZDMATmi_IM(imx,1,JLH,js) & !! (1/*)
                     +ZYMAT_IM(mx,JLH)*ZDMATmi_RE(imx,1,JLH,js)   !! (1/*)
           ZYMAT_RE(mx,JLH)=  zaaar
           ZYMAT_IM(mx,JLH)=  zaaai
          END Do ! par

         do mco=JLH-1,0,-1
            mcop1=mco+1
          Do mx=0,MT ! -MT,MT                         ! 02 JUN 2008
            imx=iabs(mx)
           zaaar=  ZYMAT_RE(mx,mcop1)*ZDMATmi_RE(imx,2,mco,js)  &  
                  -ZYMAT_IM(mx,mcop1)*ZDMATmi_IM(imx,2,mco,js)
           zaaai=  ZYMAT_RE(mx,mcop1)*ZDMATmi_IM(imx,2,mco,js)  &
                       +ZYMAT_IM(mx,mcop1)*ZDMATmi_RE(imx,2,mco,js)
           parRE=  ZYMAT_RE(mx,mco)-zaaar
           parIM=  ZYMAT_IM(mx,mco)-zaaai
           ZYMAT_RE(mx,mco)= parRE*ZDMATmi_RE(imx,1,mco,js)     &
                            -parIM*ZDMATmi_IM(imx,1,mco,js)
           ZYMAT_IM(mx,mco)= parRE*ZDMATmi_IM(imx,1,mco,js)     &
                            +parIM*ZDMATmi_RE(imx,1,mco,js)
          END Do ! par
         end do

         do jcol=0,JLH
            jjj= jcol
          Do mx=0,MT ! -MT,MT                         ! 02 JUN 2008
            AJX_REw(mx,jjj,js)= ZYMAT_RE(mx,jcol)
            AJX_IMw(mx,jjj,js)= ZYMAT_IM(mx,jcol)
          END Do ! par
         end do

      END DO ! js=1,2
!-----
      do mx=3,MT
         AJX_REw(mx,0,:)= 0.d0  ! Sym and Asym at poles = 0 : mx>=3,... : MAT_type_III
         AJX_IMw(mx,0,:)= 0.d0  ! 22 OCT 2012, v(=d*/dLon)  : mx=1 (v)
      end do

      DO j=0,JLH
         AJX_RE(:,JBW-j)= AJX_REw(:,j,2) - AJX_REw(:,j,1)
         AJX_RE(:,    j)= AJX_REw(:,j,2) + AJX_REw(:,j,1)  ! sym
         AJX_IM(:,JBW-j)= AJX_IMw(:,j,2) - AJX_IMw(:,j,1)
         AJX_IM(:,    j)= AJX_IMw(:,j,2) + AJX_IMw(:,j,1)  ! sym
      END DO
!-----

      CALL GLOBAL0_FEM_1D( AJX_RE(0,:), JBW, rum3, +1 )
      CALL GLOBAL0_FEM_1D( AJX_IM(0,:), JBW, rum4, +1 )
!
         AJX_RE(0,:)= AJX_RE(0,:) + rum1  ! global-mean reconstructed
         AJX_IM(0,:)= AJX_IM(0,:) + rum2

!--------------------------------------------------------------------C
      END SUBROUTINE ZLAP200S_JS2_FEM
!*********************************************************************
!

!23456789012345678901234567890123456789012345678901234567890123456789012
!*********************************************************************
!                                                                    *
!     Spectral(x)-Galerkin(y) method                                 *
!                                                                    *
!     06 SEP 2012 : sinLat coordinate                                *
!                 : vor=-dU/dx+(dv/dlon)/cos                         *
!     07 SEP 2012 : vor=-d(uCos)+(dv/dlon)/cos == Type III           *
!                 : best of type I, II, and III                      *
!     16 SEP 2012 : vor=-du/dlat + u(SinLat)/CosLat +(1/Cos)dv/dlon  *
!                 : better than III, particularly for mass conservation
!                 : Matrix Z & v1MAT are very similar to U- and PMAT *
!     16 OCT 2012 : Z=-du/dth mat modified for mx=2                  *
!                 : Zmat==-du/dth neq for mx=2                       *
!     16 OCT 2012 : Z=-du/dth mat modified for mx=3                  *
!     06 NOV 2012 : 1-2*mod(mj,2)                                    *
!                 : COSym0, SINym0                                   *
!                                                                    *
!*********************************************************************
      SUBROUTINE MATm_vor_uv_JS2_FEM
!--------------------------------------------------------------------C
      use parameter_pi
      use parameter_dsize
      use parameter_fsize
      use parameter_sin_power_o_e
      use common_highorder_filter_sphere
      use common_legendre_m0
      use common_Z_GW_SZ2
      use common_reduced_grid
        implicit none
!-----local variable-------------------------------------------------C
      real(kind=8) :: YMATD(0:MT,3,0:JB)
      real(kind=8) :: rat
      integer      :: js,jsmo,jcol,jcoljsm,mx,j,k,i,mc,mc1
      integer      :: jbeg, N9=Ngrid
      real(kind=8) :: mx2, thkp1,thk,thkm1
!--------------------------------------------------------------------C
      real(kind=8) :: del
!--------------------------------------------------------------------C
!
      do mc=0,JBW                      ! for use in Fourier-series
         thk= dfloat(mc)*PI/dfloat(JBW)
      do j=0,JBW
         COSym0(mc,j)= DCOS( thk * dfloat(j) )
         SINym0(mc,j)= DSIN( thk * dfloat(j) )
      end do ; end do
!
!*************************************************
!beg-- Matrices for vor= -(d uCos / dx) + (d v / dlon)(1/Cos)
!*************************************************

         ZMATm(: ,:,:,:)= 0.d0
        v1MATm(: ,:,:,:)= 0.d0

      DO mx=0,MT
!
!-- only ZMATm(: ,:,:,:) is inverted, but not v1MATm & v2MATm
!
         ZMATm(mx,:,:,1)= 0.d0  
         ZMATm(mx,2,:,1)= 1.d0  ! diag
         ZMATm(mx,2,0,1)= 0.d0
         ZMATm(mx,1,0,1)= 1.d0  ! diag

           jbeg= jlat(mx)+1  ! (jbeg>0) is necessary
!************
      do j=jbeg,JB
!************
                   thkp1= rthetam(j+1)
                   thk  = rthetam(j  )
                   thkm1= rthetam(j-1)
                     del= PI/dfloat(JBW)
!-
         ZMATm(mx,1,j,1)=  del * 1.d0 / 6.d0
         ZMATm(mx,2,j,1)=  del * 4.d0 / 6.d0                 ! mass term
         ZMATm(mx,3,j,1)=  del * 1.d0 / 6.d0
!
        v1MATm(mx,1,j,1)=  1/2.d0                            ! u-term (k-1) = -du/dlat
        v1MATm(mx,3,j,1)= -1/2.d0                            ! u-term (k+1) = -du/dlat

      end do ! j=jbeg,JB

!************
         j= 0000  ! BC modification
!************

           if(mx==1) then

         j= jbeg

         ZMATm(mx,1,j,1)=  0.d0

       elseif(mx>1 .and. mod(mx,2)==1) then                  ! mx=3 modified

         j= jbeg

         ZMATm(mx,1,j,1)=  0.d0
        v1MATm(mx,1,j,1)=  0.d0

       elseif(mod(mx,2)==0) then                             ! mx=2 modified

         j= 0     ! only needed for m=0,2 because Z(0) /=0   ! Z=-du/dth
                                                             ! Zmat is not for vorticity
                     del= PI/dfloat(JBW)

         ZMATm(mx,1,j,1)=  del * 2.d0 / 6.d0
         ZMATm(mx,2,j,1)=  del * 1.d0 / 6.d0                 ! mass term
!
        v1MATm(mx,1,j,1)=  0.d0
        v1MATm(mx,2,j,1)= -1/2.d0                            ! u-term (k+1) = -du/dlat

         j= jbeg
 
        v1MATm(mx,1,j,1)=  0.d0                              ! u(m=0)=0,u(m=2,4,...)=0: 90N

       endif 
!
      END DO ! mx=0,MT

!---- m=0: Z(0) /= 0  -> [*,*      ] z0   [0,*      ] v1=(u-vel)
!                        [*,*,*    ] z1 = [0,*,*    ] v1
!                        [  *,*,*  ] z2   [  *,*,*  ] v1
!                        [    *,*,*] z3   [    *,*,*] v1

!---- m=1: Z(0) == 0  -> [1,0      ] z0   [0,0      ] v1=(u-vel)
!                        [0,*,*    ] z1 = [*,*,*    ] v1
!                        [  *,*,*  ] z2   [  *,*,*  ] v1
!                        [    *,*,*] z3   [    *,*,*] v1
!
!---- m=2: Z(0) /= 0  -> [*,*      ] z0   [0,*      ] v1=(u-vel)  ! notice that Z=-du/dth
!       4                [*,*,*    ] z1 = [0,*,*    ] v1          ! , but not vorticity
!       6                [  *,*,*  ] z2   [  *,*,*  ] v1
!                        [    *,*,*] z3   [    *,*,*] v1
!
!---- m=3: Z(0) == 0  -> [1,0      ] z0   [0,0      ] v1=(u-vel)
!       5                [0,*,*    ] z1 = [0,*,*    ] v1
!       7                [  *,*,*  ] z2   [  *,*,*  ] v1
!                        [    *,*,*] z3   [    *,*,*] v1
!
!-(1)   js= 2 for NS Symmetric : psi-sym = u-asym

        v1MATm(: ,:,:,2)= v1MATm(: ,:,:,1)

         j= JB
        v1MATm(: ,1,j,2)= v1MATm(: ,1,j,2) + v1MATm(: ,3,j,2)  ! by symmetry across EQ.
        v1MATm(: ,3,j,2)= 0.d0

!----   js= 1 for NS AntiSymmetric : psi-asym = u-sym

         j= JB
        v1MATm(: ,1,j,1)= v1MATm(: ,1,j,1) - v1MATm(: ,3,j,1)  ! by symmetry across EQ.
        v1MATm(: ,3,j,1)= 0.d0

         j= JB-1
        v1MATm(: ,3,j,1)= 0.d0

!-(2)   js= 2 for NS Symmetric : psi-sym = u-asym

         ZMATm(: ,:,:,2)=  ZMATm(: ,:,:,1)

         j= JB
         ZMATm(: ,1,j,2)=  ZMATm(: ,1,j,2) +  ZMATm(: ,3,j,2)  ! by symmetry across EQ.
         ZMATm(: ,3,j,2)= 0.d0

!----   js= 1 for NS AntiSymmetric : psi-asym = u-sym

         j= JB
         ZMATm(: ,:,j,1)= 0.d0
         ZMATm(: ,2,j,1)= 1.d0 ! for matrix inversion
         ZMATm(: ,3,j,1)= 0.d0
!---
         j= JB-1
         ZMATm(: ,3,j,1)= 0.d0
 
!*************************************************
!end-- Matrices for vor= -(d uCos / dx) + (d v / dlon)(1/Cos)
!*************************************************
!
!*************************************************
!BEG  Time saving, prehandling of the MATRIX     *
!*************************************************

!beg-------------------------------------------------- ZMAT -> ZMAT_
!
      DO js=1,2

         do mc=1,JB-1
          Do mx=0,MT
            YMATD( mx,1,mc)= ZMATm(mx,1,mc,js)
            YMATD( mx,2,mc)= ZMATm(mx,2,mc,js) 
            YMATD( mx,3,mc)= ZMATm(mx,3,mc,js)
          END Do
         end do
            mc=0
          Do mx=0,MT
            YMATD( mx,1,mc)= ZMATm(mx,1,mc,js)
            YMATD( mx,2,mc)= ZMATm(mx,2,mc,js)
          END Do
            mc=JB 
          Do mx=0,MT
            YMATD( mx,1,mc)= ZMATm(mx,1,mc,js)
            YMATD( mx,2,mc)= ZMATm(mx,2,mc,js)
          END Do

      do mc=0,JB-1                    
         mc1= mc+1
       Do mx=0,MT

         rat= YMATD( mx,1,mc1) / YMATD( mx,1,mc)

!next-sub   YMAT(mc )= YMAT(mc )*rat   
            YMATD( mx,2,mc1)= YMATD( mx,2,mc1)-YMATD( mx,2,mc )*rat    
!next-sub   YMAT(mc1)= YMAT(mc1)-YMAT(mc )
            YMATD( mx,1,mc1)= YMATD( mx,2,mc1)
            YMATD( mx,2,mc1)= YMATD( mx,3,mc1)

            ZMATm_( mx,1,mc ,js)= 1.d0/YMATD( mx,1,mc ) !! (1/*)

            ZMATm_( mx,2,mc ,js)=      YMATD( mx,2,mc )
            ZMATm_( mx,3,mc ,js)= rat
       END Do ! par
      end do ! mc=0,JB-1

       Do mx=0,MT
            ZMATm_( mx,1,JB,js)= 1.d0/YMATD( mx,1,JB) !! (1/*)
       END Do ! par

      END DO ! js=1,2
!
!end-------------------------------------------------- DMAT -> DMAT_

!*************************************************
!END  Time saving, prehandling of the MATRIX     *
!*************************************************
!
!--------------------------------------------------------------------C
      END SUBROUTINE MATm_vor_uv_JS2_FEM
!*********************************************************************

!*********************************************************************
!                                                                    *
!     vorticity from u & v                                           *
!                                                                    *
!     vor( sym) cos = - d u(asym)cos / d the + d v( sym)/ dlam       *
!     vor(asym) cos =   d u( sym)cos / d the + d v(asym)/ dlam       *
!                                                                    *
!     06 SEP 2012 : sinLat coordinate                                *
!                 : vor=-dU/dx+(dV/dlon)/cos^2                       *
!     16 SEP 2012 : vor=-du/dlat + u(SinLat)/CosLat +(1/Cos)dv/dlon  *
!                 : better than III, particularly for mass conservation
!                                                                    *
!                                                         -> -du/dth *
!     16 OCT 2012 : Z=-du/dth mat modified for mx=2                  *
!                 : Zmat==-du/dth neq 0 for mx=2                     *
!                 : , but Vort(m=1,2,..., 0 )= 0                     *
!                 :       Vort(m=1,2,...,JBW)= 0                     *
!     08 NOV 2012 : adv_m0 segment restructured                      *
!     18 NOV 2012 : adv for all mx by spectral                       *
!     30 DEC 2012 : switch btw 'adv' or 'vor'                        *
!                                                                    *
!*********************************************************************
      SUBROUTINE uv_to_vor_FEM ( TC1psi, TC2psi, AJXzeta, advORvor )  ! u, v, vort
!--------------------------------------------------------------------C
      use parameter_pi
      use parameter_dsize
      use parameter_fsize
      use common_highorder_filter_sphere
      use common_legendre_m0
      use common_Z_GW_SZ2
      use common_reduced_grid
      use common_enm1_CosSinLat
        implicit none
!--------------------------------------------------------------------C
      real(kind=8), intent( in) :: TC1psi(-MT:MT,0:JBW) 
      real(kind=8), intent( in) :: TC2psi(-MT:MT,0:JBW) 
      real(kind=8), intent(out) :: AJXzeta(-MT:MT,0:JBW)
      character(len=3), intent( in) :: advORvor
!-----local variable-------------------------------------------------C
      real(kind=8) :: a4,a5,a6,ace,aaa,XMAT0
      integer      :: js,jcol,jja,jjb,jjc,mx,imx,mc,mc1,mco,mcop1,jjj
!--------------------------------------------------------------------C
      real(kind=8) :: TC1(-MT:MT,0:JB,2), AJX(-MT:MT,0:JB,2)
      real(kind=8), dimension(0:JBW) :: WORK_m0, coef_cos_m0, coef_Pn0
!--------------------------------------------------------------------C
      real(kind=8) :: sum1, sum2
      integer      :: j, mj, k, n, ks
!--------------------------------------------------------------------C
      real(kind=8) :: ANM(-MT:MT,0:JBW)
!--------------------------------------------------------------------C
!     integer      :: adv_mx0= +1  ! (+1) or (-1), in parameter_xdir_sphere
!--------------------------------------------------------------------C
!     JL=JBW, JLH=JB

!-b- Symmetric and AntiSymmetric component

      do j=0,JB   ! j=0 S-pole
         TC1(:,j,1)= ( TC1psi(:,j) - TC1psi(:,JBW-j) )/2.d0  ! asym
         TC1(:,j,2)= ( TC1psi(:,j) + TC1psi(:,JBW-j) )/2.d0  ! sym
      end do

!-e- Symmetric and AntiSymmetric component

         AJX(:,:,:)= 0.d0 

      DO js=1,2

         if(js==1) ks=2
         if(js==2) ks=1

!---- 1  To get YMAT, YMAT= DMAT*TC1

         do jcol=1,JB-1
            jja= jcol-1
            jjb= jcol
            jjc= jcol+1
          Do mx=-MT,MT
            imx=iabs(mx)
             a4= v1MATm(imx,1,jcol,js)
             a5= v1MATm(imx,2,jcol,js)
             a6= v1MATm(imx,3,jcol,js)
             ace=( a5 )*TC1(mx,jjb,js)
            YMAT(mx,jcol)= a4*TC1(mx,jja,js) + ace + a6*TC1(mx,jjc,js)
          END Do ! par
         end do

            jcol=0
            jjb= jcol
            jjc= jcol+1
          Do mx=-MT,MT
            imx=iabs(mx)
             a4= v1MATm(imx,1,jcol,js)
             a5= v1MATm(imx,2,jcol,js)
            YMAT(mx,jcol)=( a4 )*TC1(mx,jjb,js)+a5*TC1(mx,jjc,js)
          END Do ! par

            jcol=JB
            jja= jcol-1
            jjb= jcol
          Do mx=-MT,MT
            imx=iabs(mx)
             a4= v1MATm(imx,1,jcol,js)
             a5= v1MATm(imx,2,jcol,js)
            YMAT(mx,jcol)= a4*TC1(mx,jja,js)+( a5 )*TC1(mx,jjb,js)
          END Do ! par

!---- 2  To get ZETA, AMAT*ZETA= YMAT

         do mc=0,JB-1
            mc1= mc+1
          Do mx=-MT,MT
            imx=iabs(mx)
            YMAT(mx,mc1)= YMAT(mx,mc1)-YMAT(mx,mc )*ZMATm_(imx,3,mc,ks)  ! js
          END Do ! par
         end do

          Do mx=-MT,MT
            imx=iabs(mx) 
            YMAT(mx,JB)=  YMAT(mx,JB) * ZMATm_(imx,1,JB,ks) !! (1/*)  ! js
          END Do ! par

         do mco=JB-1,0,-1
            mcop1=mco+1
          Do mx=-MT,MT
            imx=iabs(mx)
                 aaa =  YMAT(mx,mcop1)*ZMATm_(imx,2,mco,ks)  ! js
            YMAT(mx,mco)= (YMAT(mx,mco)-aaa) * ZMATm_(imx,1,mco,ks)  ! js
          END Do ! par
         end do

         do jcol=0,JB
            jjj= jcol
          Do mx=-MT,MT
            AJX(mx,jjj,ks)= YMAT(mx,jcol)  ! js
          END Do ! par
         end do

      END DO ! js=1,2

!-----
      do mx=1,MT             ! 16 OCT 2012
         AJX(-mx,0,:)= 0.d0  ! Sym and Asym at poles = 0 : mx >= 1
         AJX(+mx,0,:)= 0.d0  ! For mx=2, AJX(+mx,0,:) /= 0
                             ! , but cancelled by other terms below
      end do ! mx=
!
      do j=0,JB
         AJXzeta(:,JBW-j)= AJX(:,j,2) - AJX(:,j,1)             ! -du/dth
         AJXzeta(:,    j)= AJX(:,j,2) + AJX(:,j,1)  ! sym
      end do
!
      if(advORvor=='adv') then

      if(adv_mx0==+1) then ! mx=0 by Fourier-fun

      DO mj=0,JBW
         sum1=0.d0
      do j=0,JBW
         sum1= sum1 +   TC1psi(0, j ) * SINym0(mj,j)
      enddo ! j
               coef_cos_m0(mj)= sum1/dfloat(JB )
      ENDDO ! mj=

      DO j=0,JBW
         sum1= 0.d0
      do mj=0,JBW
         sum1= sum1 + coef_cos_m0(mj)* ( mj)* COSym0(mj,j)
      enddo ! mj=
         AJXzeta(0, j )= -sum1                    ! (- d v h / d the )
      ENDDO ! j=

!-- all mx by spectral

      elseif(adv_mx0==+2) then

      CALL FFT_DFS_235_SC_FullGrid_r_y_trans( +1, TC1psi, ANM, JBW,-1)

      DO mx=-MT,MT
        if(mod(mx,2)==0) then
           do mj=0,JBW
              ANM(mx,mj)= -ANM(mx,mj)*( mj)       ! (- d v h / d the ) 
           enddo
        else
           do mj=0,JBW
              ANM(mx,mj)= -ANM(mx,mj)*(-mj)
           enddo
        endif
      END DO

      CALL FFT_DFS_235_SC_FullGrid_y_trans( -1, AJXzeta, ANM, JBW,-1)

!-- all mx by spectral

      endif !----------------mx=0 by Fourier-fun
!
      endif !--advORvor
!
         AJXzeta(0,  0  )=  AJXzeta(0,  0  ) * 2               ! u.Sin/Cos at poles
         AJXzeta(0, JBW )=  AJXzeta(0, JBW ) * 2

      do j=1,JBW-1
      do mx=-MT,MT
         AJXzeta(mx, j  )=  AJXzeta( mx, j )                 &  
                       +(   TC1psi( mx, j ) *  SINLAT0(j-JB) & ! u.Sin/Cos
                          + TC2psi(-mx, j ) *(-mx)           & ! (dv/dlon) /C
                        )/  COSLAT0(j-JB,1)
      end do
      end do

!--------------------------------------------------------------------C
      END SUBROUTINE uv_to_vor_FEM
!*********************************************************************

!23456789012345678901234567890123456789012345678901234567890123456789012
!*********************************************************************
!                                                                    *
!     Spectral(x)-Galerkin(y) method                                 *
!                                                                    *
!    <- SUB MAT200E_JS2                                              *
!                                                                    *
!     26 JUL 2012 : Matrix for U-psi, Advection, Mass-mat            *
!                 : Matrix Z & v1MAT are very similar to U- and PMAT *
!                                                                    *
!*********************************************************************
      SUBROUTINE UMAT_PMATm_JS2_FEM
!--------------------------------------------------------------------C
      use parameter_pi
      use parameter_dsize
      use parameter_fsize
      use parameter_sin_power_o_e
      use common_highorder_filter_sphere
      use common_legendre_m0
      use common_Z_GW_SZ2
      use common_reduced_grid
        implicit none
!-----local variable-------------------------------------------------C
      real(kind=8) :: YMATD(0:MT,3,0:JLH)
      real(kind=8) :: rat
      integer      :: js,jsmo,jcol,jcoljsm,mx,j,k,i,mc,mc1
      integer      :: jbeg, N9=Ngrid
      real(kind=8) :: mx2, thkp1,thk,thkm1
!--------------------------------------------------------------------C
      real(kind=8) :: del
!--------------------------------------------------------------------C

!*************************************************
!BEG  MATRIECS for U-vel-psi, Adv-y, Mass-mat    *
!*************************************************
!
!beg-- Matrices for Y= ( D^2/Dlambda^2 + COS(LAT) D/Dphi COS(LAT) D/Dphi ) X

!------- m = 0  : Vanishing gradient : done with Leg Poly
         mx= 0

         UMATm(: ,:,:,:)= 0.d0                         ! for m>=1

         PMATm(: ,:,:,:)= 0.d0  ! only forward operation for m>=1

!-b----- mx= 1,2,..  : F'(x)=0 at x=0 and x=L (linear+COS) or (linear+SIN)

      DO mx=0,MT,1

         UMATm(mx,:,:,1)= 0.d0
         UMATm(mx,2,:,1)= 1.d0  ! diag
         UMATm(mx,2,0,1)= 0.d0
         UMATm(mx,1,0,1)= 1.d0  ! diag

           jbeg= jlat(mx)+1  ! (jbeg>0) is necessary
!************
      do j=jbeg,JLH
!************
                   thkp1= rthetam(j+1)
                   thk  = rthetam(j  )
                   thkm1= rthetam(j-1)
                     del= PI/dfloat(JBW)
!-
         UMATm(mx,1,j,1)=  del * 1.d0 / 6.d0
         UMATm(mx,2,j,1)=  del * 4.d0 / 6.d0
         UMATm(mx,3,j,1)=  del * 1.d0 / 6.d0
!
         PMATm(mx,1,j,1)=  1/2.d0                                   ! ADV_k-1
         PMATm(mx,3,j,1)= -1/2.d0                                   ! ADV_k+1

      end do ! j=jbeg,JLH

!************
         j= jbeg  ! BC modification
!************

           if(mx>=2) then !-----polar piece

!************
         j= jbeg  ! BC modification
!************
!                  thkp1= rthetam(j+1)
!                  thk  = rthetam(j  )
!                  thkm1= rthetam(j-1)
                     del= PI/dfloat(JBW)

         PMATm(mx,1,j,1)=    0.d0                               ! A(1,0)

         UMATm(mx,1,j,1)=    0.d0

       elseif(mx==1) then

!************
         j= 0     ! BC modification
!************
!                  thkp1= rthetam(j+1)
!                  thk  = rthetam(j  )
                     del= PI/dfloat(JBW)

         PMATm(mx,1,j,1)=  0.d0
         PMATm(mx,2,j,1)= -1.d0  ! ( -1/2 -(1/2) )

         UMATm(mx,1,j,1)=  del * 4.d0 / 6.d0
         UMATm(mx,2,j,1)=  del * 2.d0 / 6.d0  ! works well ... unexpected
!        UMATm(mx,2,j,1)=  del * 0.d0 / 6.d0  ! not works

       elseif(mx==0) then

!************
         j= 0     ! BC modification
!************
                   thkp1= rthetam(j+1)
                   thk  = rthetam(j  )
                     del= DELtheta(1)
                     del= PI/dfloat(JBW)

         PMATm(mx,1,j,1)=  0.d0
         PMATm(mx,2,j,1)=  0.d0

         UMATm(mx,1,j,1)=  del * 4.d0 / 6.d0  ! any value other than zero works right.
!        UMATm(mx,2,j,1)=  del * 2.d0 / 6.d0  ! if psi(j=-1)= psi(j=1) assumed. Not works well. 
         UMATm(mx,2,j,1)=  del * 0.d0 / 6.d0  ! should be zero-valued

        endif !-----------------polar piece 

      END DO ! mx=0,MT,1

!-e----- mx= 1,2,..  : F'(x)=0 at x=0 and x=L (linear+COS) or (linear+SIN)

!-(1)   js= 2 for NS Symmetric : psi-sym = u-asym

         PMATm(: ,:,:,2)= PMATm(: ,:,:,1)

         j= JLH
         PMATm(: ,1,j,2)= PMATm(: ,1,j,2) + PMATm(: ,3,j,2)  ! by symmetry across EQ.
         PMATm(: ,3,j,2)= 0.d0

!----   js= 1 for NS AntiSymmetric : psi-asym = u-sym

         j= JLH
         PMATm(: ,1,j,1)= PMATm(: ,1,j,1) - PMATm(: ,3,j,1)  ! by symmetry across EQ.
         PMATm(: ,3,j,1)= 0.d0

         j= JLH-1
         PMATm(: ,3,j,1)= 0.d0

!-(2)   js= 2 for NS Symmetric 

         UMATm(: ,:,:,2)= UMATm(: ,:,:,1)

         j= JLH
         UMATm(: ,1,j,2)= UMATm(: ,1,j,2) + UMATm(: ,3,j,2)  ! by symmetry across EQ.
         UMATm(: ,3,j,2)= 0.d0

!----   js= 1 for NS AntiSymmetric 

         j= JLH
         UMATm(: ,:,j,1)= 0.d0
         UMATm(: ,2,j,1)= 1.d0 ! for matrix inversion
         UMATm(: ,3,j,1)= 0.d0

         j= JLH-1
         UMATm(: ,3,j,1)= 0.d0

!--------------------------------------------------------------------------
!end-- Matrices for Y= ( D^2/Dlambda^2 + COS(LAT) D/Dphi COS(LAT) D/Dphi ) X
!--------------------------------------------------------------------------
!
!*************************************************
!END  MATRIECS for U-vel-psi, Adv-y, Mass-mat    *
!*************************************************
!
!*************************************************
!BEG  Time saving, prehandling of the MATRIX     *
!*************************************************
!
!beg-------------------------------------------------- UMAT -> UMAT_

      DO js=1,2

         do mc=1,JLH-1
          Do mx=0,MT
            YMATD( mx,1,mc)= UMATm(mx,1,mc,js) 
            YMATD( mx,2,mc)= UMATm(mx,2,mc,js) 
            YMATD( mx,3,mc)= UMATm(mx,3,mc,js)
          END Do
         end do
            mc=0
          Do mx=0,MT
            YMATD( mx,1,mc)= UMATm(mx,1,mc,js)
            YMATD( mx,2,mc)= UMATm(mx,2,mc,js)
          END Do
            mc=JLH 
          Do mx=0,MT
            YMATD( mx,1,mc)= UMATm(mx,1,mc,js)
            YMATD( mx,2,mc)= UMATm(mx,2,mc,js)
          END Do

      do mc=0,JLH-1                    
         mc1= mc+1
       Do mx=0,MT

         rat= YMATD( mx,1,mc1) / YMATD( mx,1,mc)

!next-sub   YMAT(mc )= YMAT(mc )*rat   
            YMATD( mx,2,mc1)= YMATD( mx,2,mc1)-YMATD( mx,2,mc )*rat    
!next-sub   YMAT(mc1)= YMAT(mc1)-YMAT(mc )
            YMATD( mx,1,mc1)= YMATD( mx,2,mc1)
            YMATD( mx,2,mc1)= YMATD( mx,3,mc1)

            UMATm_( mx,1,mc ,js)= 1.d0/YMATD( mx,1,mc ) !! (1/*)

            UMATm_( mx,2,mc ,js)=      YMATD( mx,2,mc )
            UMATm_( mx,3,mc ,js)= rat
       END Do ! par
      end do ! mc

       Do mx=0,MT
            UMATm_( mx,1,JLH,js)= 1.d0/YMATD( mx,1,JLH) !! (1/*)
       END Do ! par

      END DO ! js=1,2
!
!end-------------------------------------------------- CMAT -> CMAT_ 

!*************************************************
!END  Time saving, prehandling of the MATRIX     *
!*************************************************
!
!--------------------------------------------------------------------C
      END SUBROUTINE UMAT_PMATm_JS2_FEM
!*********************************************************************

!*********************************************************************
!                                                                    *
!     u & v from streamfunction                                      *
!                                                                    *
!     u(sym) = streaam(asym); u(asym)= stream(sym)                   *
!                                                                    *
!     24 JUL 2012 : by FEM                                           *
!     30 JUL 2012 : add vnm                                          *
!                                                                    *
!*********************************************************************
      SUBROUTINE PSI_to_uv_FEM ( TC1psi, unm, vnm )
!--------------------------------------------------------------------C
      use parameter_pi
      use parameter_dsize
      use parameter_fsize
      use common_highorder_filter_sphere
      use common_legendre_m0
      use common_Z_GW_SZ2
      use common_reduced_grid
      use common_enm1_CosSinLat
        implicit none
!--------------------------------------------------------------------C
      real(kind=8) :: TC1psi(-MT:MT,0:JBW)
      real(kind=8) :: unm(-MT:MT,0:JBW), vnm(-MT:MT,0:JBW)
!-----local variable-------------------------------------------------C
      real(kind=8) :: a4,a5,a6,ace,aaa,XMAT0
      integer      :: js,jcol,jja,jjb,jjc,mx,imx,mc,mc1,mco,mcop1,jjj
!--------------------------------------------------------------------C
      real(kind=8) :: TC1(-MT:MT,0:JB,2), AJX(-MT:MT,0:JB,2)
      real(kind=8), dimension(0:JBW) :: WORK_m0, coef_cos_m0, coef_Pn0
!--------------------------------------------------------------------C
      real(kind=8) :: sum1
      integer      :: j, mj, k, n, ks
!--------------------------------------------------------------------C
      real(kind=8) :: ANM(-MT:MT,0:JBW)
!--------------------------------------------------------------------C
!     JL=JBW, JLH=JB

!-b- Symmetric and AntiSymmetric component

      do j=0,JB    ! j=0 S-pole
         TC1(:,j,1)= ( TC1psi(:,j) - TC1psi(:,JBW-j) )/2.d0  ! asym
         TC1(:,j,2)= ( TC1psi(:,j) + TC1psi(:,JBW-j) )/2.d0  ! sym
      end do

!-e- Symmetric and AntiSymmetric component

         AJX(:,:,:)= 0.d0 

      DO js=1,2

         if(js==1) ks=2
         if(js==2) ks=1

!---- 1  To get YMAT, YMAT= DMAT*TC1

         do jcol=1,JB-1
            jja= jcol-1
            jjb= jcol
            jjc= jcol+1
          Do mx=-MT,MT
            imx=iabs(mx)
             a4= PMATm(imx,1,jcol,js)
             a5= PMATm(imx,2,jcol,js)
             a6= PMATm(imx,3,jcol,js)
             ace=( a5 )*TC1(mx,jjb,js)
            YMAT(mx,jcol)= a4*TC1(mx,jja,js) + ace + a6*TC1(mx,jjc,js)
          END Do ! par
         end do

            jcol=0
            jjb= jcol
            jjc= jcol+1
          Do mx=-MT,MT
            imx=iabs(mx) 
             a4= PMATm(imx,1,jcol,js)
             a5= PMATm(imx,2,jcol,js)
            YMAT(mx,jcol)=( a4 )*TC1(mx,jjb,js)+a5*TC1(mx,jjc,js)
          END Do ! par

            jcol=JB 
            jja= jcol-1
            jjb= jcol
          Do mx=-MT,MT
            imx=iabs(mx)
             a4= PMATm(imx,1,jcol,js)
             a5= PMATm(imx,2,jcol,js)
            YMAT(mx,jcol)= a4*TC1(mx,jja,js)+( a5 )*TC1(mx,jjb,js)
          END Do ! par

!---- 2  To get ZETA, AMAT*ZETA= YMAT

         do mc=0,JB-1
            mc1= mc+1
          Do mx=-MT,MT
            imx=iabs(mx)
            YMAT(mx,mc1)= YMAT(mx,mc1)-YMAT(mx,mc )*UMATm_(imx,3,mc,ks)  ! js
          END Do ! par
         end do

          Do mx=-MT,MT
            imx=iabs(mx) 
            YMAT(mx, JB)=  YMAT(mx, JB) * UMATm_(imx,1, JB,ks) !! (1/*)  ! js
          END Do ! par

         do mco=JB-1,0,-1
            mcop1=mco+1
          Do mx=-MT,MT
            imx=iabs(mx)
                 aaa =  YMAT(mx,mcop1)*UMATm_(imx,2,mco,ks)  ! js
            YMAT(mx,mco)= (YMAT(mx,mco)-aaa) * UMATm_(imx,1,mco,ks)  ! js
          END Do ! par
         end do

         do jcol=0,JB
            jjj= jcol
          Do mx=-MT,MT
            AJX(mx,jjj,ks)= YMAT(mx,jcol)  ! js
          END Do ! par
         end do

      END DO ! js=1,2

!-----
      do mx=2,MT
         AJX(-mx,0,:)= 0.d0  ! Sym and Asym at poles = 0 : mx >= 2
         AJX(+mx,0,:)= 0.d0
      end do
         AJX( 0 ,0,:)= 0.d0  ! Sym and Asym at poles = 0 : mx=0

      do j=0,JB
         unm(:,JBW-j)= AJX(:,j,2) - AJX(:,j,1)
         unm(:,    j)= AJX(:,j,2) + AJX(:,j,1)  ! sym
      end do
!----

!     if(adv_mx0==+1) then ! mx=0 by Fourier-fun

!-- all mx by spectral

          if(adv_mx0==+2) then

      CALL FFT_DFS_235_SC_FullGrid_y_trans( +1, TC1psi, ANM, JBW,-1)

      DO mx=-MT,MT
        if(mod(mx,2)==0) then
           do mj=0,JBW
              ANM(mx,mj)= -ANM(mx,mj)*(-mj)       ! (- d v h / d the ) 
           enddo
        else
           do mj=0,JBW
              ANM(mx,mj)= -ANM(mx,mj)*( mj)
           enddo
        endif
      END DO

      CALL FFT_DFS_235_SC_FullGrid_r_y_trans( -1, unm, ANM, JBW,-1)

      do mx=-MT,MT
      if(mx/=-1 .and. mx/=1) then
         unm(mx, 0 )= 0.d0  ! unm(m=0,2,3,...) == 0 at poles
         unm(mx,JBW)= 0.d0  ! unm(m=1)         /= 0 at poles
      endif
      end do

!-- all mx by spectral

      endif !----------------mx=0 by Fourier-fun

      do mx=-MT,MT
      do j= 1,JBW-1
         vnm(mx,j)=  TC1psi(-mx,j) * (-mx) / COSLAT0(j-JB,1)
      end do
         j= 0
         vnm(mx,j)= -unm(-mx,j)*(-mx)
         j=JBW
         vnm(mx,j)=  unm(-mx,j)*(-mx)
      end do

!--------------------------------------------------------------------C
      END SUBROUTINE PSI_to_uv_FEM
!*********************************************************************

!********************************************************************* 
!                                                                    *
!     18 MAY 2011 : Full-grids                                       *
!                                                                    *
!********************************************************************* 
      SUBROUTINE COS_SIN_LAT
!--------------------------------------------------------------------C
        use parameter_pi
        use parameter_dsize
        use parameter_fsize
        use common_enm1_CosSinLat
!--------------------------------------------------------------------C
        implicit none
!-----local-variables------------------------------------------------C
      real(kind=8) :: dthe= PI/JBW
      integer      :: j
!--------------------------------------------------------------------- 
!
!-- Half grid

      do j=-JB,JB1
         SINLAT5(j  )= DSIN((j+0.5d0)*dthe)
         COSLAT5(j,1)= DCOS((j+0.5d0)*dthe)
         COSLAT5(j,2)= COSLAT5(j,1)**2.d0
       end do

!-- Full grid

      do j=-JB,JB
         SINLAT0(j  )= DSIN((j      )*dthe)
         COSLAT0(j,1)= DCOS((j      )*dthe)
         COSLAT0(j,2)= COSLAT0(j,1)**2.d0
       end do
!
!--------------------------------------------------------------------C
      END SUBROUTINE COS_SIN_LAT
!********************************************************************* 

!
!*********************************************************************
!                                                                    *
!     19 MAY 2011                                                    *
!                                                                    *
!*********************************************************************
      SUBROUTINE TEST_FFT_HalfGrid
!--------------------------------------------------------------------C
        use parameter_pi
        use parameter_dsize
        use parameter_fsize
!--------------------------------------------------------------------C
        implicit none
!-----local-variables------------------------------------------------C
      real(kind=8), dimension(0:IB1,-JB:JB1) :: WORK1, WORK2
      real(kind=8), dimension(-MT:MT,0:JL)   :: V1, V2
      integer      :: mx,mj, jLast, itest,isign, i,j
      real(kind=8) :: error1, error2, criter, errsum
!--------------------------------------------------------------------C

      do mj=0,JL
      do mx=-MT,MT
         V1(mx,mj)= 1.0D0
      end do
      end do

              JLAST= JL
          if(JL.eq. JBW  ) then
              JLAST= JL-1
      do mx=-MT,MT,2
         V1(mx,JL)= 0.
      end do
       endif
          if(MT.eq.(IB/2)) then
      do mj=0,JL
         V1(MT,mj)= 0.
      end do
       endif

         CALL FFT_DFS_235_SC_HalfGrid( -1, WORK1, V1, JL, -1 )   ! is=1:->Wa, ip=1:cut

      DO ITEST=1,2
         CALL FFT_DFS_235_SC_HalfGrid( +1, WORK1, V2, JL, -1 )   ! is=1:->Wa, ip=1:cut
         CALL FFT_DFS_235_SC_HalfGrid( -1, WORK1, V2, JL, -1 )   ! is=1:->Wa, ip=1:cut
      END DO

         ISIGN= 1

         criter= 1.0D-9

         errsum= 0

      do mj=0,JLAST 
      do mx=-MT,MT,2
            error1= DABS( V1( mx,mj)-V2( mx,mj) )
         IF(error1.GT.criter) ISIGN= 0
         errsum= errsum + error1
      end do
      end do
      do mj=1,JL 
      do mx=-MT+1,MT,2
            error2= DABS( V1( mx,mj)-V2( mx,mj) )
         IF(error2.GT.criter) ISIGN= 0
         errsum= errsum + error2
      end do
      end do

          IF(MT.eq.(IB/2) .and. JL.eq.JBW) then

      do j=-JB,JB1
      do i=0,IB1
         WORK2(I,J)= 0.0D0
      end do
      end do
         WORK2(1, 1 )= 1.0D0
         WORK2(2,JB1)= 1.0D0

         CALL FFT_DFS_235_SC_HalfGrid( +1, WORK2, V2, JL, -1 )   ! is=1:->Wa, ip=1:cut
         CALL FFT_DFS_235_SC_HalfGrid( -1, WORK1, V2, JL, -1 )   ! is=1:->Wa, ip=1:cut

      do j=-JB,JB1
      do i=0,IB1
             error1= DABS( WORK1(I,J)-WORK2(I,J) )
          IF(error1.GT.criter) ISIGN= 0
         errsum= errsum + error1
      end do
      end do

       ENDIF

         errsum= errsum/( MT*2.0*JL + IB*JBW*(MT*2./IB) )

             write(*,*) '     ================================='
             write(*,*) '       error1 : WAVE1->GRID->WAVE2    '
             write(*,*) '       error2 : GRID1->WAVE->GRID2    '
             write(*,*) '       total ERROR=(error1+error2)/2  '
             write(*,*) '                                      '
             write(*,*) '       Half-Grid system               '
             write(*,*) '           using COS_FTN & SIN_FTN    '
             write(*,*) '                                      '
             write(*,*) '       m=even: COS_FFT, odd: SIN_FFT  '
             write(*,*) '                                      '
             write(*,*) '     ================================='

          IF(ISIGN.eq.1) THEN

             write(*,*) '     ================================='
             write(*,*) '     --------- Global Domain ---------'
             write(*,*) '                                      '
             write(*,*) '      TEST of FFT : It is All Right ! '
             write(*,*) '     ================================='
      ELSE
             write(*,*) '     ================================='
             write(*,*) '      TEST of FFT : Something wrong ! '
             write(*,*) '     ================================='
      ENDIF

          IF(MT.eq.(IB/2) .and. JL.eq.JBW) then
             write(*,*) '   1-WORK1(1,1) must be VERY near to 0.0'
             write(*,*) '   1-WORK1(1,1)= ', 1.D0-WORK1(1,1)
       ENDIF   
             write(*,*) '     ================================='
             write(*,*) '     NORMALIZED total ERROR in FFT is ',errsum
             write(*,*) '     ================================='
             write(*,*) '                 IB=',IB
             write(*,*) '                JBW=',JBW
             write(*,*) '                 MT=',MT
             write(*,*) '                 JL=',JL
             write(*,*) '     ================================='
!
!--------------------------------------------------------------------C
      END SUBROUTINE TEST_FFT_HalfGrid
!*********************************************************************
!
!
!*********************************************************************
!                                                                    *
!     26 MAY 2011 : m02=SIN, m13=COS                                 *
!                                                                    *
!*********************************************************************
      SUBROUTINE TEST_FFT_HalfGrid_r
!--------------------------------------------------------------------C
        use parameter_pi
        use parameter_dsize
        use parameter_fsize
!--------------------------------------------------------------------C
        implicit none
!-----local-variables------------------------------------------------C
      real(kind=8), dimension(0:IB1,-JB:JB1) :: WORK1, WORK2
      real(kind=8), dimension(-MT:MT,0:JL)   :: V1, V2
      integer      :: mx,mj, jLast, itest,isign, i,j
      real(kind=8) :: error1, error2, criter, errsum
!--------------------------------------------------------------------C

      do mj=0,JL
      do mx=-MT,MT
         V1(mx,mj)= 1.0D0
      end do
      end do

              JLAST= JL
          if(JL.eq. JBW  ) then
              JLAST= JL-1
      do mx=-MT+1,MT-1,2
         V1(mx,JL)= 0.
      end do
       endif
          if(MT.eq.(IB/2)) then
      do mj=0,JL
         V1(MT,mj)= 0.
      end do
       endif

         CALL FFT_DFS_235_SC_HalfGrid_r( -1, WORK1, V1, JL, -1 )   ! is=1:->Wa, ip=1:cut

      DO ITEST=1,2
         CALL FFT_DFS_235_SC_HalfGrid_r( +1, WORK1, V2, JL, -1 )   ! is=1:->Wa, ip=1:cut
         CALL FFT_DFS_235_SC_HalfGrid_r( -1, WORK1, V2, JL, -1 )   ! is=1:->Wa, ip=1:cut
      END DO

         ISIGN= 1

         criter= 1.0D-9

         errsum= 0

      do mj=1,JL 
      do mx=-MT,MT,2
            error1= DABS( V1( mx,mj)-V2( mx,mj) )
         IF(error1.GT.criter) ISIGN= 0
         errsum= errsum + error1
      end do
      end do
      do mj=0,JLAST 
      do mx=-MT+1,MT,2
            error2= DABS( V1( mx,mj)-V2( mx,mj) )
         IF(error2.GT.criter) ISIGN= 0
         errsum= errsum + error2
      end do
      end do

          IF(MT.eq.(IB/2) .and. JL.eq.JBW) then

      do j=-JB,JB1
      do i=0,IB1
         WORK2(I,J)= 0.0D0
      end do
      end do
         WORK2(1, 1 )= 1.0D0
         WORK2(2,JB1)= 1.0D0

         CALL FFT_DFS_235_SC_HalfGrid( +1, WORK2, V2, JL, -1 )   ! is=1:->Wa, ip=1:cut
         CALL FFT_DFS_235_SC_HalfGrid( -1, WORK1, V2, JL, -1 )   ! is=1:->Wa, ip=1:cut

      do j=-JB,JB1
      do i=0,IB1
             error1= DABS( WORK1(I,J)-WORK2(I,J) )
          IF(error1.GT.criter) ISIGN= 0
         errsum= errsum + error1
      end do
      end do

       ENDIF

         errsum= errsum/( MT*2.0*JL + IB*JBW*(MT*2./IB) )

             write(*,*) '     ================================='
             write(*,*) '       error1 : WAVE1->GRID->WAVE2    '
             write(*,*) '       error2 : GRID1->WAVE->GRID2    '
             write(*,*) '       total ERROR=(error1+error2)/2  '
             write(*,*) '                                      '
             write(*,*) '       Half-Grid : Half_Grid_reversed '
             write(*,*) '           using COS_FTN & SIN_FTN    '
             write(*,*) '                                      '
             write(*,*) '       m=even: SIN_FFT, odd: COS_FFT  '
             write(*,*) '                                      '
             write(*,*) '     ================================='

          IF(ISIGN.eq.1) THEN

             write(*,*) '     ================================='
             write(*,*) '     --------- Global Domain ---------'
             write(*,*) '                                      '
             write(*,*) '      TEST of FFT : It is All Right ! '
             write(*,*) '     ================================='
      ELSE
             write(*,*) '     ================================='
             write(*,*) '      TEST of FFT : Something wrong ! '
             write(*,*) '     ================================='
      ENDIF

          IF(MT.eq.(IB/2) .and. JL.eq.JBW) then
             write(*,*) '   1-WORK1(1,1) must be VERY near to 0.0'
             write(*,*) '   1-WORK1(1,1)= ', 1.D0-WORK1(1,1)
       ENDIF   
             write(*,*) '     ================================='
             write(*,*) '     NORMALIZED total ERROR in FFT is ',errsum
             write(*,*) '     ================================='
             write(*,*) '                 IB=',IB
             write(*,*) '                JBW=',JBW
             write(*,*) '                 MT=',MT
             write(*,*) '                 JL=',JL
             write(*,*) '     ================================='
!
!--------------------------------------------------------------------C
      END SUBROUTINE TEST_FFT_HalfGrid_r
!*********************************************************************
!
!
!*********************************************************************
!                                                                    *
!     18 MAY 2011 : (-JB:JB) grids                                   *
!                 : m02 -> COS trans, m13 -> SIN trans               *
!                                                                    *
!*********************************************************************
      SUBROUTINE TEST_FFT_FullGrid
!--------------------------------------------------------------------C
        use parameter_pi
        use parameter_dsize
        use parameter_fsize
!--------------------------------------------------------------------C
        implicit none
!-----local-variables------------------------------------------------C
      real(kind=4), dimension(0:IB1,-JB:JB) :: SORK1, SORK2
      real(kind=8), dimension(0:IB1,-JB:JB) :: WORK1, WORK2
      real(kind=8), dimension(-MT:MT,0:JL)  :: V1, V2
      integer      :: mx,mj, jLast, itest,isign, i,j
      real(kind=8) :: error1, error2, criter, errsum
!--------------------------------------------------------------------C

         V1(: ,: )= 1.d0

      do mx=-MT+1,MT,2
         V1(mx, 0)= 0.d0
           if(JL==JBW) then
         V1(mx,JL)= 0.d0
           endif
      end do

                  JLAST= JL
      if(JL==JBW) JLAST= JL-1

         CALL FFT_DFS_235_SC_FullGrid( -1, WORK1, V1, JL, -1 )   ! is=1:->Wa, ip=1:cut

      DO ITEST=1,2
         CALL FFT_DFS_235_SC_FullGrid( +1, WORK1, V2, JL, -1 )   ! is=1:->Wa, ip=1:cut
         CALL FFT_DFS_235_SC_FullGrid( -1, WORK1, V2, JL, -1 )   ! is=1:->Wa, ip=1:cut
      END DO

         ISIGN= 1

         criter= 1.0D-9

         errsum= 0

      do mj=0,JL
      do mx=-MT,MT,2
            error1= DABS( V1( mx,mj)-V2( mx,mj) )
         IF(error1.GT.criter) ISIGN= 0
         errsum= errsum + error1
      end do
      end do

      do mj=1,JLAST
      do mx=-MT+1,MT,2
            error2= DABS( V1( mx,mj)-V2( mx,mj) )
         IF(error2.GT.criter) ISIGN= 0
         errsum= errsum + error2
      end do
      end do

          IF(MT.eq.(IB/2) .and. JL.eq.JBW) then

      do j=-JB,JB1
      do i=0,IB1
         WORK2(I,J)= 0.0D0
      end do
      end do
         WORK2(1, 1 )= 1.0D0
         WORK2(2,JB1)= 1.0D0

         CALL FFT_DFS_235_SC_FullGrid( +1, WORK2, V2, JL, -1 )   ! is=1:->Wa, ip=1:cut
         CALL FFT_DFS_235_SC_FullGrid( -1, WORK1, V2, JL, -1 )   ! is=1:->Wa, ip=1:cut

      do j=-JB,JB1
      do i=0,IB1
             error1= DABS( WORK1(I,J)-WORK2(I,J) )
          IF(error1.GT.criter) ISIGN= 0
         errsum= errsum + error1
      end do
      end do

       ENDIF

         errsum= errsum/( MT*2.0*JL + IB*JBW*(MT*2./IB) )

             write(*,*) '     ================================='
             write(*,*) '       error1 : WAVE1->GRID->WAVE2    '
             write(*,*) '       error2 : GRID1->WAVE->GRID2    '
             write(*,*) '       total ERROR=(error1+error2)/2  '
             write(*,*) '                                      '
             write(*,*) '       Full-Grid system               '
             write(*,*) '       Full-Grid system               '
             write(*,*) '                                      '
             write(*,*) '       m=even: COS_FFT, odd: SIN_FFT  '
             write(*,*) '                                      '
             write(*,*) '     ================================='

          IF(ISIGN.eq.1) THEN

             write(*,*) '     ================================='
             write(*,*) '     --------- Global Domain ---------'
             write(*,*) '                                      '
             write(*,*) '      TEST of FFT : It is All Right ! '
             write(*,*) '     ================================='
      ELSE
             write(*,*) '     ================================='
             write(*,*) '      TEST of FFT : Something wrong ! '
             write(*,*) '     ================================='
      ENDIF

          IF(MT.eq.(IB/2) .and. JL.eq.JBW) then
             write(*,*) '   1-WORK1(1,1) must be VERY near to 0.0'
             write(*,*) '   1-WORK1(1,1)= ', 1.D0-WORK1(1,1)
       ENDIF   
             write(*,*) '     ================================='
             write(*,*) '     NORMALIZED total ERROR in FFT is ',errsum
             write(*,*) '     ================================='
             write(*,*) '                 IB=',IB
             write(*,*) '                JBW=',JBW
             write(*,*) '                 MT=',MT
             write(*,*) '                 JL=',JL
             write(*,*) '     ================================='
!
!--------------------------------------------------------------------C
      END SUBROUTINE TEST_FFT_FullGrid
!*********************************************************************

!*********************************************************************
!                                                                    *
!     18 MAY 2011 : (-JB:JB) grids                                   *
!                 : m0, 135 -> COS trans, m24 -> SIN trans           *
!                                                                    *
!*********************************************************************
      SUBROUTINE TEST_FFT_FullGrid_r
!--------------------------------------------------------------------C
        use parameter_pi
        use parameter_dsize
        use parameter_fsize
!--------------------------------------------------------------------C
        implicit none
!-----local-variables------------------------------------------------C
      real(kind=4), dimension(0:IB1,-JB:JB) :: SORK1, SORK2
      real(kind=8), dimension(0:IB1,-JB:JB) :: WORK1, WORK2
      real(kind=8), dimension(-MT:MT,0:JL)  :: V1, V2
      integer      :: mx,mj, jLast, itest,isign, i,j
      real(kind=8) :: error1, error2, criter, errsum
!--------------------------------------------------------------------C

         V1(: ,: )= 1.d0

      do mx=-MT,MT,2           ! SIN trans
         V1( mx, 0)= 0.d0
           if(JL==JBW) then
         V1( mx,JL)= 0.d0
           endif
      end do

                  JLAST= JL
      if(JL==JBW) JLAST= JL-1

         CALL FFT_DFS_235_SC_FullGrid_r( -1, WORK1, V1, JL, -1 )   ! is=1:->Wa, ip=1:cut

      DO ITEST=1,2
         CALL FFT_DFS_235_SC_FullGrid_r( +1, WORK1, V2, JL, -1 )   ! is=1:->Wa, ip=1:cut
         CALL FFT_DFS_235_SC_FullGrid_r( -1, WORK1, V2, JL, -1 )   ! is=1:->Wa, ip=1:cut
      END DO

         ISIGN= 1

         criter= 1.0D-9

         errsum= 0

      do mj=1,JLAST
      do mx=-MT,MT,2
            error1= DABS( V1( mx,mj)-V2( mx,mj) )
         IF(error1.GT.criter) ISIGN= 0
         errsum= errsum + error1
      end do
      end do

      do mj=0,JL
      do mx=-MT+1,MT,2
            error2= DABS( V1( mx,mj)-V2( mx,mj) )
         IF(error2.GT.criter) ISIGN= 0
         errsum= errsum + error2
      end do
      end do

          IF(MT.eq.(IB/2) .and. JL.eq.JBW) then

      do j=-JB,JB
      do i=0,IB1
         WORK2(I,J)= 0.0D0
      end do
      end do
         WORK2(1, 1 )= 1.0D0
         WORK2(2,JB1)= 1.0D0

         CALL FFT_DFS_235_SC_FullGrid_r( +1, WORK2, V2, JL, -1 )   ! is=1:->Wa, ip=1:cut
         CALL FFT_DFS_235_SC_FullGrid_r( -1, WORK1, V2, JL, -1 )   ! is=1:->Wa, ip=1:cut

      do j=-JB,JB
      do i=0,IB1
             error1= DABS( WORK1(I,J)-WORK2(I,J) )
          IF(error1.GT.criter) ISIGN= 0
         errsum= errsum + error1
      end do
      end do

       ENDIF

         errsum= errsum/( MT*2.0*JL + IB*JBW*(MT*2./IB) )

             write(*,*) '     ================================='
             write(*,*) '       error1 : WAVE1->GRID->WAVE2    '
             write(*,*) '       error2 : GRID1->WAVE->GRID2    '
             write(*,*) '       total ERROR=(error1+error2)/2  '
             write(*,*) '                                      '
             write(*,*) '       Full-Grid system               '
             write(*,*) '                                      '
             write(*,*) '       m=even: SIN_FFT, odd: COS_FFT  '
             write(*,*) '                                      '
             write(*,*) '     ================================='

          IF(ISIGN.eq.1) THEN

             write(*,*) '     ================================='
             write(*,*) '     --------- Global Domain ---------'
             write(*,*) '                                      '
             write(*,*) '      TEST of FFT : It is All Right ! '
             write(*,*) '     ================================='
      ELSE
             write(*,*) '     ================================='
             write(*,*) '      TEST of FFT : Something wrong ! '
             write(*,*) '     ================================='
      ENDIF

          IF(MT.eq.(IB/2) .and. JL.eq.JBW) then
             write(*,*) '   1-WORK1(1,1) must be VERY near to 0.0'
             write(*,*) '   1-WORK1(1,1)= ', 1.D0-WORK1(1,1)
       ENDIF   
             write(*,*) '     ================================='
             write(*,*) '     NORMALIZED total ERROR in FFT is ',errsum
             write(*,*) '     ================================='
             write(*,*) '                 IB=',IB
             write(*,*) '                JBW=',JBW
             write(*,*) '                 MT=',MT
             write(*,*) '                 JL=',JL
             write(*,*) '     ================================='
!
!--------------------------------------------------------------------C
      END SUBROUTINE TEST_FFT_FullGrid_r
!*********************************************************************

!
!*********************************************************************
!                                                                    *
!     02 JUN 2011 : SUB FFT_..._HalfGrid, JT+1                       *
!     25 MAY 2011 : inefficiency of factor 2 -> made efficient       *
!     19 MAY 2011 : m024 -> COS trans, m135 -> SIN trans             *
!                                                                    *
!*********************************************************************
      SUBROUTINE FFT_DFS_235_SC_HalfGrid( isign, PSI, ANM, JT, ipole ) ! is=1:->Wa, ip=1:cut
!--------------------------------------------------------------------C
        use parameter_pi
        use parameter_dsize
        use parameter_fsize
        use common_enm1_CosSinLat           ! 25 OCT 2010: m024 COS, m135 SIN
!--------------------------------------------------------------------C
        implicit none
      integer      :: isign, JT, ipole
      real(kind=8) :: PSI(0:IB1,-JB:JB1), ANM(-MT:MT,0:JT)
!-----local-variables------------------------------------------------C
      real(kind=8) :: mxx2(0:JBW,2)                               ! 2001.07.06
      real(kind=8) :: SHIFTC(0:JBW), SHIFTS(0:JBW)                 ! 2001.07.06
      real(kind=8) :: TRIGSIB(IB*2), TRIGSJBW(JBW*2)
!-----
      real(kind=8) :: data_COS(-MTH:MTH,1:JBW), temp_COS(-MTH:MTH)
      real(kind=8) :: data_SIN(-MTH:MTH,1:JBW), temp_SIN(-MTH:MTH)         ! mx=-MT,MT -> half
      real(kind=8) :: partRE_COS(-MTH:MTH,0:JB)
      real(kind=8) :: partIM_COS(-MTH:MTH,0:JB)
      real(kind=8) :: partRE_SIN(-MTH:MTH,0:JB)
      real(kind=8) :: partIM_SIN(-MTH:MTH,0:JB)
      real(kind=8) :: SINHF(0:JB), COSPK(0:JB), SINPK(0:JB)             ! mx= all
!-----
      real(kind=8) :: ALON(0:JB,0:IB1) , BLON(0:JB,0:IB1)
      real(kind=8) :: ALAS(0:MTH,0:IB1), BLAS(0:MTH,0:IB1)
      real(kind=8) :: ALAC(0:MTH,0:IB1), BLAC(0:MTH,0:IB1)
!-----
      real(kind=8) :: FWAVEJ(-MT:MT,-JB:JB )
!-----
      CHARACTER(len=4) :: FFTOPT
      LOGICAL :: JUSDOIT=.TRUE.
!-----
      integer      :: mx,mj,mw,i,j,k,j2n,mlast,kev,kod,ibmx,jjbp1
      real(kind=8) :: pin, aa, bb
!--------------------------------------------------------------------C

      IF(JUSDOIT) THEN
         JUSDOIT=.FALSE.

         do mx=0,JBW    ! 2001.07.06
            mxx2(mx,1)= mx*2
            mxx2(mx,2)= mx*2+1
         end do

                PIN= PI/(JBW*2)  ! 05 MAR 2008
         do k=0,JBW    
            bb= PIN*dble(k)
            SHIFTC(k)= DCOS(bb)
            SHIFTS(k)= DSIN(bb)
         end do
!---
              FFTOPT='P235'
              J2N= 1
        do k=1,20
              J2N= J2N*2
           if(IB.eq.J2N) then
!             FFTOPT='P222'
              EXIT
           endif
        end do        ! 2004.04.02      
           write(*,*) ' IB, FFTSOPT=', IB, FFTOPT   

         CALL GPFASET_8_VEC(TRIGSIB ,IB )
         CALL GPFASET_8_VEC(TRIGSJBW,JBW)  ! for 2,3,5 prime factor 

            PIN= PI/JBW

         do j=0,JB                         ! For SINE and COSINE transform 
            aa= PIN*(j+0.5D-00)
            SINHF(j)= DSIN(aa)
         end do
         do k=0,JB
            bb= PIN*dble(k)
            COSPK(k)= DCOS(bb)
            SINPK(k)= DSIN(bb)
         end do

      ENDIF

!----------------------------------------------------------------------C

          IF(JT.gt. JBW  )  then  ! 05 MAR 2008
             write(*,*) ' ==   Invalid range of Y-transform   =='
             write(*,*) ' == JT must not be greater than IB/2 =='
             stop
       ENDIF

!-----------------------------

                          MLAST= MT         ! A part transform for Y-dir
         if(MT.eq.(IB/2)) MLAST= MT-1       ! Full range transform for Y-dir

         do 9211 J=-JB,JB    ! reset
         do 9211 mx=-MT,MT 
 9211       FWAVEJ(mx,J)= 0.

!=============================
          IF(isign.EQ.+1) THEN
!=============================

!-----(I,J)->(mx,J)

         do I=0,IB1
         Do J=0,JB1 
            BLON( J,I)= PSI(I, J )
            ALON( J,I)= PSI(I,-J )
         end do
            ALON(JB,I)= PSI(I,-JB)
            BLON(JB,I)= 0.d0
            BLON( 0,I)= 0.d0      ! to avoid the same point 
         END Do
         
         CALL GPFA_8_VEC( ALON,BLON,TRIGSIB, 1, IB, IB, 1, isign,JB,JB )

         do mx=1,MLAST  
                      kev= mxx2(mx,1) ! mx*2
                      kod= mxx2(mx,2) ! kev+1
            IBmx= IB-mx
         Do J=0,JB
            FWAVEJ(-mx, J)= ( BLON(J,mx)+BLON(J,IBmx))/IB ! FWAVEJ(*,JB)= 0.
            FWAVEJ(-mx,-J)= ( ALON(J,mx)+ALON(J,IBmx))/IB
            FWAVEJ( mx, J)= (-ALON(J,mx)+ALON(J,IBmx))/IB
            FWAVEJ( mx,-J)= ( BLON(J,mx)-BLON(J,IBmx))/IB
         END Do ! par 
         end do
         Do J=0,JB
            FWAVEJ( 0 , J)=    BLON(J,0 )/IB
            FWAVEJ( 0 ,-J)=    ALON(J,0 )/IB      ! always A is the last
                if(MT.eq.(IB/2)) then
            FWAVEJ(-MT, J)=    BLON(J,MT)/IB
            FWAVEJ(-MT,-J)=    ALON(J,MT)/IB
             endif
         END Do ! par 

!-----(mx,J)->(mx,mj)

            data_SIN( :,:)= 0.d0
            data_COS( :,:)= 0.d0
         Do J=-JB,JB1
            JJBP1= J+JB+1
         do mx=-MT,MT,2
                     mw= (mx+0)/2
            data_COS(mw,JJBP1)= FWAVEJ(mx,J)      ! 05 MAR 2008: m0=COS, m1=SIN, m2=COS
!           data_COS(mx,JJBP1)= FWAVEJ(mx,J)      ! 05 MAR 2008: m0=COS, m1=SIN, m2=COS
         end do
         do mx=-MT+1,MT-1,2
                     mw= (mx+1)/2
            data_SIN(mw,JJBP1)= FWAVEJ(mx,J)      ! 05 MAR 2008: m0=COS, m1=SIN, m2=COS
!           data_SIN(mx,JJBP1)= FWAVEJ(mx,J)      ! 05 MAR 2008: m0=COS, m1=SIN, m2=COS
         end do
         END Do

      CALL COS_FTN                                                      &
      ( data_COS, partRE_COS, partIM_COS, temp_COS, SINHF, COSPK, SINPK,&
       ALAC, BLAC, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )

      CALL SIN_FTN                                                      &
      ( data_SIN, partRE_SIN, partIM_SIN, temp_SIN, SINHF, COSPK, SINPK,&
       ALAS, BLAS, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )
!
                    i= 0
         if(JT<JBW) i= 1            ! 02 JUN 2011

         Do mj=1,JT+i
         do mx=-MT,MT,2
                                   mw= (mx+0)/2
            ANM(mx,mj-1)= data_COS(mw,mj)
!           ANM(mx,mj-1)= data_COS(mx,mj)
         end do
         do mx=-MT+1,MT-1,2
                                   mw= (mx+1)/2
            ANM(mx,mj  )= data_SIN(mw,mj)
!           ANM(mx,mj  )= data_SIN(mx,mj)
         end do
         END Do

!e 05 MAR 2008

!------
         do mx=-MT+1,MT,2        ! 19 MAY 2011
            ANM( mx,0)= 0.
         end do
             if(JT.eq. JBW  ) then
         do mx=-MT  ,MT,2
            ANM(mx,JT)= 0.
         end do
          endif   
             if(MT.eq.(IB/2)) then
         do mj=0,JT
            ANM(MT,mj)= 0.
         end do
          endif

!=============================
      ELSEIF(isign.EQ.-1) THEN
!=============================
!
         do mx=-MT+1,MT,2        ! 19 MAY 2011
            ANM( mx,0)= 0.
         end do
             if(JT.eq. JBW  ) then
         do mx=-MT  ,MT,2
            ANM(mx,JT)= 0.
         end do
          endif   
             if(MT.eq.(IB/2)) then
         do mj=0,JT
            ANM(MT,mj)= 0.
         end do
          endif

!-----(mx,mj)->(mx,J)

!b 05 MAR 2008

            data_SIN( :, :)= 0.d0
            data_COS( :, :)= 0.d0

                    i= 0
         if(JT<JBW) i= 1            ! 02 JUN 2011

         Do mj=1,JT+i
         do mx=-MT,MT,2
                     mw= (mx+0)/2
            data_COS(mw,mj)= ANM(mx,mj-1)
!           data_COS(mx,mj)= ANM(mx,mj-1)
         end do
         do mx=-MT+1,MT-1,2
                     mw= (mx+1)/2
            data_SIN(mw,mj)= ANM(mx,mj  )
!           data_SIN(mx,mj)= ANM(mx,mj  )
         end do
         END Do

      CALL COS_FTN                                                      &
      ( data_COS, partRE_COS, partIM_COS, temp_COS, SINHF, COSPK, SINPK,&
       ALAC, BLAC, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )
!
      CALL SIN_FTN                                                      &
      ( data_SIN, partRE_SIN, partIM_SIN, temp_SIN, SINHF, COSPK, SINPK,&
       ALAS, BLAS, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )
!
         Do J=-JB,JB1
            JJBP1= J+JB+1
         do mx=-MT,MT,2
                                   mw= (mx+0)/2
            FWAVEJ(mx,J)= data_COS(mw,JJBP1)
!           FWAVEJ(mx,J)= data_COS(mx,JJBP1)
         end do
         do mx=-MT+1,MT-1,2
                                   mw= (mx+1)/2
            FWAVEJ(mx,J)= data_SIN(mw,JJBP1)
!           FWAVEJ(mx,J)= data_SIN(mx,JJBP1)
         end do
         END Do

!        IF(ipole.EQ.+1) CALL POLECUT
!
!-----(mx,J)->(I,J)

         do I=0,IB1
         dO J=0,JB
            BLON(J,I)= 0.
            ALON(J,I)= 0.
         end do
         end do

         do mx=1,MLAST  
                      kev= mxx2(mx,1) ! mx*2
                      kod= mxx2(mx,2) ! kev+1
            IBmx= IB-mx
         Do J=1,JB
            BLON(J,  mx)= ( FWAVEJ( mx,-J)+FWAVEJ(-mx, J))/2.d0
            BLON(J,IBmx)= (-FWAVEJ( mx,-J)+FWAVEJ(-mx, J))/2.d0
            ALON(J,  mx)= ( FWAVEJ(-mx,-J)-FWAVEJ( mx, J))/2.d0
            ALON(J,IBmx)= ( FWAVEJ(-mx,-J)+FWAVEJ( mx, J))/2.d0
         END Do
            J=0
            BLON(J,  mx)= ( FWAVEJ( mx,-J)               )/2.d0
            BLON(J,IBmx)= (-FWAVEJ( mx,-J)               )/2.d0
            ALON(J,  mx)= ( FWAVEJ(-mx,-J)               )/2.d0
            ALON(J,IBmx)= ( FWAVEJ(-mx,-J)               )/2.d0
         end do ! mx=
            mx=0
         Do J=0,JB
            BLON(J,  mx)=   FWAVEJ( mx, J)
            ALON(J,  mx)=   FWAVEJ( mx,-J)
         END Do
            BLON(0,  mx)=   0.  ! to avoid the same input
                if(MT.eq.(IB/2)) then
         Do J=0,JB
            BLON(J,  MT)=   FWAVEJ(-MT, J)
            ALON(J,  MT)=   FWAVEJ(-MT,-J)
         END Do
            BLON(0,  MT)=   0.  ! to avoid the same input
             endif

         CALL GPFA_8_VEC( ALON,BLON,TRIGSIB, 1, IB, IB, 1, isign,JB,JB )

         do I=0,IB1
         DO J=0,JB1
            PSI(I, J )= BLON(J ,I)
            PSI(I,-J )= ALON(J ,I)
         end do
            PSI(I,-JB)= ALON(JB,I)
         END DO

       ENDIF                  
!
!--------------------------------------------------------------------C
      END SUBROUTINE FFT_DFS_235_SC_HalfGrid
!*********************************************************************

!
!*********************************************************************
!                                                                    c
!     25 MAY 2011 : inefficiency of factor 2 -> made efficient       c
!     12 MAY 2011 : call COS_FTN_FullGrid, and SIN                   c
!                                                                    c
!                 : inefficiency of factor 2 remains                 c
!                 : can be cured by MT -> MT/2 for args COS_FullGrid c
!                                                                    c
!*********************************************************************
      SUBROUTINE FFT_DFS_235_SC_FullGrid( isign, PSI, ANM, JT, ipole ) ! is=1:->Wa, ip=1:cut
!--------------------------------------------------------------------C
        use parameter_pi
        use parameter_dsize
        use parameter_fsize
        use common_enm1_CosSinLat           ! 25 OCT 2010: m024 COS, m135 SIN
!--------------------------------------------------------------------C
        implicit none
      integer      :: isign, JT, ipole
      real(kind=8) :: PSI(0:IB1,-JB:JB), ANM(-MT:MT,0:JT)
!-----local-variables------------------------------------------------C
      real(kind=8) :: mxx2(0:JBW,2)                               ! 2001.07.06
      real(kind=8) :: SHIFTC(0:JBW), SHIFTS(0:JBW)                 ! 2001.07.06
      real(kind=8) :: TRIGSIB(IB*2), TRIGSJBW(JBW*2)
!-----
!-----
      real(kind=8) :: data_COS(-MTH:MTH,0:JBW), temp_COS(-MTH:MTH)
      real(kind=8) :: data_SIN(-MTH:MTH,0:JBW), temp_SIN(-MTH:MTH)         ! mx=-MT,MT -> half
      real(kind=8) :: partRE_COS(-MTH:MTH,0:JB)
      real(kind=8) :: partIM_COS(-MTH:MTH,0:JB)
      real(kind=8) :: partRE_SIN(-MTH:MTH,0:JB)
      real(kind=8) :: partIM_SIN(-MTH:MTH,0:JB)
      real(kind=8) :: SINHF(0:JB), COSHF(0:JB)
      real(kind=8) :: COSPK(0:JB), SINPK(0:JB)             ! mx= all
!-----
      real(kind=8) :: ALON(0:JB,0:IB1)  , BLON(0:JB,0:IB1)
      real(kind=8) :: ALAC(0:MTH,0:JBW1), BLAC(0:MTH,0:JBW1)
      real(kind=8) :: ALAS(0:MTH,0:JBW1), BLAS(0:MTH,0:JBW1)
!-----
      real(kind=8) :: FWAVEJ(-MT:MT,-JB:JB)
!-----
      CHARACTER(len=4) :: FFTOPT
      LOGICAL :: JUSDOIT=.TRUE.
!-----
      integer      :: mx,mj,mw,i,j,k,j2n,mlast,kev,kod,ibmx,jjbp1
      real(kind=8) :: pin, aa, bb
!--------------------------------------------------------------------C

      IF(JUSDOIT) THEN
         JUSDOIT=.FALSE.

         do mx=0,JBW    ! 2001.07.06
            mxx2(mx,1)= mx*2
            mxx2(mx,2)= mx*2+1
         end do

                PIN= PI/(JBW*2)  ! 05 MAR 2008
         do k=0,JBW    
            bb= PIN*dble(k)
            SHIFTC(k)= DCOS(bb)
            SHIFTS(k)= DSIN(bb)
         end do
!---
              FFTOPT='P235'
              J2N= 1
        do k=1,20
              J2N= J2N*2
           if(IB.eq.J2N) then
!             FFTOPT='P222'
              EXIT
           endif
        end do        ! 2004.04.02      
           write(*,*) ' IB, FFTSOPT=', IB, FFTOPT   

         CALL GPFASET_8_VEC(TRIGSIB ,IB )
         CALL GPFASET_8_VEC(TRIGSJBW,JBW)  ! for 2,3,5 prime factor 

            PIN= PI/JBW

         do j=0,JB                         ! For SINE and COSINE transform 
            aa= PIN*(j + 0.d0 )            ! 00-grid, full-grid, unstaggered grid
            SINHF(j)= DSIN(aa)
            COSHF(j)= DCOS(aa)
         end do
         do k=0,JB
            bb= PIN*dble(k)
            COSPK(k)= DCOS(bb)
            SINPK(k)= DSIN(bb)
         end do

      ENDIF

!----------------------------------------------------------------------C

          IF(JT.gt. JBW  )  then  ! 05 MAR 2008
             write(*,*) ' ==   Invalid range of Y-transform   =='
             write(*,*) ' == JT must not be greater than IB/2 =='
             stop
       ENDIF

!-----------------------------

                          MLAST= MT         ! A part transform for Y-dir
         if(MT.eq.(IB/2)) MLAST= MT-1       ! Full range transform for Y-dir

         do 9211 J=-JB,JB    ! reset
         do 9211 mx=-MT,MT 
 9211       FWAVEJ(mx,J)= 0.

!=============================
          IF(isign.EQ.+1) THEN
!=============================

!-----(I,J)->(mx,J)

         do I=0,IB1
         Do J=0,JB ! JB1 
            BLON( J,I)= PSI(I, J )
            ALON( J,I)= PSI(I,-J )
         end do
!           ALON(JB,I)= PSI(I,-JB)
!           BLON(JB,I)= 0.d0
            BLON( 0,I)= 0.d0      ! to avoid the same point 
         END Do
         
         CALL GPFA_8_VEC( ALON,BLON,TRIGSIB, 1, IB, IB, 1, isign,JB,JB )

         do mx=1,MLAST  
                      kev= mxx2(mx,1) ! mx*2
                      kod= mxx2(mx,2) ! kev+1
            IBmx= IB-mx
         Do J=0,JB
            FWAVEJ(-mx, J)= ( BLON(J,mx)+BLON(J,IBmx))/IB
            FWAVEJ(-mx,-J)= ( ALON(J,mx)+ALON(J,IBmx))/IB
            FWAVEJ( mx, J)= (-ALON(J,mx)+ALON(J,IBmx))/IB
            FWAVEJ( mx,-J)= ( BLON(J,mx)-BLON(J,IBmx))/IB
         END Do ! par 
         end do
         Do J=0,JB
            FWAVEJ( 0 , J)=    BLON(J,0 )/IB
            FWAVEJ( 0 ,-J)=    ALON(J,0 )/IB      ! always A is the last
                if(MT.eq.(IB/2)) then
            FWAVEJ(-MT, J)=    BLON(J,MT)/IB
            FWAVEJ(-MT,-J)=    ALON(J,MT)/IB
             endif
         END Do ! par 
!--
         do mx=1,MT               ! at poles      ! 18 MAY 2011
!           FWAVEJ(-mx,-JB)= 0.d0
!           FWAVEJ(-mx,+JB)= 0.d0
!           FWAVEJ( mx,-JB)= 0.d0
!           FWAVEJ( mx,+JB)= 0.d0
         end do   

!        IF(ipole.EQ.+1) CALL POLECUT

!-----(mx,J)->(mx,mj)

            data_SIN( :,:)= 0.d0
            data_COS( :,:)= 0.d0
         Do J=-JB,JB
            JJBP1= J+JB
         do mx=-MT,MT,2
                     mw= (mx+0)/2
            data_COS(mw,JJBP1)= FWAVEJ(mx,J)      ! 05 MAR 2008: m0=COS, m1=SIN, m2=COS
!           data_COS(mx,JJBP1)= FWAVEJ(mx,J)      ! 05 MAR 2008: m0=COS, m1=SIN, m2=COS
         end do
         do mx=-MT+1,MT-1,2
                     mw= (mx+1)/2
            data_SIN(mw,JJBP1)= FWAVEJ(mx,J)      ! 05 MAR 2008: m0=COS, m1=SIN, m2=COS
!           data_SIN(mx,JJBP1)= FWAVEJ(mx,J)      ! 05 MAR 2008: m0=COS, m1=SIN, m2=COS
         end do
         END Do ! J=
!
      CALL COS_FTN_FullGrid                                             &
      ( data_COS, partRE_COS, partIM_COS, temp_COS, SINHF, COSHF,       &
       COSPK, SINPK,                                                    &
       ALAC, BLAC, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )            

      CALL SIN_FTN_FullGrid                                             &
      ( data_SIN, partRE_SIN, partIM_SIN, temp_SIN, SINHF, COSHF,       &
       COSPK, SINPK,                                                    &
       ALAS, BLAS, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )

         do mj=0,JT
         do mx=-MT,MT,2
                                 mw= (mx+0)/2
            ANM(mx,mj)= data_COS(mw,mj)
!           ANM(mx,mj)= data_COS(mx,mj)
         end do
         do mx=-MT+1,MT-1,2
                                 mw= (mx+1)/2
            ANM(mx,mj)= data_SIN(mw,mj)
!           ANM(mx,mj)= data_SIN(mx,mj)
         end do
         END Do ! mj=

!------
         do mx=-MT+1,MT,2            ! 10 MAY 2011
            ANM( mx,0)= 0.
         end do
             if(JT.eq. JBW  ) then
         do mx=-MT+1,MT,2
            ANM(mx,JT)= 0.
         end do
          endif
             if(MT.eq.(IB/2)) then
         do mj=0,JT
            ANM(MT,mj)= 0.
         end do
          endif

!=============================
      ELSEIF(isign.EQ.-1) THEN
!=============================
!
         do mx=-MT+1,MT,2            ! 10 MAY 2011
            ANM( mx,0)= 0.
         end do
             if(JT.eq. JBW  ) then
         do mx=-MT+1,MT,2
            ANM(mx,JT)= 0.
         end do
          endif
             if(MT.eq.(IB/2)) then
         do mj=0,JT
            ANM(MT,mj)= 0.
         end do
          endif

!-----(mx,mj)->(mx,J)

            data_SIN( :, :)= 0.d0
            data_COS( :, :)= 0.d0

         Do mj=0,JT
         do mx=-MT,MT,2
                     mw= (mx+0)/2
            data_COS(mw,mj)= ANM(mx,mj)
!           data_COS(mx,mj)= ANM(mx,mj)
         end do
         do mx=-MT+1,MT-1,2
                     mw= (mx+1)/2
            data_SIN(mw,mj)= ANM(mx,mj)
!           data_SIN(mx,mj)= ANM(mx,mj)
         end do
         END Do ! mj=

      CALL COS_FTN_FullGrid                                             &
      ( data_COS, partRE_COS, partIM_COS, temp_COS, SINHF, COSHF,       &
       COSPK, SINPK,                                                    &
       ALAC, BLAC, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )

      CALL SIN_FTN_FullGrid                                             &
      ( data_SIN, partRE_SIN, partIM_SIN, temp_SIN, SINHF, COSHF,       &
       COSPK, SINPK,                                                    &
       ALAS, BLAS, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )

         Do J=-JB,JB
            JJBP1= J+JB
         do mx=-MT,MT,2
                                   mw= (mx+0)/2
            FWAVEJ(mx,J)= data_COS(mw,JJBP1)
!           FWAVEJ(mx,J)= data_COS(mx,JJBP1)
         end do
         do mx=-MT+1,MT-1,2
                                   mw= (mx+1)/2
            FWAVEJ(mx,J)= data_SIN(mw,JJBP1)
!           FWAVEJ(mx,J)= data_SIN(mx,JJBP1)
         end do
         END Do ! J=
!--
         do mx=1,MT               ! at poles      ! 18 MAY 2011
!           FWAVEJ(-mx,-JB)= 0.d0
!           FWAVEJ(-mx,+JB)= 0.d0
!           FWAVEJ( mx,-JB)= 0.d0
!           FWAVEJ( mx,+JB)= 0.d0
         end do   

!        IF(ipole.EQ.+1) CALL POLECUT
!
!-----(mx,J)->(I,J)

         do I=0,IB1
         dO J=0,JB
            BLON(J,I)= 0.
            ALON(J,I)= 0.
         end do
         end do

         do mx=1,MLAST  
                      kev= mxx2(mx,1) ! mx*2
                      kod= mxx2(mx,2) ! kev+1
            IBmx= IB-mx
         Do J=1,JB
            BLON(J,  mx)= ( FWAVEJ( mx,-J)+FWAVEJ(-mx, J))/2.d0
            BLON(J,IBmx)= (-FWAVEJ( mx,-J)+FWAVEJ(-mx, J))/2.d0
            ALON(J,  mx)= ( FWAVEJ(-mx,-J)-FWAVEJ( mx, J))/2.d0
            ALON(J,IBmx)= ( FWAVEJ(-mx,-J)+FWAVEJ( mx, J))/2.d0
         END Do
            J=0
            BLON(J,  mx)= ( FWAVEJ( mx,-J)               )/2.d0
            BLON(J,IBmx)= (-FWAVEJ( mx,-J)               )/2.d0
            ALON(J,  mx)= ( FWAVEJ(-mx,-J)               )/2.d0
            ALON(J,IBmx)= ( FWAVEJ(-mx,-J)               )/2.d0
         end do ! mx=
            mx=0
         Do J=0,JB
            BLON(J,  mx)=   FWAVEJ( mx, J)
            ALON(J,  mx)=   FWAVEJ( mx,-J)
         END Do
            BLON(0,  mx)=   0.  ! to avoid the same input
                if(MT.eq.(IB/2)) then
         Do J=0,JB
            BLON(J,  MT)=   FWAVEJ(-MT, J)
            ALON(J,  MT)=   FWAVEJ(-MT,-J)
         END Do
            BLON(0,  MT)=   0.  ! to avoid the same input
             endif

         CALL GPFA_8_VEC( ALON,BLON,TRIGSIB, 1, IB, IB, 1, isign,JB,JB )

         do I=0,IB1
         DO J=0,JB
            PSI(I, J )= BLON(J ,I)
            PSI(I,-J )= ALON(J ,I)
         end do
         END DO

       ENDIF                  
!
!--------------------------------------------------------------------C
      END SUBROUTINE FFT_DFS_235_SC_FullGrid
!*********************************************************************
!
!*********************************************************************
!                                                                    c
!     14 MAY 2012 : x-transform only                                 c
!     25 MAY 2011 : inefficiency of factor 2 -> made efficient       c
!     12 MAY 2011 : call COS_FTN_FullGrid, and SIN                   c
!                                                                    c
!                 : inefficiency of factor 2 remains                 c
!                 : can be cured by MT -> MT/2 for args COS_FullGrid c
!                                                                    c
!*********************************************************************
      SUBROUTINE FFT_DFS_235_SC_FullGrid_x_trans                        &
      ( isign, PSI, FWAVEJ, JT, ipole ) ! is=1:->Wa, ip=1:cut
!--------------------------------------------------------------------C
        use parameter_pi
        use parameter_dsize
        use parameter_fsize
        use common_enm1_CosSinLat           ! 25 OCT 2010: m024 COS, m135 SIN
!--------------------------------------------------------------------C
        implicit none
      integer      :: isign, JT, ipole
      real(kind=8) :: PSI(0:IB1,-JB:JB)
      real(kind=8) :: FWAVEJ(-MT:MT,-JB:JB)
!-----local-variables------------------------------------------------C
      real(kind=8) :: mxx2(0:JBW,2)                               ! 2001.07.06
      real(kind=8) :: SHIFTC(0:JBW), SHIFTS(0:JBW)                 ! 2001.07.06
      real(kind=8) :: TRIGSIB(IB*2), TRIGSJBW(JBW*2)
!-----
!-----
      real(kind=8) :: data_COS(-MTH:MTH,0:JBW), temp_COS(-MTH:MTH)
      real(kind=8) :: data_SIN(-MTH:MTH,0:JBW), temp_SIN(-MTH:MTH)     ! mx=-MT,MT -> half
      real(kind=8) :: partRE_COS(-MTH:MTH,0:JB)
      real(kind=8) :: partIM_COS(-MTH:MTH,0:JB)
      real(kind=8) :: partRE_SIN(-MTH:MTH,0:JB)
      real(kind=8) :: partIM_SIN(-MTH:MTH,0:JB)
      real(kind=8) :: SINHF(0:JB), COSHF(0:JB)
      real(kind=8) :: COSPK(0:JB), SINPK(0:JB)             ! mx= all
!-----
      real(kind=8) :: ALON(0:JB,0:IB1)  , BLON(0:JB,0:IB1)
      real(kind=8) :: ALAC(0:MTH,0:JBW1), BLAC(0:MTH,0:JBW1)
      real(kind=8) :: ALAS(0:MTH,0:JBW1), BLAS(0:MTH,0:JBW1)
!-----
!     real(kind=8) :: FWAVEJ(-MT:MT,-JB:JB)
!-----
      CHARACTER(len=4) :: FFTOPT
      LOGICAL :: JUSDOIT=.TRUE.
!-----
      integer      :: mx,mj,mw,i,j,k,j2n,mlast,kev,kod,ibmx,jjbp1
      real(kind=8) :: pin, aa, bb
!--------------------------------------------------------------------C

      IF(JUSDOIT) THEN
         JUSDOIT=.FALSE.

         do mx=0,JBW    ! 2001.07.06
            mxx2(mx,1)= mx*2
            mxx2(mx,2)= mx*2+1
         end do

                PIN= PI/(JBW*2)  ! 05 MAR 2008
         do k=0,JBW    
            bb= PIN*dble(k)
            SHIFTC(k)= DCOS(bb)
            SHIFTS(k)= DSIN(bb)
         end do
!---
              FFTOPT='P235'
              J2N= 1
        do k=1,20
              J2N= J2N*2
           if(IB.eq.J2N) then
!             FFTOPT='P222'
              EXIT
           endif
        end do        ! 2004.04.02      
           write(*,*) ' IB, FFTSOPT=', IB, FFTOPT   

         CALL GPFASET_8_VEC(TRIGSIB ,IB )
         CALL GPFASET_8_VEC(TRIGSJBW,JBW)  ! for 2,3,5 prime factor 

            PIN= PI/JBW

         do j=0,JB                         ! For SINE and COSINE transform 
            aa= PIN*(j + 0.d0 )            ! 00-grid, full-grid, unstaggered grid
            SINHF(j)= DSIN(aa)
            COSHF(j)= DCOS(aa)
         end do
         do k=0,JB
            bb= PIN*dble(k)
            COSPK(k)= DCOS(bb)
            SINPK(k)= DSIN(bb)
         end do

      ENDIF

!----------------------------------------------------------------------C

          IF(JT.gt. JBW  )  then  ! 05 MAR 2008
             write(*,*) ' ==   Invalid range of Y-transform   =='
             write(*,*) ' == JT must not be greater than IB/2 =='
             stop
       ENDIF

!-----------------------------

                          MLAST= MT         ! A part transform for Y-dir
         if(MT.eq.(IB/2)) MLAST= MT-1       ! Full range transform for Y-dir
!
!        do 9211 J=-JB,JB    ! reset
!        do 9211 mx=-MT,MT 
!9211       FWAVEJ(mx,J)= 0.

!=============================
          IF(isign.EQ.+1) THEN
!=============================

!-----(I,J)->(mx,J)

         do I=0,IB1
         Do J=0,JB ! JB1 
            BLON( J,I)= PSI(I, J )
            ALON( J,I)= PSI(I,-J )
         end do
!           ALON(JB,I)= PSI(I,-JB)
!           BLON(JB,I)= 0.d0
            BLON( 0,I)= 0.d0      ! to avoid the same point 
         END Do
         
         CALL GPFA_8_VEC( ALON,BLON,TRIGSIB, 1, IB, IB, 1, isign,JB,JB )

         do mx=1,MLAST  
                      kev= mxx2(mx,1) ! mx*2
                      kod= mxx2(mx,2) ! kev+1
            IBmx= IB-mx
         Do J=0,JB
            FWAVEJ(-mx, J)= ( BLON(J,mx)+BLON(J,IBmx))/IB
            FWAVEJ(-mx,-J)= ( ALON(J,mx)+ALON(J,IBmx))/IB
            FWAVEJ( mx, J)= (-ALON(J,mx)+ALON(J,IBmx))/IB
            FWAVEJ( mx,-J)= ( BLON(J,mx)-BLON(J,IBmx))/IB
         END Do ! par 
         end do
         Do J=0,JB
            FWAVEJ( 0 , J)=    BLON(J,0 )/IB
            FWAVEJ( 0 ,-J)=    ALON(J,0 )/IB      ! always A is the last
                if(MT.eq.(IB/2)) then
            FWAVEJ(-MT, J)=    BLON(J,MT)/IB
            FWAVEJ(-MT,-J)=    ALON(J,MT)/IB
             endif
         END Do ! par 
!--
         do mx=1,MT               ! at poles      ! 18 MAY 2011
!           FWAVEJ(-mx,-JB)= 0.d0
!           FWAVEJ(-mx,+JB)= 0.d0
!           FWAVEJ( mx,-JB)= 0.d0
!           FWAVEJ( mx,+JB)= 0.d0
         end do   

!=============================
      ELSEIF(isign.EQ.-1) THEN
!=============================
!
!-----(mx,J)->(I,J)

         do I=0,IB1
         dO J=0,JB
            BLON(J,I)= 0.
            ALON(J,I)= 0.
         end do
         end do

         do mx=1,MLAST  
                      kev= mxx2(mx,1) ! mx*2
                      kod= mxx2(mx,2) ! kev+1
            IBmx= IB-mx
         Do J=1,JB
            BLON(J,  mx)= ( FWAVEJ( mx,-J)+FWAVEJ(-mx, J))/2.d0
            BLON(J,IBmx)= (-FWAVEJ( mx,-J)+FWAVEJ(-mx, J))/2.d0
            ALON(J,  mx)= ( FWAVEJ(-mx,-J)-FWAVEJ( mx, J))/2.d0
            ALON(J,IBmx)= ( FWAVEJ(-mx,-J)+FWAVEJ( mx, J))/2.d0
         END Do
            J=0
            BLON(J,  mx)= ( FWAVEJ( mx,-J)               )/2.d0
            BLON(J,IBmx)= (-FWAVEJ( mx,-J)               )/2.d0
            ALON(J,  mx)= ( FWAVEJ(-mx,-J)               )/2.d0
            ALON(J,IBmx)= ( FWAVEJ(-mx,-J)               )/2.d0
         end do ! mx=
            mx=0
         Do J=0,JB
            BLON(J,  mx)=   FWAVEJ( mx, J)
            ALON(J,  mx)=   FWAVEJ( mx,-J)
         END Do
            BLON(0,  mx)=   0.  ! to avoid the same input
                if(MT.eq.(IB/2)) then
         Do J=0,JB
            BLON(J,  MT)=   FWAVEJ(-MT, J)
            ALON(J,  MT)=   FWAVEJ(-MT,-J)
         END Do
            BLON(0,  MT)=   0.  ! to avoid the same input
             endif

         CALL GPFA_8_VEC( ALON,BLON,TRIGSIB, 1, IB, IB, 1, isign,JB,JB )

         do I=0,IB1
         DO J=0,JB
            PSI(I, J )= BLON(J ,I)
            PSI(I,-J )= ALON(J ,I)
         end do
         END DO

       ENDIF                  
!
!--------------------------------------------------------------------C
      END SUBROUTINE FFT_DFS_235_SC_FullGrid_x_trans
!*********************************************************************
!
!*********************************************************************
!                                                                    *
!     24 JUL 2009 : f90 style                                        *
!                                                                    *
!     To make GLOBAL AVERAGE zero ( When MAKE_0 = +1 )               *
!                                                                    *
!*********************************************************************
      SUBROUTINE GLOBAL0_FEM ( AJX, sum, MAKE_0 )  ! MAKE_0 =+1 : Make 0
!--------------------------------------------------------------------C
        use parameter_pi
        use parameter_dsize
        use parameter_fsize
        implicit none
!--------------------------------------------------------------------C
      real(kind=8) :: AJX(-MT:MT,0:JBW)
      real(kind=8) :: sum, sum1
      integer      :: MAKE_0
      real(kind=8) :: dd
      integer      :: mj,j
!--------------------------------------------------------------------C

          sum= 0.                      ! global mean

      DO mj=0,JBW,2
         sum1=0.d0
      do j=1,JBW-1
         sum1= sum1 + AJX(0,j) * DCOS( PI*j*mj/dfloat(JBW) )
      enddo ! j
         sum1= sum1+ (  AJX(0, 0 ) + AJX(0,JBW) *(-1.d0)**mj )/2.d0

         if(mj== 0 .OR. mj==JBW) then
               sum1= sum1/dfloat(JBW)
         else
               sum1= sum1/dfloat(JB )
         endif

           dd= DFLOAT(mj)**2-1.D-00
          sum= sum - sum1/dd
          
      ENDDO ! mj=

      IF(MAKE_0.eq.+1) AJX(0,:)= AJX(0,:) - sum  ! global-mean subtracted

!--------------------------------------------------------------------C
      END SUBROUTINE GLOBAL0_FEM
!*********************************************************************
!*********************************************************************
      SUBROUTINE GLOBAL0_FEM_1D ( AJX, JBW, sum, MAKE_0 )  ! MAKE_0 =+1 : Make 0
!--------------------------------------------------------------------C
        implicit none
!--------------------------------------------------------------------C
      real(kind=8), parameter :: PI= 3.14159265358979312D-00
      integer, intent( in)    :: JBW, MAKE_0
      real(kind=8) :: AJX(0:JBW)
      real(kind=8) :: sum, sum1
      real(kind=8) :: dd
      integer      :: mj,j
!--------------------------------------------------------------------C

          sum= 0.                      ! global mean

      DO mj=0,JBW,2
        sum1=0.d0
      do j=1,JBW-1
        sum1= sum1 + AJX(  j) * DCOS( PI*j*mj/dfloat(JBW) )
      enddo ! j
        sum1= sum1+ (  AJX(   0 ) + AJX(  JBW) *( 1-2*mod(mj,2) ) )/2.d0

         if(mj== 0 .OR. mj==JBW) then
               sum1= sum1/dfloat(JBW)
         else
               sum1= sum1/dfloat(JBW/2)
         endif

           dd= DFLOAT(mj)**2-1.D-00
          sum= sum - sum1/dd
          
      ENDDO ! mj=

      IF(MAKE_0.eq.+1) AJX(  :)= AJX(  :) - sum  ! global-mean subtracted

!--------------------------------------------------------------------C
      END SUBROUTINE GLOBAL0_FEM_1D
!*********************************************************************


!
!*********************************************************************
!                                                                    *
!     02 JUN 2011 : SUB FFT_..._HalfGrid, JT+1                       *
!     26 MAY 2011 : m02=SIN, m13=COS                                 *
!                                                                    *
!*********************************************************************
      SUBROUTINE FFT_DFS_235_SC_HalfGrid_r( isign, PSI, ANM, JT, ipole ) ! is=1:->Wa, ip=1:cut
!--------------------------------------------------------------------C
        use parameter_pi
        use parameter_dsize
        use parameter_fsize
        use common_enm1_CosSinLat           ! 25 OCT 2010: m024 COS, m135 SIN
!--------------------------------------------------------------------C
        implicit none
      integer      :: isign, JT, ipole
      real(kind=8) :: PSI(0:IB1,-JB:JB1), ANM(-MT:MT,0:JT)
!-----local-variables------------------------------------------------C
      real(kind=8) :: mxx2(0:JBW,2)                               ! 2001.07.06
      real(kind=8) :: SHIFTC(0:JBW), SHIFTS(0:JBW)                 ! 2001.07.06
      real(kind=8) :: TRIGSIB(IB*2), TRIGSJBW(JBW*2)
!-----
      real(kind=8) :: data_COS(-MTH:MTH,1:JBW), temp_COS(-MTH:MTH)
      real(kind=8) :: data_SIN(-MTH:MTH,1:JBW), temp_SIN(-MTH:MTH)         ! mx=-MT,MT -> half
      real(kind=8) :: partRE_COS(-MTH:MTH,0:JB)
      real(kind=8) :: partIM_COS(-MTH:MTH,0:JB)
      real(kind=8) :: partRE_SIN(-MTH:MTH,0:JB)
      real(kind=8) :: partIM_SIN(-MTH:MTH,0:JB)
      real(kind=8) :: SINHF(0:JB), COSPK(0:JB), SINPK(0:JB)             ! mx= all
!-----
      real(kind=8) :: ALON(0:JB,0:IB1) , BLON(0:JB,0:IB1)
      real(kind=8) :: ALAS(0:MTH,0:IB1), BLAS(0:MTH,0:IB1)
      real(kind=8) :: ALAC(0:MTH,0:IB1), BLAC(0:MTH,0:IB1)
!-----
      real(kind=8) :: FWAVEJ(-MT:MT,-JB:JB )
!-----
      CHARACTER(len=4) :: FFTOPT
      LOGICAL :: JUSDOIT=.TRUE.
!-----
      integer      :: mx,mj,mw,i,j,k,j2n,mlast,kev,kod,ibmx,jjbp1
      real(kind=8) :: pin, aa, bb
!--------------------------------------------------------------------C

      IF(JUSDOIT) THEN
         JUSDOIT=.FALSE.

         do mx=0,JBW    ! 2001.07.06
            mxx2(mx,1)= mx*2
            mxx2(mx,2)= mx*2+1
         end do

                PIN= PI/(JBW*2)  ! 05 MAR 2008
         do k=0,JBW    
            bb= PIN*dble(k)
            SHIFTC(k)= DCOS(bb)
            SHIFTS(k)= DSIN(bb)
         end do
!---
              FFTOPT='P235'
              J2N= 1
        do k=1,20
              J2N= J2N*2
           if(IB.eq.J2N) then
!             FFTOPT='P222'
              EXIT
           endif
        end do        ! 2004.04.02      
           write(*,*) ' IB, FFTSOPT=', IB, FFTOPT   

         CALL GPFASET_8_VEC(TRIGSIB ,IB )
         CALL GPFASET_8_VEC(TRIGSJBW,JBW)  ! for 2,3,5 prime factor 

            PIN= PI/JBW

         do j=0,JB                         ! For SINE and COSINE transform 
            aa= PIN*(j+0.5D-00)
            SINHF(j)= DSIN(aa)
         end do
         do k=0,JB
            bb= PIN*dble(k)
            COSPK(k)= DCOS(bb)
            SINPK(k)= DSIN(bb)
         end do

      ENDIF

!----------------------------------------------------------------------C

          IF(JT.gt. JBW  )  then  ! 05 MAR 2008
             write(*,*) ' ==   Invalid range of Y-transform   =='
             write(*,*) ' == JT must not be greater than IB/2 =='
             stop
       ENDIF

!-----------------------------

                          MLAST= MT         ! A part transform for Y-dir
         if(MT.eq.(IB/2)) MLAST= MT-1       ! Full range transform for Y-dir

         do 9211 J=-JB,JB    ! reset
         do 9211 mx=-MT,MT 
 9211       FWAVEJ(mx,J)= 0.

!=============================
          IF(isign.EQ.+1) THEN
!=============================

!-----(I,J)->(mx,J)

         do I=0,IB1
         Do J=0,JB1 
            BLON( J,I)= PSI(I, J )
            ALON( J,I)= PSI(I,-J )
         end do
            ALON(JB,I)= PSI(I,-JB)
            BLON(JB,I)= 0.d0
            BLON( 0,I)= 0.d0      ! to avoid the same point 
         END Do
         
         CALL GPFA_8_VEC( ALON,BLON,TRIGSIB, 1, IB, IB, 1, isign,JB,JB )

         do mx=1,MLAST  
                      kev= mxx2(mx,1) ! mx*2
                      kod= mxx2(mx,2) ! kev+1
            IBmx= IB-mx
         Do J=0,JB
            FWAVEJ(-mx, J)= ( BLON(J,mx)+BLON(J,IBmx))/IB ! FWAVEJ(*,JB)= 0.
            FWAVEJ(-mx,-J)= ( ALON(J,mx)+ALON(J,IBmx))/IB
            FWAVEJ( mx, J)= (-ALON(J,mx)+ALON(J,IBmx))/IB
            FWAVEJ( mx,-J)= ( BLON(J,mx)-BLON(J,IBmx))/IB
         END Do ! par 
         end do
         Do J=0,JB
            FWAVEJ( 0 , J)=    BLON(J,0 )/IB
            FWAVEJ( 0 ,-J)=    ALON(J,0 )/IB      ! always A is the last
                if(MT.eq.(IB/2)) then
            FWAVEJ(-MT, J)=    BLON(J,MT)/IB
            FWAVEJ(-MT,-J)=    ALON(J,MT)/IB
             endif
         END Do ! par 

!-----(mx,J)->(mx,mj)

            data_SIN( :,:)= 0.d0
            data_COS( :,:)= 0.d0
         Do J=-JB,JB1
            JJBP1= J+JB+1
         do mx=-MT,MT,2
                     mw= (mx+0)/2
            data_SIN(mw,JJBP1)= FWAVEJ(mx,J)      ! 05 MAR 2008: m0=COS, m1=SIN, m2=COS
!           data_COS(mw,JJBP1)= FWAVEJ(mx,J)      ! 05 MAR 2008: m0=COS, m1=SIN, m2=COS
         end do
         do mx=-MT+1,MT-1,2
                     mw= (mx+1)/2
            data_COS(mw,JJBP1)= FWAVEJ(mx,J)      ! 05 MAR 2008: m0=COS, m1=SIN, m2=COS
!           data_SIN(mw,JJBP1)= FWAVEJ(mx,J)      ! 05 MAR 2008: m0=COS, m1=SIN, m2=COS
         end do
         END Do

      CALL COS_FTN                                                      &
      ( data_COS, partRE_COS, partIM_COS, temp_COS, SINHF, COSPK, SINPK,&
       ALAC, BLAC, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )

      CALL SIN_FTN                                                      &
      ( data_SIN, partRE_SIN, partIM_SIN, temp_SIN, SINHF, COSPK, SINPK,&
       ALAS, BLAS, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )
!
                    i= 0
         if(JT<JBW) i= 1            ! 02 JUN 2011

         Do mj=1,JT+i
         do mx=-MT,MT,2
                                   mw= (mx+0)/2
            ANM(mx,mj  )= data_SIN(mw,mj)
!           ANM(mx,mj-1)= data_COS(mw,mj)
!           ANM(mx,mj-1)= data_COS(mx,mj)
         end do
         do mx=-MT+1,MT-1,2
                                   mw= (mx+1)/2
            ANM(mx,mj-1)= data_COS(mw,mj)
!           ANM(mx,mj  )= data_SIN(mw,mj)
!           ANM(mx,mj  )= data_SIN(mx,mj)
         end do
         END Do

!e 05 MAR 2008

!------
         do mx=-MT  ,MT,2        ! 26 MAY 2011
            ANM( mx,0)= 0.
         end do
             if(JT.eq. JBW  ) then
         do mx=-MT+1,MT,2
            ANM(mx,JT)= 0.
         end do
          endif   
             if(MT.eq.(IB/2)) then
         do mj=0,JT
            ANM(MT,mj)= 0.
         end do
          endif

!=============================
      ELSEIF(isign.EQ.-1) THEN
!=============================
!
         do mx=-MT  ,MT,2        ! 26 MAY 2011
            ANM( mx,0)= 0.
         end do
             if(JT.eq. JBW  ) then
         do mx=-MT+1,MT,2
            ANM(mx,JT)= 0.
         end do
          endif   
             if(MT.eq.(IB/2)) then
         do mj=0,JT
            ANM(MT,mj)= 0.
         end do
          endif

!-----(mx,mj)->(mx,J)

!b 05 MAR 2008

            data_SIN( :, :)= 0.d0
            data_COS( :, :)= 0.d0

                    i= 0
         if(JT<JBW) i= 1            ! 02 JUN 2011

         Do mj=1,JT+i
         do mx=-MT,MT,2
                     mw= (mx+0)/2
            data_SIN(mw,mj)= ANM(mx,mj  )
!           data_COS(mw,mj)= ANM(mx,mj-1)
!           data_COS(mx,mj)= ANM(mx,mj-1)
         end do
         do mx=-MT+1,MT-1,2
                     mw= (mx+1)/2
            data_COS(mw,mj)= ANM(mx,mj-1)
!           data_SIN(mw,mj)= ANM(mx,mj  )
!           data_SIN(mx,mj)= ANM(mx,mj  )
         end do
         END Do

      CALL COS_FTN                                                      &
      ( data_COS, partRE_COS, partIM_COS, temp_COS, SINHF, COSPK, SINPK,&
       ALAC, BLAC, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )
!
      CALL SIN_FTN                                                      &
      ( data_SIN, partRE_SIN, partIM_SIN, temp_SIN, SINHF, COSPK, SINPK,&
       ALAS, BLAS, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )
!
         Do J=-JB,JB1
            JJBP1= J+JB+1
         do mx=-MT,MT,2
                                   mw= (mx+0)/2
            FWAVEJ(mx,J)= data_SIN(mw,JJBP1)
!           FWAVEJ(mx,J)= data_COS(mw,JJBP1)
!           FWAVEJ(mx,J)= data_COS(mx,JJBP1)
         end do
         do mx=-MT+1,MT-1,2
                                   mw= (mx+1)/2
            FWAVEJ(mx,J)= data_COS(mw,JJBP1)
!           FWAVEJ(mx,J)= data_SIN(mw,JJBP1)
!           FWAVEJ(mx,J)= data_SIN(mx,JJBP1)
         end do
         END Do

!        IF(ipole.EQ.+1) CALL POLECUT
!
!-----(mx,J)->(I,J)

         do I=0,IB1
         dO J=0,JB
            BLON(J,I)= 0.
            ALON(J,I)= 0.
         end do
         end do

         do mx=1,MLAST  
                      kev= mxx2(mx,1) ! mx*2
                      kod= mxx2(mx,2) ! kev+1
            IBmx= IB-mx
         Do J=1,JB
            BLON(J,  mx)= ( FWAVEJ( mx,-J)+FWAVEJ(-mx, J))/2.d0
            BLON(J,IBmx)= (-FWAVEJ( mx,-J)+FWAVEJ(-mx, J))/2.d0
            ALON(J,  mx)= ( FWAVEJ(-mx,-J)-FWAVEJ( mx, J))/2.d0
            ALON(J,IBmx)= ( FWAVEJ(-mx,-J)+FWAVEJ( mx, J))/2.d0
         END Do
            J=0
            BLON(J,  mx)= ( FWAVEJ( mx,-J)               )/2.d0
            BLON(J,IBmx)= (-FWAVEJ( mx,-J)               )/2.d0
            ALON(J,  mx)= ( FWAVEJ(-mx,-J)               )/2.d0
            ALON(J,IBmx)= ( FWAVEJ(-mx,-J)               )/2.d0
         end do ! mx=
            mx=0
         Do J=0,JB
            BLON(J,  mx)=   FWAVEJ( mx, J)
            ALON(J,  mx)=   FWAVEJ( mx,-J)
         END Do
            BLON(0,  mx)=   0.  ! to avoid the same input
                if(MT.eq.(IB/2)) then
         Do J=0,JB
            BLON(J,  MT)=   FWAVEJ(-MT, J)
            ALON(J,  MT)=   FWAVEJ(-MT,-J)
         END Do
            BLON(0,  MT)=   0.  ! to avoid the same input
             endif

         CALL GPFA_8_VEC( ALON,BLON,TRIGSIB, 1, IB, IB, 1, isign,JB,JB )

         do I=0,IB1
         DO J=0,JB1
            PSI(I, J )= BLON(J ,I)
            PSI(I,-J )= ALON(J ,I)
         end do
            PSI(I,-JB)= ALON(JB,I)
         END DO

       ENDIF                  
!
!--------------------------------------------------------------------C
      END SUBROUTINE FFT_DFS_235_SC_HalfGrid_r
!*********************************************************************
!

!
!*********************************************************************
!                                                                    c
!     25 MAY 2011 : inefficiency of factor 2 -> made efficient       c
!     18 MAY 2011 : m135=COS, m024=SIN                               c
!     12 MAY 2011 : call COS_FTN_FullGrid, and SIN                   c
!                                                                    c
!                 : inefficiency of factor 2 remains                 c
!                 : can be cured by MT -> MT/2 for args COS_FullGrid c
!                                                                    c
!*********************************************************************
      SUBROUTINE FFT_DFS_235_SC_FullGrid_r( isign, PSI, ANM, JT, ipole ) ! is=1:->Wa, ip=1:cut
!--------------------------------------------------------------------C
        use parameter_pi
        use parameter_dsize
        use parameter_fsize
        use common_enm1_CosSinLat           ! 25 OCT 2010: m024 COS, m135 SIN
!--------------------------------------------------------------------C
        implicit none
!-----local-variables------------------------------------------------C
      integer      :: isign, JT, ipole
      real(kind=8) :: PSI(0:IB1,-JB:JB), ANM(-MT:MT,0:JT)
!-----
      real(kind=8) :: mxx2(0:JBW,2)                               ! 2001.07.06
      real(kind=8) :: SHIFTC(0:JBW), SHIFTS(0:JBW)                 ! 2001.07.06
      real(kind=8) :: TRIGSIB(IB*2), TRIGSJBW(JBW*2)
!-----
      real(kind=8) :: data_COS(-MTH:MTH,0:JBW), temp_COS(-MTH:MTH)
      real(kind=8) :: data_SIN(-MTH:MTH,0:JBW), temp_SIN(-MTH:MTH)         ! mx=-MT,MT -> half
      real(kind=8) :: partRE_COS(-MTH:MTH,0:JB)
      real(kind=8) :: partIM_COS(-MTH:MTH,0:JB)
      real(kind=8) :: partRE_SIN(-MTH:MTH,0:JB)
      real(kind=8) :: partIM_SIN(-MTH:MTH,0:JB)
      real(kind=8) :: SINHF(0:JB), COSHF(0:JB)
      real(kind=8) :: COSPK(0:JB), SINPK(0:JB)             ! mx= all
!-----
      real(kind=8) :: ALON(0:JB,0:IB1)  , BLON(0:JB,0:IB1)
      real(kind=8) :: ALAC(0:MTH,0:JBW1), BLAC(0:MTH,0:JBW1)
      real(kind=8) :: ALAS(0:MTH,0:JBW1), BLAS(0:MTH,0:JBW1)
!-----
      real(kind=8) :: FWAVEJ(-MT:MT,-JB:JB)
!-----
      CHARACTER(len=4) :: FFTOPT
      LOGICAL :: JUSDOIT=.TRUE.
!-----
      integer      :: mx,mj,mw,i,j,k,j2n,mlast,kev,kod,ibmx,jjbp1
      real(kind=8) :: pin, aa, bb
!--------------------------------------------------------------------C

      IF(JUSDOIT) THEN
         JUSDOIT=.FALSE.

         do mx=0,JBW    ! 2001.07.06
            mxx2(mx,1)= mx*2
            mxx2(mx,2)= mx*2+1
         end do

                PIN= PI/(JBW*2)  ! 05 MAR 2008
         do k=0,JBW    
            bb= PIN*dble(k)
            SHIFTC(k)= DCOS(bb)
            SHIFTS(k)= DSIN(bb)
         end do
!---
              FFTOPT='P235'
              J2N= 1
        do k=1,20
              J2N= J2N*2
           if(IB.eq.J2N) then
!             FFTOPT='P222'
              EXIT
           endif
        end do        ! 2004.04.02      
           write(*,*) ' IB, FFTSOPT=', IB, FFTOPT   

         CALL GPFASET_8_VEC(TRIGSIB ,IB )
         CALL GPFASET_8_VEC(TRIGSJBW,JBW)  ! for 2,3,5 prime factor 

            PIN= PI/JBW

         do j=0,JB                         ! For SINE and COSINE transform 
            aa= PIN*(j + 0.d0 )            ! 00-grid, full-grid, unstaggered grid
            SINHF(j)= DSIN(aa)
            COSHF(j)= DCOS(aa)
         end do
         do k=0,JB
            bb= PIN*dble(k)
            COSPK(k)= DCOS(bb)
            SINPK(k)= DSIN(bb)
         end do

      ENDIF

!----------------------------------------------------------------------C

          IF(JT.gt. JBW  )  then  ! 05 MAR 2008
             write(*,*) ' ==   Invalid range of Y-transform   =='
             write(*,*) ' == JT must not be greater than IB/2 =='
             stop
       ENDIF

!-----------------------------

                          MLAST= MT         ! A part transform for Y-dir
         if(MT.eq.(IB/2)) MLAST= MT-1       ! Full range transform for Y-dir

         do 9211 J=-JB,JB    ! reset
         do 9211 mx=-MT,MT 
 9211       FWAVEJ(mx,J)= 0.

!=============================
          IF(isign.EQ.+1) THEN
!=============================
!
!-- hurts
!        aa= 0.d0              ! at poles      ! 18 MAY 2011
!        bb= 0.d0 
!     do I=0,IB1
!        aa= aa + PSI(I,-JB)
!        bb= bb + PSI(I, JB)
!     end do
!        PSI(:,-JB)= aa/IB
!        PSI(:, JB)= bb/IB
!--
!-----(I,J)->(mx,J)

         do I=0,IB1
         Do J=0,JB ! JB1 
            BLON( J,I)= PSI(I, J )
            ALON( J,I)= PSI(I,-J )
         end do
!           ALON(JB,I)= PSI(I,-JB)
!           BLON(JB,I)= 0.d0
            BLON( 0,I)= 0.d0      ! to avoid the same point 
         END Do

         
         CALL GPFA_8_VEC( ALON,BLON,TRIGSIB, 1, IB, IB, 1, isign,JB,JB )

         do mx=1,MLAST  
                      kev= mxx2(mx,1) ! mx*2
                      kod= mxx2(mx,2) ! kev+1
            IBmx= IB-mx
         Do J=0,JB
            FWAVEJ(-mx, J)= ( BLON(J,mx)+BLON(J,IBmx))/IB
            FWAVEJ(-mx,-J)= ( ALON(J,mx)+ALON(J,IBmx))/IB
            FWAVEJ( mx, J)= (-ALON(J,mx)+ALON(J,IBmx))/IB
            FWAVEJ( mx,-J)= ( BLON(J,mx)-BLON(J,IBmx))/IB
         END Do ! par 
         end do
         Do J=0,JB
            FWAVEJ( 0 , J)=    BLON(J,0 )/IB
            FWAVEJ( 0 ,-J)=    ALON(J,0 )/IB      ! always A is the last
                if(MT.eq.(IB/2)) then
            FWAVEJ(-MT, J)=    BLON(J,MT)/IB
            FWAVEJ(-MT,-J)=    ALON(J,MT)/IB
             endif
         END Do ! par 
!--
         do mx=1,MT               ! at poles      ! 18 MAY 2011
!           FWAVEJ(-mx,-JB)= 0.d0
!           FWAVEJ(-mx,+JB)= 0.d0
!           FWAVEJ( mx,-JB)= 0.d0
!           FWAVEJ( mx,+JB)= 0.d0
         end do   

!        IF(ipole.EQ.+1) CALL POLECUT

!-----(mx,J)->(mx,mj)

            data_SIN( :,:)= 0.d0
            data_COS( :,:)= 0.d0
         Do J=-JB,JB
            JJBP1= J+JB
         do mx=-MT,MT,2
                     mw= (mx+0)/2 
            data_SIN(mw,JJBP1)= FWAVEJ(mx,J)  ! 18 MAY 2011
!           data_SIN(mx,JJBP1)= FWAVEJ(mx,J)  ! 18 MAY 2011
         end do
         do mx=-MT+1,MT-1,2
                     mw= (mx+1)/2 
            data_COS(mw,JJBP1)= FWAVEJ(mx,J)
!           data_COS(mx,JJBP1)= FWAVEJ(mx,J)
         end do
         END Do ! J=
!
      CALL COS_FTN_FullGrid                                             &
      ( data_COS, partRE_COS, partIM_COS, temp_COS, SINHF, COSHF,       &
       COSPK, SINPK,                                                    &
       ALAC, BLAC, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )

      CALL SIN_FTN_FullGrid                                             &
      ( data_SIN, partRE_SIN, partIM_SIN, temp_SIN, SINHF, COSHF,       &
       COSPK, SINPK,                                                    &
       ALAS, BLAS, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )

         do mj=0,JT
         do mx=-MT,MT,2
                                 mw= (mx+0)/2 
            ANM(mx,mj)= data_SIN(mw,mj)
!           ANM(mx,mj)= data_SIN(mx,mj)
         end do
         do mx=-MT+1,MT-1,2
                                 mw= (mx+1)/2 
            ANM(mx,mj)= data_COS(mw,mj)
!           ANM(mx,mj)= data_COS(mx,mj)
         end do
         END Do ! mj=

!------
         do mx=-MT  ,MT,2            ! 18 MAY 2011
            ANM( mx,0)= 0.
         end do
             if(JT.eq. JBW  ) then
         do mx=-MT  ,MT,2
            ANM(mx,JT)= 0.
         end do
          endif
             if(MT.eq.(IB/2)) then
         do mj=0,JT
            ANM(MT,mj)= 0.
         end do
          endif

!=============================
      ELSEIF(isign.EQ.-1) THEN
!=============================
!
         do mx=-MT  ,MT,2            ! 18 MAY 2011
            ANM( mx,0)= 0.
         end do
             if(JT.eq. JBW  ) then
         do mx=-MT  ,MT,2
            ANM(mx,JT)= 0.
         end do
          endif
             if(MT.eq.(IB/2)) then
         do mj=0,JT
            ANM(MT,mj)= 0.
         end do
          endif

!-----(mx,mj)->(mx,J)

            data_SIN( :, :)= 0.d0
            data_COS( :, :)= 0.d0

         Do mj=0,JT
         do mx=-MT,MT,2
                     mw= (mx+0)/2
            data_SIN(mw,mj)= ANM(mx,mj)
!           data_SIN(mx,mj)= ANM(mx,mj)
         end do
         do mx=-MT+1,MT-1,2
                     mw= (mx+1)/2
            data_COS(mw,mj)= ANM(mx,mj)
!           data_COS(mx,mj)= ANM(mx,mj)
         end do
         END Do ! mj=

      CALL COS_FTN_FullGrid                                             &
      ( data_COS, partRE_COS, partIM_COS, temp_COS, SINHF, COSHF,       &
       COSPK, SINPK,                                                    &
       ALAC, BLAC, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )

      CALL SIN_FTN_FullGrid                                             &
      ( data_SIN, partRE_SIN, partIM_SIN, temp_SIN, SINHF, COSHF,       &
       COSPK, SINPK,                                                    &
       ALAS, BLAS, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )

         Do J=-JB,JB
            JJBP1= J+JB
         do mx=-MT,MT,2
                                   mw= (mx+0)/2
            FWAVEJ(mx,J)= data_SIN(mw,JJBP1)
!           FWAVEJ(mx,J)= data_SIN(mx,JJBP1)
         end do
         do mx=-MT+1,MT-1,2
                                   mw= (mx+1)/2
            FWAVEJ(mx,J)= data_COS(mw,JJBP1)
!           FWAVEJ(mx,J)= data_COS(mx,JJBP1)
         end do
         END Do ! J=
!--
         do mx=1,MT               ! at poles      ! 18 MAY 2011
!           FWAVEJ(-mx,-JB)= 0.d0
!           FWAVEJ(-mx,+JB)= 0.d0
!           FWAVEJ( mx,-JB)= 0.d0
!           FWAVEJ( mx,+JB)= 0.d0
         end do   

!        IF(ipole.EQ.+1) CALL POLECUT
!
!-----(mx,J)->(I,J)

         do I=0,IB1
         dO J=0,JB
            BLON(J,I)= 0.
            ALON(J,I)= 0.
         end do
         end do

         do mx=1,MLAST  
                      kev= mxx2(mx,1) ! mx*2
                      kod= mxx2(mx,2) ! kev+1
            IBmx= IB-mx
         Do J=1,JB
            BLON(J,  mx)= ( FWAVEJ( mx,-J)+FWAVEJ(-mx, J))/2.d0
            BLON(J,IBmx)= (-FWAVEJ( mx,-J)+FWAVEJ(-mx, J))/2.d0
            ALON(J,  mx)= ( FWAVEJ(-mx,-J)-FWAVEJ( mx, J))/2.d0
            ALON(J,IBmx)= ( FWAVEJ(-mx,-J)+FWAVEJ( mx, J))/2.d0
         END Do
            J=0
            BLON(J,  mx)= ( FWAVEJ( mx,-J)               )/2.d0
            BLON(J,IBmx)= (-FWAVEJ( mx,-J)               )/2.d0
            ALON(J,  mx)= ( FWAVEJ(-mx,-J)               )/2.d0
            ALON(J,IBmx)= ( FWAVEJ(-mx,-J)               )/2.d0
         end do ! mx=
            mx=0
         Do J=0,JB
            BLON(J,  mx)=   FWAVEJ( mx, J)
            ALON(J,  mx)=   FWAVEJ( mx,-J)
         END Do
            BLON(0,  mx)=   0.  ! to avoid the same input
                if(MT.eq.(IB/2)) then
         Do J=0,JB
            BLON(J,  MT)=   FWAVEJ(-MT, J)
            ALON(J,  MT)=   FWAVEJ(-MT,-J)
         END Do
            BLON(0,  MT)=   0.  ! to avoid the same input
             endif

         CALL GPFA_8_VEC( ALON,BLON,TRIGSIB, 1, IB, IB, 1, isign,JB,JB )

         do I=0,IB1
         DO J=0,JB
            PSI(I, J )= BLON(J ,I)
            PSI(I,-J )= ALON(J ,I)
         end do
         END DO

       ENDIF                  
!
!--------------------------------------------------------------------C
      END SUBROUTINE FFT_DFS_235_SC_FullGrid_r
!*********************************************************************
!

!*********************************************************************
!                                                                    c
!     18 NOV 2012 : y-transform only of x-transformed data           c
!     25 MAY 2011 : inefficiency of factor 2 -> made efficient       c
!     12 MAY 2011 : call COS_FTN_FullGrid, and SIN                   c
!                                                                    c
!                 : inefficiency of factor 2 remains                 c
!                 : can be cured by MT -> MT/2 for args COS_FullGrid c
!                                                                    c
!*********************************************************************
      SUBROUTINE FFT_DFS_235_SC_FullGrid_y_trans                        &
      ( isign, FWAVEJ, ANM, JT, ipole ) ! is=1:->Wa, ip=1:cut
!--------------------------------------------------------------------C
        use parameter_pi
        use parameter_dsize
        use parameter_fsize
        use common_enm1_CosSinLat           ! 25 OCT 2010: m024 COS, m135 SIN
!--------------------------------------------------------------------C
        implicit none
      integer      :: isign, JT, ipole
      real(kind=8) :: ANM(-MT:MT,0:JT)
      real(kind=8) :: FWAVEJ(-MT:MT,-JB:JB)
!-----local-variables------------------------------------------------C
      real(kind=8) :: mxx2(0:JBW,2)                               ! 2001.07.06
      real(kind=8) :: SHIFTC(0:JBW), SHIFTS(0:JBW)                 ! 2001.07.06
      real(kind=8) :: TRIGSIB(IB*2), TRIGSJBW(JBW*2)
!-----
!-----
      real(kind=8) :: data_COS(-MTH:MTH,0:JBW), temp_COS(-MTH:MTH)
      real(kind=8) :: data_SIN(-MTH:MTH,0:JBW), temp_SIN(-MTH:MTH)         ! mx=-MT,MT -> half
      real(kind=8) :: partRE_COS(-MTH:MTH,0:JB)
      real(kind=8) :: partIM_COS(-MTH:MTH,0:JB)
      real(kind=8) :: partRE_SIN(-MTH:MTH,0:JB)
      real(kind=8) :: partIM_SIN(-MTH:MTH,0:JB)
      real(kind=8) :: SINHF(0:JB), COSHF(0:JB)
      real(kind=8) :: COSPK(0:JB), SINPK(0:JB)             ! mx= all
!-----
      real(kind=8) :: ALON(0:JB,0:IB1)  , BLON(0:JB,0:IB1)
      real(kind=8) :: ALAC(0:MTH,0:JBW1), BLAC(0:MTH,0:JBW1)
      real(kind=8) :: ALAS(0:MTH,0:JBW1), BLAS(0:MTH,0:JBW1)
!-----
      CHARACTER(len=4) :: FFTOPT
      LOGICAL :: JUSDOIT=.TRUE.
!-----
      integer      :: mx,mj,mw,i,j,k,j2n,mlast,kev,kod,ibmx,jjbp1
      real(kind=8) :: pin, aa, bb
!--------------------------------------------------------------------C

      IF(JUSDOIT) THEN
         JUSDOIT=.FALSE.

         do mx=0,JBW    ! 2001.07.06
            mxx2(mx,1)= mx*2
            mxx2(mx,2)= mx*2+1
         end do

                PIN= PI/(JBW*2)  ! 05 MAR 2008
         do k=0,JBW    
            bb= PIN*dble(k)
            SHIFTC(k)= DCOS(bb)
            SHIFTS(k)= DSIN(bb)
         end do
!---
              FFTOPT='P235'
              J2N= 1
        do k=1,20
              J2N= J2N*2
           if(IB.eq.J2N) then
!             FFTOPT='P222'
              EXIT
           endif
        end do        ! 2004.04.02      
           write(*,*) ' IB, FFTSOPT=', IB, FFTOPT   

         CALL GPFASET_8_VEC(TRIGSIB ,IB )
         CALL GPFASET_8_VEC(TRIGSJBW,JBW)  ! for 2,3,5 prime factor 

            PIN= PI/JBW

         do j=0,JB                         ! For SINE and COSINE transform 
            aa= PIN*(j + 0.d0 )            ! 00-grid, full-grid, unstaggered grid
            SINHF(j)= DSIN(aa)
            COSHF(j)= DCOS(aa)
         end do
         do k=0,JB
            bb= PIN*dble(k)
            COSPK(k)= DCOS(bb)
            SINPK(k)= DSIN(bb)
         end do
!---
      ENDIF

!----------------------------------------------------------------------C

          IF(JT.gt. JBW  )  then  ! 05 MAR 2008
             write(*,*) ' ==   Invalid range of Y-transform   =='
             write(*,*) ' == JT must not be greater than IB/2 =='
             stop
       ENDIF

!-----------------------------

                          MLAST= MT         ! A part transform for Y-dir
         if(MT.eq.(IB/2)) MLAST= MT-1       ! Full range transform for Y-dir

!        do 9211 J=-JB,JB    ! reset
!        do 9211 mx=-MT,MT 
!9211       FWAVEJ(mx,J)= 0.

!=============================
          IF(isign.EQ.+1) THEN
!=============================

!-----(mx,J)->(mx,mj)

            data_SIN( :,:)= 0.d0
            data_COS( :,:)= 0.d0
         Do J=-JB,JB
            JJBP1= J+JB
         do mx=-MT,MT,2
                     mw= (mx+0)/2
            data_COS(mw,JJBP1)= FWAVEJ(mx,J)      ! 05 MAR 2008: m0=COS, m1=SIN, m2=COS
!           data_COS(mx,JJBP1)= FWAVEJ(mx,J)      ! 05 MAR 2008: m0=COS, m1=SIN, m2=COS
         end do
         do mx=-MT+1,MT-1,2
                     mw= (mx+1)/2
            data_SIN(mw,JJBP1)= FWAVEJ(mx,J)      ! 05 MAR 2008: m0=COS, m1=SIN, m2=COS
!           data_SIN(mx,JJBP1)= FWAVEJ(mx,J)      ! 05 MAR 2008: m0=COS, m1=SIN, m2=COS
         end do
         END Do ! J=
!
      CALL COS_FTN_FullGrid                                             &
      ( data_COS, partRE_COS, partIM_COS, temp_COS, SINHF, COSHF,       &
       COSPK, SINPK,                                                    &
       ALAC, BLAC, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )

      CALL SIN_FTN_FullGrid                                             &
      ( data_SIN, partRE_SIN, partIM_SIN, temp_SIN, SINHF, COSHF,       &
       COSPK, SINPK,                                                    &
       ALAS, BLAS, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )

         do mj=0,JT
         do mx=-MT,MT,2
                                 mw= (mx+0)/2
            ANM(mx,mj)= data_COS(mw,mj)
!           ANM(mx,mj)= data_COS(mx,mj)
         end do
         do mx=-MT+1,MT-1,2
                                 mw= (mx+1)/2
            ANM(mx,mj)= data_SIN(mw,mj)
!           ANM(mx,mj)= data_SIN(mx,mj)
         end do
         END Do ! mj=

!------
         do mx=-MT+1,MT,2            ! 10 MAY 2011
            ANM( mx,0)= 0.
         end do
             if(JT.eq. JBW  ) then
         do mx=-MT+1,MT,2
            ANM(mx,JT)= 0.
         end do
          endif
             if(MT.eq.(IB/2)) then
         do mj=0,JT
            ANM(MT,mj)= 0.
         end do
          endif

!=============================
      ELSEIF(isign.EQ.-1) THEN
!=============================
!
         do mx=-MT+1,MT,2            ! 10 MAY 2011
            ANM( mx,0)= 0.
         end do
             if(JT.eq. JBW  ) then
         do mx=-MT+1,MT,2
            ANM(mx,JT)= 0.
         end do
          endif
             if(MT.eq.(IB/2)) then
         do mj=0,JT
            ANM(MT,mj)= 0.
         end do
          endif

!-----(mx,mj)->(mx,J)

            data_SIN( :, :)= 0.d0
            data_COS( :, :)= 0.d0

         Do mj=0,JT
         do mx=-MT,MT,2
                     mw= (mx+0)/2
            data_COS(mw,mj)= ANM(mx,mj)
!           data_COS(mx,mj)= ANM(mx,mj)
         end do
         do mx=-MT+1,MT-1,2
                     mw= (mx+1)/2
            data_SIN(mw,mj)= ANM(mx,mj)
!           data_SIN(mx,mj)= ANM(mx,mj)
         end do
         END Do ! mj=

      CALL COS_FTN_FullGrid                                             &
      ( data_COS, partRE_COS, partIM_COS, temp_COS, SINHF, COSHF,       &
        COSPK, SINPK,                                                   &
        ALAC, BLAC, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )

      CALL SIN_FTN_FullGrid                                             &
      ( data_SIN, partRE_SIN, partIM_SIN, temp_SIN, SINHF, COSHF,       &
        COSPK, SINPK,                                                   &
        ALAS, BLAS, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )

         Do J=-JB,JB
            JJBP1= J+JB
         do mx=-MT,MT,2
                                   mw= (mx+0)/2
            FWAVEJ(mx,J)= data_COS(mw,JJBP1)
!           FWAVEJ(mx,J)= data_COS(mx,JJBP1)
         end do
         do mx=-MT+1,MT-1,2
                                   mw= (mx+1)/2
            FWAVEJ(mx,J)= data_SIN(mw,JJBP1)
!           FWAVEJ(mx,J)= data_SIN(mx,JJBP1)
         end do
         END Do ! J=
!--
       ENDIF                  
!
!--------------------------------------------------------------------C
      END SUBROUTINE FFT_DFS_235_SC_FullGrid_y_trans
!*********************************************************************
!
!
!*********************************************************************
!                                                                    c
!     18 NOV 2012 : y-transform only of x-transformed data           c
!     25 MAY 2011 : inefficiency of factor 2 -> made efficient       c
!     18 MAY 2011 : m135=COS, m024=SIN                               c
!     12 MAY 2011 : call COS_FTN_FullGrid, and SIN                   c
!                                                                    c
!                 : inefficiency of factor 2 remains                 c
!                 : can be cured by MT -> MT/2 for args COS_FullGrid c
!                                                                    c
!********************************************************************
      SUBROUTINE FFT_DFS_235_SC_FullGrid_r_y_trans                      &
      ( isign, FWAVEJ, ANM, JT, ipole ) ! is=1:->Wa, ip=1:cut
!--------------------------------------------------------------------C
        use parameter_pi
        use parameter_dsize
        use parameter_fsize
        use common_enm1_CosSinLat           ! 25 OCT 2010: m024 COS, m135 SIN
!--------------------------------------------------------------------C
        implicit none
!-----local-variables------------------------------------------------C
      integer      :: isign, JT, ipole
      real(kind=8) :: ANM(-MT:MT,0:JT)
      real(kind=8) :: FWAVEJ(-MT:MT,-JB:JB)
!-----
      real(kind=8) :: mxx2(0:JBW,2)                               ! 2001.07.06
      real(kind=8) :: SHIFTC(0:JBW), SHIFTS(0:JBW)                 ! 2001.07.06
      real(kind=8) :: TRIGSIB(IB*2), TRIGSJBW(JBW*2)
!-----
      real(kind=8) :: data_COS(-MTH:MTH,0:JBW), temp_COS(-MTH:MTH)
      real(kind=8) :: data_SIN(-MTH:MTH,0:JBW), temp_SIN(-MTH:MTH)         ! mx=-MT,MT -> half
      real(kind=8) :: partRE_COS(-MTH:MTH,0:JB)
      real(kind=8) :: partIM_COS(-MTH:MTH,0:JB)
      real(kind=8) :: partRE_SIN(-MTH:MTH,0:JB)
      real(kind=8) :: partIM_SIN(-MTH:MTH,0:JB)
      real(kind=8) :: SINHF(0:JB), COSHF(0:JB)
      real(kind=8) :: COSPK(0:JB), SINPK(0:JB)             ! mx= all
!-----
      real(kind=8) :: ALON(0:JB,0:IB1)  , BLON(0:JB,0:IB1)
      real(kind=8) :: ALAC(0:MTH,0:JBW1), BLAC(0:MTH,0:JBW1)
      real(kind=8) :: ALAS(0:MTH,0:JBW1), BLAS(0:MTH,0:JBW1)
!-----
      CHARACTER(len=4) :: FFTOPT
      LOGICAL :: JUSDOIT=.TRUE.
!-----
      integer      :: mx,mj,mw,i,j,k,j2n,mlast,kev,kod,ibmx,jjbp1
      real(kind=8) :: pin, aa, bb
!--------------------------------------------------------------------C

      IF(JUSDOIT) THEN
         JUSDOIT=.FALSE.

         do mx=0,JBW    ! 2001.07.06
            mxx2(mx,1)= mx*2
            mxx2(mx,2)= mx*2+1
         end do

                PIN= PI/(JBW*2)  ! 05 MAR 2008
         do k=0,JBW    
            bb= PIN*dble(k)
            SHIFTC(k)= DCOS(bb)
            SHIFTS(k)= DSIN(bb)
         end do
!---
              FFTOPT='P235'
              J2N= 1
        do k=1,20
              J2N= J2N*2
           if(IB.eq.J2N) then
!             FFTOPT='P222'
              EXIT
           endif
        end do        ! 2004.04.02      
           write(*,*) ' IB, FFTSOPT=', IB, FFTOPT   

         CALL GPFASET_8_VEC(TRIGSIB ,IB )
         CALL GPFASET_8_VEC(TRIGSJBW,JBW)  ! for 2,3,5 prime factor 

            PIN= PI/JBW

         do j=0,JB                         ! For SINE and COSINE transform 
            aa= PIN*(j + 0.d0 )            ! 00-grid, full-grid, unstaggered grid
            SINHF(j)= DSIN(aa)
            COSHF(j)= DCOS(aa)
         end do
         do k=0,JB
            bb= PIN*dble(k)
            COSPK(k)= DCOS(bb)
            SINPK(k)= DSIN(bb)
         end do

      ENDIF

!----------------------------------------------------------------------C

          IF(JT.gt. JBW  )  then  ! 05 MAR 2008
             write(*,*) ' ==   Invalid range of Y-transform   =='
             write(*,*) ' == JT must not be greater than IB/2 =='
             stop
       ENDIF

!-----------------------------

                          MLAST= MT         ! A part transform for Y-dir
         if(MT.eq.(IB/2)) MLAST= MT-1       ! Full range transform for Y-dir

!        do 9211 J=-JB,JB    ! reset
!        do 9211 mx=-MT,MT 
!9211       FWAVEJ(mx,J)= 0.

!=============================
          IF(isign.EQ.+1) THEN
!=============================
!
!-----(mx,J)->(mx,mj)

            data_SIN( :,:)= 0.d0
            data_COS( :,:)= 0.d0
         Do J=-JB,JB
            JJBP1= J+JB
         do mx=-MT,MT,2
                     mw= (mx+0)/2 
            data_SIN(mw,JJBP1)= FWAVEJ(mx,J)  ! 18 MAY 2011
!           data_SIN(mx,JJBP1)= FWAVEJ(mx,J)  ! 18 MAY 2011
         end do
         do mx=-MT+1,MT-1,2
                     mw= (mx+1)/2 
            data_COS(mw,JJBP1)= FWAVEJ(mx,J)
!           data_COS(mx,JJBP1)= FWAVEJ(mx,J)
         end do
         END Do ! J=
!
      CALL COS_FTN_FullGrid                                             &
      ( data_COS, partRE_COS, partIM_COS, temp_COS, SINHF, COSHF,       &
        COSPK, SINPK,                                                   &
        ALAC, BLAC, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )

      CALL SIN_FTN_FullGrid                                             &
      ( data_SIN, partRE_SIN, partIM_SIN, temp_SIN, SINHF, COSHF,       &
        COSPK, SINPK,                                                   &
        ALAS, BLAS, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )

         do mj=0,JT
         do mx=-MT,MT,2
                                 mw= (mx+0)/2 
            ANM(mx,mj)= data_SIN(mw,mj)
!           ANM(mx,mj)= data_SIN(mx,mj)
         end do
         do mx=-MT+1,MT-1,2
                                 mw= (mx+1)/2 
            ANM(mx,mj)= data_COS(mw,mj)
!           ANM(mx,mj)= data_COS(mx,mj)
         end do
         END Do ! mj=

!------
         do mx=-MT  ,MT,2            ! 18 MAY 2011
            ANM( mx,0)= 0.
         end do
             if(JT.eq. JBW  ) then
         do mx=-MT  ,MT,2
            ANM(mx,JT)= 0.
         end do
          endif
             if(MT.eq.(IB/2)) then
         do mj=0,JT
            ANM(MT,mj)= 0.
         end do
          endif

!=============================
      ELSEIF(isign.EQ.-1) THEN
!=============================
!
         do mx=-MT  ,MT,2            ! 18 MAY 2011
            ANM( mx,0)= 0.
         end do
             if(JT.eq. JBW  ) then
         do mx=-MT  ,MT,2
            ANM(mx,JT)= 0.
         end do
          endif
             if(MT.eq.(IB/2)) then
         do mj=0,JT
            ANM(MT,mj)= 0.
         end do
          endif

!-----(mx,mj)->(mx,J)

            data_SIN( :, :)= 0.d0
            data_COS( :, :)= 0.d0

         Do mj=0,JT
         do mx=-MT,MT,2
                     mw= (mx+0)/2
            data_SIN(mw,mj)= ANM(mx,mj)
!           data_SIN(mx,mj)= ANM(mx,mj)
         end do
         do mx=-MT+1,MT-1,2
                     mw= (mx+1)/2
            data_COS(mw,mj)= ANM(mx,mj)
!           data_COS(mx,mj)= ANM(mx,mj)
         end do
         END Do ! mj=

      CALL COS_FTN_FullGrid                                             &
      ( data_COS, partRE_COS, partIM_COS, temp_COS, SINHF, COSHF,       &
        COSPK, SINPK,                                                   &
        ALAC, BLAC, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )

      CALL SIN_FTN_FullGrid                                             &
      ( data_SIN, partRE_SIN, partIM_SIN, temp_SIN, SINHF, COSHF,       &
        COSPK, SINPK,                                                   &
        ALAS, BLAS, TRIGSJBW, JBW, JBW-1, JB, MT/2, isign )

         Do J=-JB,JB
            JJBP1= J+JB
         do mx=-MT,MT,2
                                   mw= (mx+0)/2
            FWAVEJ(mx,J)= data_SIN(mw,JJBP1)
!           FWAVEJ(mx,J)= data_SIN(mx,JJBP1)
         end do
         do mx=-MT+1,MT-1,2
                                   mw= (mx+1)/2
            FWAVEJ(mx,J)= data_COS(mw,JJBP1)
!           FWAVEJ(mx,J)= data_COS(mx,JJBP1)
         end do
         END Do ! J=
!--
       ENDIF                  
!
!--------------------------------------------------------------------C
      END SUBROUTINE FFT_DFS_235_SC_FullGrid_r_y_trans
!*********************************************************************



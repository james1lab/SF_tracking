#!/bin/csh -xvf
#PBS -l nodes=slash08:ppn=1
#PBS -N ETC_YEARS
#PBS -j oe
#PBS -o wrf.out

set NPROC = `cat $PBS_NODEFILE | wc -l`
limit stacksize unlimit
cd $PBS_O_WORKDIR
time mpirun -np $NPROC -machinefile $PBS_NODEFILE ./CYCLONE_TRACKING_YEARS.exe
